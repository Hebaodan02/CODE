import json
import os
import threading
import time
import uuid
from pathlib import Path


class PersistentTaskQueue:
    def __init__(self, path, base_delay=5, max_delay=300, max_attempts=20):
        self.path = Path(path)
        self.base_delay = base_delay
        self.max_delay = max_delay
        self.max_attempts = max_attempts
        self._lock = threading.Lock()
        self._tasks = self._load()

    def _load(self):
        try:
            data = json.loads(self.path.read_text(encoding="utf-8"))
            return data if isinstance(data, list) else []
        except (OSError, ValueError, TypeError):
            return []

    def _save(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)
        fd, temp_path = tempfile_path = None, None
        try:
            fd, temp_path = __import__("tempfile").mkstemp(
                prefix=self.path.name + ".", suffix=".tmp", dir=str(self.path.parent))
            with os.fdopen(fd, "w", encoding="utf-8") as f:
                fd = None
                json.dump(self._tasks, f, ensure_ascii=False, separators=(",", ":"))
                f.flush()
                os.fsync(f.fileno())
            os.replace(temp_path, self.path)
            temp_path = None
            return True
        except OSError:
            return False
        finally:
            if fd is not None:
                os.close(fd)
            if temp_path:
                try:
                    os.unlink(temp_path)
                except OSError:
                    pass

    def add(self, task):
        item = dict(task)
        item.update({
            "id": item.get("id") or uuid.uuid4().hex,
            "attempts": int(item.get("attempts", 0)),
            "next_try": float(item.get("next_try", 0)),
            "created_at": float(item.get("created_at", time.time())),
        })
        with self._lock:
            self._tasks.append(item)
            self._save()
        return item["id"]

    def next_ready(self):
        now = time.time()
        with self._lock:
            for task in self._tasks:
                if task.get("next_try", 0) <= now:
                    return dict(task)
        return None

    def complete(self, task_id):
        with self._lock:
            self._tasks = [task for task in self._tasks if task.get("id") != task_id]
            self._save()

    def fail(self, task_id, error=""):
        with self._lock:
            for task in self._tasks:
                if task.get("id") != task_id:
                    continue
                attempts = int(task.get("attempts", 0)) + 1
                task["attempts"] = attempts
                task["last_error"] = str(error)[:300]
                delay = min(self.max_delay, self.base_delay * (2 ** min(attempts - 1, 8)))
                task["next_try"] = time.time() + delay
                if attempts >= self.max_attempts:
                    task["next_try"] = time.time() + self.max_delay
                break
            self._save()

    def seconds_until_ready(self, default=0.5):
        with self._lock:
            if not self._tasks:
                return default
            wait = min(float(task.get("next_try", 0)) for task in self._tasks) - time.time()
        return max(0.05, min(default, wait))

    def __len__(self):
        with self._lock:
            return len(self._tasks)
