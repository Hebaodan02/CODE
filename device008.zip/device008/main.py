#!/usr/bin/env python3
# 日志
import logging
import traceback

import sys
import os

from PyQt5.QtWidgets import QApplication
from PyQt5.QtCore import Qt
        
from window_function import Window_added
from window_function import init_immediate_logger


if __name__ == '__main__':
    init_immediate_logger()
    app = QApplication(sys.argv)
    
    
    app.setQuitOnLastWindowClosed(False)
    window = Window_added()
    window.showFullScreen()
    sys.exit(app.exec_())
