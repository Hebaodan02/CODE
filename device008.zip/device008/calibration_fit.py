def fit_linear_calibration(x_values, y_values, through_origin=False):
    """线性拟合；through_origin=True 时固定截距为 0。"""
    x = [float(value) for value in x_values]
    y = [float(value) for value in y_values]

    if len(x) != len(y):
        raise ValueError("X、Y 数据数量不一致")
    if len(x) < 2:
        raise ValueError("至少需要 2 组有效标定数据")

    if through_origin:
        denominator = sum(value * value for value in x)
        if denominator == 0:
            raise ValueError("X 不能全部为 0")
        slope = sum(xi * yi for xi, yi in zip(x, y)) / denominator
        intercept = 0.0
    else:
        x_mean = sum(x) / len(x)
        y_mean = sum(y) / len(y)
        denominator = sum((value - x_mean) ** 2 for value in x)
        if denominator == 0:
            raise ValueError("X 数据不能全部相同")
        slope = sum((xi - x_mean) * (yi - y_mean) for xi, yi in zip(x, y)) / denominator
        intercept = y_mean - slope * x_mean

    predicted = [slope * value + intercept for value in x]
    residual_sum = sum((actual - fitted) ** 2 for actual, fitted in zip(y, predicted))
    total_sum = sum((actual - sum(y) / len(y)) ** 2 for actual in y)
    r2 = 1.0 if total_sum == 0 and residual_sum == 0 else (
        0.0 if total_sum == 0 else 1.0 - residual_sum / total_sum
    )

    return {
        "slope": slope,
        "intercept": intercept,
        "r2": r2,
        "predicted": predicted,
        "through_origin": bool(through_origin),
    }
