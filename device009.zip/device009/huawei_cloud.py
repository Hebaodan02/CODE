import json
import logging
import os
import re
import ssl
import threading
import time
import hashlib
from datetime import datetime

import paho.mqtt.client as mqtt
from obs import ObsClient
from huaweicloudsdkcore.auth.credentials import BasicCredentials, DerivedCredentials
from huaweicloudsdkcore.region.region import Region
from huaweicloudsdkiotda.v5 import (
    IoTDAClient,
    CreateMessageRequest,
    DeviceMessageRequest,
    CreateCommandRequest,
    DeviceCommandRequest,
    ListDevicesRequest,
    ShowDeviceRequest,
    ShowDeviceShadowRequest,
)

USERNAME = os.getenv("HUAWEI_IOT_USERNAME", '6ae0406ec9429d337f780228_device009')
PASSWORD = os.getenv("HUAWEI_IOT_PASSWORD", '8108b8b4621c33c5360bf516e712337f9be0cb1d3832e794b5976732162882a7')
CLIENT_ID = os.getenv("HUAWEI_IOT_CLIENT_ID", '6ae0406ec9429d337f780228_device009_0_0_2026111906')
DEVICE_ID = os.getenv("HUAWEI_IOT_DEVICE_ID", '6ae0406ec9429d337f780228_device009')
DEVICE_NAME = os.getenv("HUAWEI_IOT_DEVICE_NAME", 'device009')
HOSTNAME = os.getenv("HUAWEI_IOT_HOSTNAME", '298b487fc3.st1.iotda-device.cn-south-1.myhuaweicloud.com')
PORT = int(os.getenv("HUAWEI_IOT_PORT", '8883'))
SERVICE_ID = "service"
CELL_PROPERTY = "cell"
IMAGE_COUNT_PROPERTY = "captured_img_num"

OBS_BUCKET = "firstpoke"
OBS_SERVER = "https://obs.cn-south-1.myhuaweicloud.com"
OBS_AK = os.getenv("HUAWEI_OBS_AK", "HPUA92XXZCWVUSE2TZ4F")
OBS_SK = os.getenv("HUAWEI_OBS_SK", "NqHI7zCG6VG1R1oPair5V71DbW7NAX04IX5Z14KU")
IOTDA_PROJECT_ID = "01a17b3937dd75e6a6c433ee782ef650"
IOTDA_API_ENDPOINT = "https://298b487fc3.st1.iotda-app.cn-south-1.myhuaweicloud.com"
PRODUCT_ID = "6ae0406ec9429d337f780228"

STATUS_WORK = 0
STATUS_CLEAN = 1


def _reason_ok(reason_code):
    return reason_code == 0 or getattr(reason_code, "value", None) == 0 or str(reason_code) == "Success"


def extract_request_id(topic, payload):
    match = re.search(r"(?:^|/)request_id=([^/]+)", topic or "")
    if match:
        return match.group(1)
    value = payload.get("request_id") if isinstance(payload, dict) else None
    return str(value) if value else None


def parse_status_command(payload):
    if not isinstance(payload, dict):
        return None
    command_name = payload.get("command_name") or payload.get("name")
    if command_name not in (None, "set_status", "status_broadcast"):
        return None
    params = payload.get("paras") or payload.get("params") or payload.get("content") or {}
    if isinstance(params, str):
        try:
            params = json.loads(params)
        except (TypeError, ValueError):
            return None
    if not isinstance(params, dict) or "status" not in params:
        return None
    try:
        value = int(params["status"])
    except (TypeError, ValueError):
        return None
    return value if value in (STATUS_WORK, STATUS_CLEAN) else None


class HuaweiCloudUploader:
    def __init__(self):
        self.client = None
        self._connected = False
        self.control_callback = None
        self._connect_event = threading.Event()
        self._stop_event = threading.Event()
        self._connect_thread = None
        self.obs = ObsClient(access_key_id=OBS_AK, secret_access_key=OBS_SK, server=OBS_SERVER)
        credentials = BasicCredentials(OBS_AK, OBS_SK, IOTDA_PROJECT_ID).with_derived_predicate(
            DerivedCredentials.get_default_derived_predicate())
        self.iotda = IoTDAClient.new_builder().with_credentials(credentials).with_region(
            Region("cn-south-1", IOTDA_API_ENDPOINT)).build()

    def set_control_callback(self, callback):
        self.control_callback = callback

    def connect(self):
        if self._connect_thread and self._connect_thread.is_alive():
            return self._connected
        self._stop_event.clear()
        self._connect_event.clear()
        try:
            self.client = mqtt.Client(
                mqtt.CallbackAPIVersion.VERSION2,
                client_id=CLIENT_ID,
                protocol=mqtt.MQTTv5,
            )
        except AttributeError:
            self.client = mqtt.Client(client_id=CLIENT_ID, protocol=mqtt.MQTTv5)
        self.client.username_pw_set(USERNAME, PASSWORD)
        self.client.tls_set(cert_reqs=ssl.CERT_REQUIRED, tls_version=ssl.PROTOCOL_TLS_CLIENT)
        self.client.tls_insecure_set(False)
        self.client.reconnect_delay_set(min_delay=1, max_delay=30)

        def on_connect(client, userdata, flags, reason_code, properties=None):
            self._connected = _reason_ok(reason_code)
            self._connect_event.set()
            if self._connected:
                client.subscribe(f"$oc/devices/{DEVICE_ID}/sys/commands/#", qos=1)
                client.subscribe(f"$oc/devices/{DEVICE_ID}/sys/messages/down", qos=1)
                logging.info("[华为云] %s 在线", DEVICE_NAME)
            else:
                logging.warning("[华为云] %s 连接失败", DEVICE_NAME)

        def on_disconnect(client, userdata, disconnect_flags, reason_code, properties=None):
            self._connected = False
            logging.warning("[华为云] %s 离线", DEVICE_NAME)

        def on_message(client, userdata, message):
            request_id = None
            result_code = 1
            try:
                payload = json.loads(message.payload.decode("utf-8"))
                request_id = extract_request_id(message.topic, payload)
                status = parse_status_command(payload)
                if status is not None and self.control_callback:
                    self.control_callback("status", status)
                    result_code = 0
            except Exception as exc:
                logging.warning("[华为云] 下行消息解析失败: %s", exc)
            finally:
                if request_id:
                    topic = f"$oc/devices/{DEVICE_ID}/sys/commands/response/request_id={request_id}"
                    body = {
                        "result_code": result_code,
                        "response_name": "success" if result_code == 0 else "invalid_command",
                        "paras": {},
                    }
                    try:
                        client.publish(topic, json.dumps(body, ensure_ascii=False), qos=1)
                    except Exception as exc:
                        logging.warning("[华为云] 命令应答失败 request_id=%s: %s", request_id, exc)

        self.client.on_connect = on_connect
        self.client.on_disconnect = on_disconnect
        self.client.on_message = on_message
        self.client.loop_start()

        def connect_until_ready():
            delay = 1
            while not self._stop_event.is_set() and not self._connected:
                try:
                    self.client.connect(HOSTNAME, PORT, keepalive=60)
                    return
                except Exception as exc:
                    logging.warning("[华为云] 连接失败，%s秒后重试: %s", delay, exc)
                    self._stop_event.wait(delay)
                    delay = min(delay * 2, 30)

        self._connect_thread = threading.Thread(target=connect_until_ready, daemon=True)
        self._connect_thread.start()
        self._connect_event.wait(10)
        return self._connected

    def _report(self, properties):
        if not self._connected or self.client is None:
            return False
        payload = {
            "services": [{
                "service_id": SERVICE_ID,
                "properties": properties,
            }]
        }
        topic = f"$oc/devices/{DEVICE_ID}/sys/properties/report"
        info = self.client.publish(
            topic,
            json.dumps(payload, ensure_ascii=False, separators=(",", ":")),
            qos=1,
        )
        if info.rc != mqtt.MQTT_ERR_SUCCESS:
            return False
        info.wait_for_publish(timeout=10)
        return info.is_published()
    
    def publish(self, img_num, cell_count):
        ok = self._report({
            IMAGE_COUNT_PROPERTY: int(img_num),
            CELL_PROPERTY: float(cell_count),
        })
        if ok:
            logging.info("[华为云] 数值上报成功：图片数=%s", int(img_num))
        else:
            logging.warning("[华为云] 数值上报失败")
        return ok
    
    def upload_image(self, local_image_path):
        date_path = datetime.now().strftime("%Y/%m/%d")
        object_key = f"devices/{DEVICE_NAME}/{date_path}/{os.path.basename(local_image_path)}"
        try:
            result = self.obs.putFile(OBS_BUCKET, object_key, local_image_path)
            if result.status >= 300:
                return None
            meta = self.obs.getObjectMetadata(OBS_BUCKET, object_key)
            if meta.status >= 300:
                return None
            local_size = os.path.getsize(local_image_path)
            remote_size = getattr(meta.body, "contentLength", None) if getattr(meta, "body", None) else None
            if remote_size is not None and int(remote_size) != local_size:
                logging.warning("[OBS] 文件大小校验失败: %s", os.path.basename(local_image_path))
                return None
            logging.info("[OBS] 图片上传成功：%s", os.path.basename(local_image_path))
            return object_key
        except Exception as exc:
            logging.warning("[OBS] 上传失败 %s: %s", os.path.basename(local_image_path), exc)
            return None

    def publish_with_image(self, img_num, cell_count, object_key):
        ok = self._report({
            IMAGE_COUNT_PROPERTY: int(img_num),
            CELL_PROPERTY: float(cell_count),
            "image_key": str(object_key),
        })
        if ok:
            logging.info("[华为云] 图片引用上报成功")
        else:
            logging.warning("[华为云] 图片引用上报失败")
        return ok

    def publish_status(self, status_value):
        ok = self._report({"status": int(status_value)})
        if ok:
            logging.info("[华为云] 状态上报成功：status=%s", int(status_value))
        else:
            logging.warning("[华为云] 状态上报失败")
        return ok

    def broadcast_status(self, status_value):
        devices = []
        marker = None
        while True:
            response = self.iotda.list_devices(ListDevicesRequest(
                product_id=PRODUCT_ID,
                limit=50,
                marker=marker,
            ))
            page_devices = response.devices or []
            for device in page_devices:
                if (device.device_name and device.device_name.startswith("device") and
                        device.device_id != DEVICE_ID):
                    devices.append(device)
            if len(page_devices) < 50:
                break
            marker = response.page.marker if response.page else None
            if not marker:
                break

        delivered = []
        for device in devices:
            body = DeviceCommandRequest(
                service_id=SERVICE_ID,
                command_name="set_status",
                paras={"status": int(status_value)},
            )
            try:
                response = self.iotda.create_command(CreateCommandRequest(
                    device_id=device.device_id,
                    body=body,
                ))
                if response.command_id and not response.error_code:
                    delivered.append(device.device_name)
            except Exception as exc:
                logging.warning("[华为云] 状态下发失败 %s: %s", device.device_name, exc)
        logging.info("[华为云] 状态下发完成：成功%s台", len(delivered))
        return delivered

    def set_status_via_http(self, status_value):
        return True

    def sync_status_from_online_devices(self, stop_check=None):
        online_status = []
        marker = None
        while True:
            response = self.iotda.list_devices(ListDevicesRequest(
                product_id=PRODUCT_ID, limit=50, marker=marker))
            devices = response.devices or []
            for device in devices:
                if stop_check and stop_check():
                    return None
                if (not device.device_name or not device.device_name.startswith("device") or
                        device.device_id == DEVICE_ID):
                    continue
                try:
                    info = self.iotda.show_device(ShowDeviceRequest(device_id=device.device_id))
                    if str(info.status).upper() != "ONLINE":
                        continue
                    shadow = self.iotda.show_device_shadow(
                        ShowDeviceShadowRequest(device_id=device.device_id))
                    for service in shadow.shadow or []:
                        if service.service_id != SERVICE_ID or not service.reported:
                            continue
                        value = (service.reported.properties or {}).get("status")
                        if int(value) in (STATUS_WORK, STATUS_CLEAN):
                            online_status.append(int(value))
                except Exception as exc:
                    logging.warning("[华为云] 启动状态查询失败 %s: %s", device.device_name, exc)
            if len(devices) < 50:
                break
            marker = response.page.marker if response.page else None
            if not marker:
                break
        if not online_status:
            return None
        return STATUS_CLEAN if online_status.count(STATUS_CLEAN) > online_status.count(STATUS_WORK) else STATUS_WORK

    def disconnect(self):
        self._stop_event.set()
        if self.client:
            try:
                self.client.disconnect()
                time.sleep(0.2)
                self.client.loop_stop()
            except Exception:
                pass
        self._connected = False
        try:
            self.obs.close()
        except Exception:
            pass
