import cv2
import numpy as np
import math

font = cv2.FONT_HERSHEY_SIMPLEX
font_scale = 0.35
font_thickness = 1
cell_standard_Area = 80     # 单个体细胞的标准面积

# 读取中文路径下的图像
def cv_imread(file_path):
    cv_img = cv2.imdecode(np.fromfile(file_path, dtype=np.uint8), -1)
    return cv_img

def thresh_callback(x):
    pass

# 根据轮廓的位置信息排序
def sort_contours(contour):
    x, y, _, _ = cv2.boundingRect(contour)
    return y, x

# 根据轮廓的位置信息和最小外接圆的圆心位置排序
def calculate_circle_center(contour):
    (x, y), radius = cv2.minEnclosingCircle(contour)
    return (int(x), int(y))

# 定义计算距离的函数
def calculate_distance(c1, c2):
    M1 = cv2.moments(c1)
    M2 = cv2.moments(c2)
    if M1["m00"] < 1e-6:
        M1["m00"] = 1.0

    if M2["m00"] < 1e-6:
        M2["m00"] = 1.0

    c1_center = (int(M1["m10"] / M1["m00"]), int(M1["m01"] / M1["m00"]))
    c2_center = (int(M2["m10"] / M2["m00"]), int(M2["m01"] / M2["m00"]))
    distance = np.sqrt((c1_center[0] - c2_center[0])**2 + (c1_center[1] - c2_center[1])**2)
    return distance

# 定义 sigmoid 函数
def sigmoid_normalize(img):
    equalized_img = cv2.equalizeHist(img)
    equalized_img[equalized_img < 50] = 0
    equalized_img = cv2.equalizeHist(equalized_img)
    result = equalized_img
    return result

# 粘连细胞细分，输入取模后图像以及掩膜图像
def cell_division(img, mask):
    # 转化成单通道
    img = img[:,:,1]
    # 归一化灰度图像
    normalized_img = sigmoid_normalize(img)
    # 对归一化后图像重新进行阈值分割
    _, binary_img = cv2.threshold(normalized_img, 200, 255, cv2.THRESH_BINARY)
    return binary_img

# 在图像中标记轮廓（只能单个轮廓），返回标记好的图像
# 传入的轮廓不能为空！
# param: img        待标记的图像
# param: contours   轮廓数组
# param: num        细胞序号
# param: cut_num    细胞团包含的细胞数（单个细胞则标1， 多个细胞则标实际的个数）
def marker_contour(img, contour, num, cut_num):
    # 计算最小外接圆圆心坐标
    (x, y), radius = cv2.minEnclosingCircle(contour)
    # 标记轮廓
    cv2.drawContours(img, [contour], contourIdx=-1, color=(0, 0, 255), thickness=1)

    # 计算文字框尺寸
    # text = str(int(all_areas[i])) # 输出第n个的面积
    if cut_num == 1:
        text = str(num) # 输出第n个的序号
    else:
        text = '({}){}'.format(cut_num, num)  # 输出第n个的序号
    text_size, _ = cv2.getTextSize(text, font, font_scale, font_thickness)
    text_width, text_height = text_size
    # 确定标记位置，避免文字越界
    text_x = max(0, min(x, img.shape[1] - text_width))
    text_y = max(0 + text_height, min(y, img.shape[0] - text_height))
    # 标记文字
    cv2.putText(img, text, (int(text_x), int(text_y)), font, font_scale, (0, 255, 255), font_thickness)

    return img

def cell_count(img, threshold):
    num = 0     # 统计细胞个数
    img_copy = img.copy()

    img_copy[:, :, 0] = 0
    img_copy[:, :, 2] = 0

    gray = cv2.cvtColor(img_copy, cv2.COLOR_BGR2GRAY)

    _, thresh1 = cv2.threshold(gray, threshold, 255, cv2.THRESH_BINARY)  # 根据亮度调整阈值

    '''背景提取(轮廓)'''
    kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3))  # 得到卷积核
    sure_bg = cv2.dilate(thresh1, kernel, iterations=1)  # 膨胀，完善背景区域
    sure_fg = cv2.erode(thresh1, kernel, iterations=1)  # 腐蚀，完善前景区域

    '''前景提取(荧光细胞)'''
    dist_transform = cv2.distanceTransform(thresh1, cv2.DIST_L2, 5)  # 距离变换
    cv2.normalize(dist_transform, dist_transform, 0, 255, cv2.NORM_MINMAX)  # 距离归一化(0~1)计算

    _, thresh2 = cv2.threshold(dist_transform, threshold-20, 255, cv2.THRESH_BINARY)  # 根据亮度调整阈值

    sure_fg = thresh2.astype(np.uint8)          # 转化成uint8格式，方便做subtract减法操作
    gradient = cv2.subtract(sure_bg, sure_fg)   # 梯度，背景减去前景，提取背景轮廓线

    '''分水岭算法——标记区域'''
    ret, markers = cv2.connectedComponents(sure_fg)     # 掩膜板标记，给每个细胞单独分配一个唯一标签值
    markers = markers + 1                               # 所有像素值加1，确保背景是1
    markers[gradient == 255] = 0                        # subtract出来的大致轮廓区域设置为0

    ''' markers可视化 '''
    markers_copy = markers.copy()
    markers_copy[markers == 0] = 150    # 灰色表示边界
    markers_copy[markers == 1] = 0      # 黑色表示背景
    markers_copy[markers > 1] = 255     # 白色表示前景
    # markers_copy = np.uint8(markers_copy)

    # 执行分水岭算法提取轮廓
    result = cv2.watershed(img, markers)
    result = result.astype(np.uint8)  # np.uint8会将超出0和255的值自动截断为0或者255

    # 使用白色标记分割轮廓结果
    marker_result = np.zeros_like(img[:, :, 1])
    marker_result[result == 255] = 255

    # 查找轮廓
    contours, _ = cv2.findContours(marker_result, cv2.RETR_LIST, cv2.CHAIN_APPROX_NONE)

    # 根据轮廓的位置信息和距离排序
    contours = sorted(contours, key=lambda x: calculate_circle_center(x))  # 按照最小外接圆圆心位置排序

    sorted_contours = [contours[0]]
    for contour in contours: # cv2.findContours会计算顺时针轮廓和逆时针轮廓，这里需要剔除重复的轮廓
        if calculate_distance(contour, sorted_contours[-1]) > 2:  # 设定距离阈值为 2
            sorted_contours.append(contour)

    # 轮廓计数变量，保存细分之后的轮廓以及面积
    all_contours = []
    all_areas = np.zeros(8000)

    # 获取屏幕分辨率
    screen_width, screen_height = 1920, 1080  # 假设屏幕分辨率为1920x1080
    ratio = 1.8

    for i, cont in enumerate(sorted_contours):
        # 计算轮廓的面积
        S = cv2.contourArea(cont)
        if S > 2000:  # 轮廓面积太大，是无意义的轮廓
            continue
        if S > cell_standard_Area * 1.5:

            cut_num = math.ceil(S / cell_standard_Area)    # 按照标准体细胞面积计算分割后的细胞个数，结果向上取整
            for j in range(cut_num):
                all_contours.append(list(cont))     # 粘连细胞按面积分割后的轮廓只记整个细胞团的
                all_areas[num] = S  # 粘连细胞按面积分割后的面积也只记整个细胞团的
                # 计数+1
                num = num + 1   # 粘连细胞按面积分割后的数量都要累加进总个数
                # print(num)
            # 标记轮廓(多个细胞粘连的只标记一个轮廓，在细胞数后面括号显示里面有多少细胞)
            img_copy = marker_contour(img_copy, cont, num, cut_num)

            pass
            # # 掩膜中轮廓填充实心
            # mask = np.zeros_like(img, dtype=np.uint8)
            # cv2.drawContours(mask, [cont], -1, (255, 255, 255), thickness=cv2.FILLED)
            #
            # # 获取取模结果
            # res = cv2.bitwise_and(img, mask)
            # res = cv2.blur(res, (3, 3))  # 均值滤波处理，避免因为个别像素亮度太高导致过度细分
            #
            # # 细胞轮廓细分
            # new_img = cell_division(res, mask)
            # new_contours, hierarchy = cv2.findContours(new_img, cv2.RETR_LIST, cv2.CHAIN_APPROX_NONE)
            #
            # # 按照最小外接圆圆心位置排序,避免重复计数
            # new_contours = sorted(new_contours, key=lambda x: calculate_circle_center(x))
            #
            # # 检测出来轮廓为空，则直接按原来轮廓标记
            # if len(hierarchy[0]) == 0:
            #     # 记录轮廓和面积
            #     all_contours.append(list(cont))
            #     all_areas[num] = S
            #     # 计数+1
            #     num = num + 1
            #     # 标记轮廓
            #     img_copy = marker_contour(img_copy, cont, num)
            # else:  # 不为空则按照新的轮廓数量进行标记
            #     # 轮廓排序，剔除重复轮廓
            #     new_sorted_contours = []
            #     new_sorted_contours.append(new_contours[0])
            #
            #     for contour in new_contours:
            #         if calculate_distance(contour, new_sorted_contours[-1]) > 2:  # 设定距离阈值为 2
            #             new_sorted_contours.append(contour)
            #
            #     if len(hierarchy[0]) == 1:  # 还是检测出一个，那就用原来的轮廓
            #         all_contours.append(list(cont))
            #         all_areas[num] = cv2.contourArea(cont)
            #         # 计数+1
            #         num = num + 1
            #         # 标记轮廓
            #         img_copy = marker_contour(img_copy, cont, num)
            #     else:
            #         for new_cont in new_sorted_contours:
            #             # 记录新细分的轮廓和面积
            #             all_contours.append(list(new_cont))
            #             all_areas[num] = cv2.contourArea(new_cont)
            #             # 计数+1
            #             num = num + 1
            #             # 标记轮廓
            #             img_copy = marker_contour(img_copy, new_cont, num)

        # 正常尺寸轮廓
        else:
            # 记录轮廓和面积
            all_contours.append(list(cont))
            all_areas[num] = S
            # 计数+1
            num = num + 1
            # 标记轮廓
            img_copy = marker_contour(img_copy, cont, num, 1)
    return num, img_copy

# 计数阈值反馈函数，实时返回阈值修改之后的效果图
def Threshold_config(img, threshold):
    img_copy = img.copy()

    img_copy[:, :, 0] = 0
    img_copy[:, :, 2] = 0
    gray = cv2.cvtColor(img_copy, cv2.COLOR_BGR2GRAY)

    _, thresh1 = cv2.threshold(gray, threshold, 255, cv2.THRESH_BINARY)  # 根据亮度调整阈值

    '''背景提取(轮廓)'''
    kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (3, 3))  # 得到卷积核
    sure_bg = cv2.dilate(thresh1, kernel, iterations=1)  # 膨胀，完善背景区域
    sure_fg = cv2.erode(thresh1, kernel, iterations=1)  # 腐蚀，完善前景区域

    '''前景提取(荧光细胞)'''
    dist_transform = cv2.distanceTransform(thresh1, cv2.DIST_L2, 5)  # 距离变换
    cv2.normalize(dist_transform, dist_transform, 0, 255, cv2.NORM_MINMAX)  # 距离归一化(0~1)计算

    _, thresh2 = cv2.threshold(dist_transform, threshold, 255, cv2.THRESH_BINARY)  # 根据亮度调整阈值

    return thresh2

if __name__ == '__main__':
    # 读取原图
    img = cv_imread("1122.jpg")
    num, new_img = cell_count(img, 55)

    # img1, img2 = Threshold_config(img, 50)

    print(num)
    cv2.imshow('new_img', new_img)
    cv2.waitKey()
    cv2.destroyAllWindows()
