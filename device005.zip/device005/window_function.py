# 日志
import logging
from logging.handlers import RotatingFileHandler
import shutil
import traceback
import json
import csv

# 内存占用率相关
import psutil
import os
import gc

# QT相关
from datetime import datetime
from functools import partial
from PyQt5 import QtCore, QtWidgets, QtGui
from PyQt5.QtGui import QIcon, QImage, QPixmap, QPainter, QBrush, QColor, QPen, QFont
from PyQt5.QtWidgets import QWidget, QMainWindow, QMessageBox, QLabel, QVBoxLayout, QSizePolicy, QHBoxLayout, \
    QPushButton, QTableWidgetItem, QTableWidgetSelectionRange, QAbstractItemView, QInputDialog, QLineEdit
from PyQt5.QtCore import QTimer, Qt, QMargins, QPointF, QThread, pyqtSignal, pyqtSlot, QEventLoop, QCoreApplication, \
    QMutex, QMutexLocker, QWaitCondition
from PyQt5.QtChart import QChart, QChartView, QLineSeries, QValueAxis, QScatterSeries

# 上位机界面
from tiaozheng import Ui_MainWindow

# 其他
import serial
import serial.tools.list_ports
import cv2
import time
import pandas as pd
import os
import math
import threading
import numpy as np
from Thresh_config import cell_count, Threshold_config
import queue
import sys

# 细胞计数算法（DoG 圆顶匹配，针对低对比度弥散细胞图像）
from new_dog import DogCellCounter

# OneNET 云平台（上传数字+图片+状态广播）
import onenet_uploader_plus as onenet_uploader
from onenet_uploader_plus import OneNETUploader
from onenet_pull_template import CONFIG as ONENET_CONFIG


def get_app_dir():
    """返回程序所在目录：打包后取可执行文件所在目录，开发环境取源码目录。"""
    if getattr(sys, 'frozen', False):
        return os.path.dirname(sys.executable)
    return os.path.dirname(os.path.abspath(__file__))


def ensure_data_dirs():
    """确保运行时数据目录存在（打包后位于可执行文件同级目录）。"""
    base = get_app_dir()
    for name in ('scc_img', 'focus', 'captured'):
        os.makedirs(os.path.join(base, name), exist_ok=True)

# import detect_cell


# 功能码
# 0x01 (自动对焦部分) 回零与定点移动
# 0x02 (自动对焦部分) 微调
# 0x03 (计数测试部分) 初次进样
# 0x04 (计数测试部分) 微泵进样
# 0x05 (计数测试部分) 清洗管路

# 日志初始化
def init_immediate_logger(log_file: str = "app.log"):
    """
    初始化即时写入的日志配置：
    1. 关闭缓冲区，每次写入立即刷到文件
    2. 保持线程安全
    3. 支持多线程直接调用logging.xxx()
    """
    # 清空已有Handler（避免重复配置）
    root_logger = logging.getLogger()
    root_logger.handlers.clear()

    # 日志格式：包含线程名、时间、级别、内容
    log_format = logging.Formatter(
        '%(asctime)s - %(threadName)s - %(levelname)s - %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'  # 精确到微秒，便于排查时序问题
    )

    # 配置文件Handler：关键是设置flush=True + 无缓冲
    file_handler = RotatingFileHandler(
        log_file,
        maxBytes=10 * 1024 * 1024,  # 10MB滚动
        backupCount=5,
        encoding='utf-8',
        delay=False  # 立即打开文件，不延迟
    )
    file_handler.setFormatter(log_format)
    file_handler.setLevel(logging.DEBUG)

    # # 核心：关闭缓冲区，每次写入立即刷新
    # file_handler.flush = True  # 强制刷新
    # file_handler.stream.reconfigure(line_buffering=True)  # Python 3.7+ 生效，行缓冲
    #
    # # 控制台Handler（可选，调试用）
    # console_handler = logging.StreamHandler()
    # console_handler.setFormatter(log_format)
    # console_handler.setLevel(logging.DEBUG)
    # console_handler.flush = True

    # 全局日志配置
    root_logger.setLevel(logging.DEBUG)
    root_logger.addHandler(file_handler)
    # root_logger.addHandler(console_handler)

    # 配置独立的流量计日志记录器
    flow_logger = logging.getLogger('flowmeter')
    flow_logger.handlers.clear()
    flow_logger.setLevel(logging.DEBUG)
    flow_logger.propagate = False

    flow_file_handler = RotatingFileHandler(
        os.path.join(get_app_dir(), 'flowmeter.log'),
        maxBytes=10 * 1024 * 1024,
        backupCount=5,
        encoding='utf-8',
        delay=False
    )
    flow_file_handler.setFormatter(log_format)
    flow_file_handler.setLevel(logging.DEBUG)
    flow_logger.addHandler(flow_file_handler)

    # 禁用logging的内部线程池（避免延迟）
    logging.raiseExceptions = True


class QtLogBridge(QtCore.QObject, logging.Handler):
    """把 logging 记录转发为 Qt 信号，供计数测试页右侧 listWidget 滚动显示。"""
    log_signal = pyqtSignal(str, int)  # (消息文本, 日志级别数值)

    def __init__(self, level=logging.NOTSET):
        QtCore.QObject.__init__(self)
        logging.Handler.__init__(self, level=level)

    def emit(self, record):
        msg = self.format(record)
        self.log_signal.emit(msg, record.levelno)


'''按钮双击类'''
class DoubleClickButton(QPushButton):
    def __init__(self, image_folder, file_name, parent=None):
        super().__init__(parent)
        self.image_folder = image_folder
        self.file_name = file_name
        self.setFixedSize(208, 117)  # 图片的固定尺寸大小，勿动！！！
        self.setIcon(QIcon(os.path.join(image_folder, file_name)))
        self.setObjectName(file_name)
        self.setIconSize(self.size())

    def mouseDoubleClickEvent(self, event):
        if event.button() == Qt.LeftButton:  # 确保是左键双击
            self.on_button_double_click()

    def on_button_double_click(self):
        button_name = self.objectName()
        logging.info(f"Double-clicked on {button_name}")

        msg_box = QMessageBox(self)
        msg_box.setWindowTitle(f"{button_name}")
        image_path = os.path.join(self.image_folder, button_name)
        pixmap = QPixmap(image_path)
        pixmap = pixmap.scaled(800, 500, aspectRatioMode=1)
        msg_box.setIconPixmap(pixmap)
        msg_box.exec_()


"""折线绘图类"""
class ChartView(QChartView):
    def __init__(self, chart, tableWidget):
        super().__init__(chart)
        self.tableWidget = tableWidget

    def mousePressEvent(self, event):
        if event.button() == Qt.LeftButton:
            pos = event.pos()
            series = self.chart().series()[1]  # 假设读取散点图的所有数据点坐标
            # 遍历所有点，检查点击位置是否接近某个点（按像素距离判断，不依赖轴范围）
            for i in range(series.count()):
                point = series.at(i)
                point_pos = self.chart().mapToPosition(point)  # 数据点转为图表像素坐标
                dist = math.hypot(point_pos.x() - pos.x(), point_pos.y() - pos.y())
                if dist <= 10:  # 命中半径（像素），略大于散点半径，方便点击
                    logging.info(f"Clicked on point: ({point.x()}, {point.y()})")
                    self.draw_point(point)

                    '''-----------高亮显示表格中对应的数据行，并且自动滚动到其对应位置-------------'''
                    self.tableWidget.clearSelection()  # 清除任何已有选中
                    self.tableWidget.setRangeSelected(
                        QTableWidgetSelectionRange(int(point.x()) - 1, 0, int(point.x()) - 1, 7), True)
                    # 滚动到该单元格
                    item = self.tableWidget.item(int(point.x()) - 1, 0)
                    self.tableWidget.scrollToItem(item, QAbstractItemView.EnsureVisible)
                    '''-----------------------------------'''

                    break

    def draw_point(self, point):
        scatter_point = self.chart().series()[2]
        scatter_point.clear()
        scatter_point.append(point.x(), point.y())  # 增加新数据


"""串口线程"""
class SerialThread(QThread):
    # 定义信号，传递串口接收到的数据
    # error_signal = pyqtSignal(str)      # 通知主线程弹窗串口错误信息， 这里需要connect的函数还没写，该函数输入需要警报的str，然后直接弹窗就好，所以可以复用
    # signal_receiveData = pyqtSignal(bytes)  # 接收数据信号
    signal_sendData = pyqtSignal(list)  # 发送数据信号
    # capture_img = pyqtSignal()          # 通知主线程拍照信号
    signal_serialConnect = pyqtSignal(str)  # 连接指定串口信号
    signal_serialLED = pyqtSignal(str)  # 通知主线程控制状态LED亮灭信号

    # 帧格式定义
    FRAME_HEADER = 0xFF  # 帧头
    FRAME_TAIL = 0xFE    # 帧尾
    MIN_FRAME_LENGTH = 4  # 最小帧长度：帧头(1) + 长度(1) + 指令(1) + 帧尾(1)

    def __init__(self, port='/dev/ttyS3', baudrate=115200):
        super().__init__()
        self.port = port
        self.baudrate = baudrate
        self.ser = None
        self.dataBuffer = []  # 累积接收缓冲区（用于帧解析）
        self.dataBuffer1 = []  # 数据缓存区（流量计线程）

        self.mutex_Receive = QMutex()  # 线程间互斥锁
        self.mutex_Send = QMutex()  # 线程间互斥锁
        self.receive_cond = QWaitCondition()  # 接收条件变量（应答到达时唤醒等待线程）
        self.signal_sendData.connect(self.send_data)
        self.signal_serialConnect.connect(self.com_connect)

        # 发送队列
        self.Send_queue = queue.Queue(maxsize=0)  # 队列上限无穷多

        # 接收字典，键=指令序号，值=应答数据帧
        self.Receive_data = {}

    def run(self):
        self.loop = QEventLoop()  # 创建事件循环

        timer_receive = QTimer()  # 使用定时器来定期接收串口数据
        timer_receive.timeout.connect(self.receive_serial)
        timer_receive.start(20)  # 每20ms触发一次

        timer_send = QTimer()  # 使用定时器来定期发送串口数据
        timer_send.timeout.connect(self.send_serial)  # 定时器触发时检查串口
        timer_send.start(100)  # 每100ms触发一次

        self.loop.exec_()  # 启动事件循环

    def stop(self):
        """退出清理（非阻塞）：关闭串口并退出事件循环。不调用 wait，避免阻塞主线程。"""
        try:
            if self.ser and self.ser.is_open:
                self.ser.close()  # 释放串口资源
        except Exception as e:
            logging.error(f"关闭串口失败: {e}")
        if getattr(self, 'loop', None):
            self.loop.quit()  # 退出事件循环

    # 定时检查串口发送/接收缓冲队列
    def receive_serial(self):
        # 接收数据帧
        try:
            if self.ser and self.ser.is_open:
                current_size = self.ser.inWaiting()
                if current_size != 0:  # 缓冲区有数据
                    # 读取所有可用数据到累积缓冲区
                    data = self.ser.read(current_size)
                    # 添加数据到缓冲区时需要加锁
                    with QMutexLocker(self.mutex_Receive):
                        self.dataBuffer.extend(data)
                    
                    # 尝试解析完整帧
                    self.parse_frames()
        except serial.SerialException as e:
            logging.error('check_serial接收数据帧报错: {}'.format(e))

    def parse_frames(self):
        """
        解析累积缓冲区中的完整帧
        帧格式：0xFF [长度] [指令序号] [参数...] 0xFE
        其中长度字段表示整个帧的字节数（包括帧头和帧尾），单字节长度范围: 4-255
        """
        with QMutexLocker(self.mutex_Receive):
            while len(self.dataBuffer) >= self.MIN_FRAME_LENGTH:
                # 查找帧头位置
                try:
                    header_index = self.dataBuffer.index(self.FRAME_HEADER)
                except ValueError:
                    # 没有找到帧头，清空缓冲区
                    self.dataBuffer = []
                    return

                # 如果帧头不在起始位置，丢弃前面的无效数据
                if header_index > 0:
                    logging.warning(f"丢弃无效数据：{bytes(self.dataBuffer[:header_index]).hex(sep=' ')}")
                    self.dataBuffer = self.dataBuffer[header_index:]
                    continue

                # 检查是否有足够的数据读取长度字段
                if len(self.dataBuffer) < 3:  # 帧头(1) + 长度(1) + 至少1个字节
                    return  # 数据不够，等待更多数据

                # 解析帧长度（单字节）
                frame_length = self.dataBuffer[1]

                # 验证长度是否合理（单字节长度范围：4-255）
                if frame_length < self.MIN_FRAME_LENGTH or frame_length > 255:
                    logging.warning(f"无效的帧长度: {frame_length}，丢弃帧头")
                    self.dataBuffer = self.dataBuffer[1:]
                    continue

                # 检查是否有完整的帧数据
                if len(self.dataBuffer) < frame_length:
                    return  # 数据不够，等待更多数据

                # 提取完整帧
                frame = bytes(self.dataBuffer[:frame_length])

                # 验证帧尾
                if frame[-1] != self.FRAME_TAIL:
                    # 帧尾不匹配：以帧头开头、frame_length 长的这块不是合法帧。
                    # 稳健重同步：找到下一个「长度合理且帧尾正确」的完整帧再继续；
                    # 而不是只删除 1 字节帧头——否则坏块里残留的半帧（如 0x0D 0x06 ...）
                    # 会被下一轮当作「帧头不在起始位」整段丢弃，导致应答（如 0x06 微泵进样）丢失。
                    logging.warning(f"帧尾不匹配，期望0xFE，实际{hex(frame[-1])}，重同步到下一合法帧")
                    rest = self.dataBuffer[1:]
                    new_head = None
                    idx = 0
                    while True:
                        try:
                            j = rest.index(self.FRAME_HEADER, idx)
                        except ValueError:
                            break
                        if j + 2 > len(rest):  # 剩余不足 帧头(1)+长度(1)+1字节
                            break
                        cand_len = rest[j + 1]
                        if (self.MIN_FRAME_LENGTH <= cand_len <= 255
                                and j + cand_len <= len(rest)
                                and rest[j + cand_len - 1] == self.FRAME_TAIL):
                            new_head = j
                            break
                        idx = j + 1
                    if new_head is not None:
                        # 丢弃坏块（坏帧头到新合法帧头之间），从新帧头继续
                        self.dataBuffer = rest[new_head:]
                    else:
                        # 没有可恢复的帧：剩余为残缺半帧，清空等待下位机重发
                        logging.warning(f"帧尾不匹配后未找到可恢复帧，清空残留 {len(rest)} 字节")
                        self.dataBuffer = []
                    continue

                # 帧解析成功（指令序号在第3字节，索引为2）
                cmd = frame[2]  # 第3字节是指令序号
                self.Receive_data[cmd] = (frame, time.time())  # 带时间戳存储
                logging.info(f"接收完整帧：指令序号{cmd}，长度{frame_length}，数据{frame.hex(sep=' ').upper()}")
                # print(f"[{time.time():.3f}] 串口接收：指令 0x{cmd:02X}，帧长度: {frame_length}")

                # 唤醒所有等待该指令应答的线程（在持锁状态下调用，符合 QWaitCondition 规范）
                self.receive_cond.wakeAll()

                # 移除已解析的帧
                self.dataBuffer = self.dataBuffer[frame_length:]

    def parse_frames_legacy(self):
        """
        兼容旧版协议的帧解析（无长度字段）
        帧格式：0xFF [指令序号] [参数...] 0xFE
        用于向后兼容
        """
        with QMutexLocker(self.mutex_Receive):
            while len(self.dataBuffer) >= 3:  # 最小帧长度：帧头(1) + 指令(1) + 帧尾(1)
                # 查找帧头位置
                try:
                    header_index = self.dataBuffer.index(self.FRAME_HEADER)
                except ValueError:
                    self.dataBuffer = []
                    return

                if header_index > 0:
                    logging.warning(f"丢弃无效数据：{bytes(self.dataBuffer[:header_index]).hex(sep=' ')}")
                    self.dataBuffer = self.dataBuffer[header_index:]
                    continue

                # 查找帧尾位置
                try:
                    tail_index = self.dataBuffer.index(self.FRAME_TAIL, header_index + 1)
                except ValueError:
                    return  # 没有找到帧尾，等待更多数据

                # 提取完整帧
                frame_length = tail_index - header_index + 1
                frame = bytes(self.dataBuffer[header_index:tail_index + 1])

                # 验证帧长度
                if frame_length < 3:
                    logging.warning(f"帧长度过短: {frame_length}")
                    self.dataBuffer = self.dataBuffer[header_index + 1:]
                    continue

                cmd = frame[1]  # 第2字节是指令序号
                self.Receive_data[cmd] = (frame, time.time())
                logging.info(f"接收完整帧(旧协议)：指令序号{cmd}，长度{frame_length}，数据{frame.hex(sep=' ').upper()}")

                # 唤醒所有等待该指令应答的线程
                self.receive_cond.wakeAll()

                # 移除已解析的帧
                self.dataBuffer = self.dataBuffer[tail_index + 1:]

    def send_serial(self):
        # 发送数据帧
        try:
            with QMutexLocker(self.mutex_Send):
                if not self.Send_queue.empty():
                    data_waitForSend = self.Send_queue.get(block=False)
                    if self.ser and self.ser.is_open:
                        write_start = time.time()
                        bytes_written = self.ser.write(bytes(data_waitForSend))
                        write_end = time.time()
                        # print(f"[{write_end:.3f}] 串口实际写入：{bytes(data_waitForSend).hex(sep=' ').upper()}，写入字节数: {bytes_written}，耗时: {(write_end - write_start)*1000:.2f}ms")
                        logging.debug(f"发送数据：{bytes(data_waitForSend).hex(sep=' ').upper()}")
        except Exception as e:
            logging.error('check_serial发送数据帧报错: {}'.format(e))

    # 串口连接
    @pyqtSlot(str)
    def com_connect(self, port):
        try:
            self.ser = serial.Serial(port, self.baudrate, timeout=None)
            self.signal_serialLED.emit('serial on')  # 激活首页串口LED
            logging.info('串口{}已连接！'.format(port))
        except Exception as e:
            logging.error(f"串口打开失败：{e}")
            data = '串口打开失败！'
            # self.error_signal.emit(data)  # 发送信号，主线程激活 串口打开失败 弹窗
            self.signal_serialLED.emit('serial off')  # 取消激活首页串口LED
            return

    def com_isconnect(self):
        try:
            if self.ser is None:
                return False
            elif self.ser.is_open:
                return True
            else:
                return False
        except serial.SerialException as e:
            logging.error('com_isconnect报错 {}'.format(e))
            return False

    # 串口发送
    @pyqtSlot(list)
    def send_data(self, data):
        """
        发送数据帧，自动添加长度字段
        输入格式：[0xFF, 指令序号, 参数..., 0xFE]
        输出格式：[0xFF, 长度, 指令序号, 参数..., 0xFE]
        长度字段为单字节，范围：4-255
        """
        if not data or len(data) < 3:
            logging.warning("发送数据格式错误，至少需要3个字节")
            return
        
        # 计算新帧长度（原长度 + 1个长度字节）
        new_length = len(data) + 1
        
        # 验证长度是否在单字节范围内
        if new_length > 255:
            logging.warning(f"帧长度{new_length}超过单字节最大范围(255)")
            return
        
        # 构建新帧：帧头 + 长度(1字节) + 原数据(去掉帧头)
        # 原数据格式：[0xFF, cmd, params..., 0xFE]
        # 新数据格式：[0xFF, length, cmd, params..., 0xFE]
        new_data = [
            self.FRAME_HEADER,
            new_length,  # 单字节长度
        ] + data[1:]  # 去掉原帧头，添加其余部分
        
        send_start = time.time()
        logging.debug(f"[{send_start:.3f}] send_data: 准备发送指令 0x{data[1]:02X}，帧长度: {new_length}")
        
        with QMutexLocker(self.mutex_Send):
            # 实际是把数据存在队列中，等待串口线程自动发送
            self.Send_queue.put(new_data)
        
        send_end = time.time()
        logging.debug(f"[{send_end:.3f}] send_data: 数据入队完成，耗时: {(send_end - send_start)*1000:.2f}ms，队列大小: {self.Send_queue.qsize()}")
        
        # 立即触发一次发送，避免等待100ms定时器
        self.send_serial()

    # 其他线程读取字典缓冲区数据，函数的输入为待匹配的指令序号cmd
    def get_data(self, cmd):
        try:
            # with语块自动上锁，退出语块后自动解锁
            with QMutexLocker(self.mutex_Receive):
                if cmd in self.Receive_data:
                    item = self.Receive_data.pop(cmd, None)  # 弹出元组
                    if item is not None:
                        data, _ = item  # 取第一个元素，忽略时间戳
                        return data
                    else:
                        return []
                else:
                    return []
        except Exception as e:
            logging.error('获取数据异常：{}'.format(e))
            return []

    # 清空指定指令的缓存数据
    def clear_data(self, cmd):
        try:
            with QMutexLocker(self.mutex_Receive):
                if cmd in self.Receive_data:
                    del self.Receive_data[cmd]
                    logging.debug(f"[{time.time():.3f}] clear_data: 已清空指令 0x{cmd:02X} 的缓存")
        except Exception as e:
            logging.error(f"clear_data 异常：{e}")

    def wait_for_answer(self, cmd, timeout_ms=3000, process_events=None):
        """
        阻塞等待指定指令的应答数据（轮询方式 + 间隙处理事件循环）
        :param cmd: 指令序号（int，如 0x01/0x02/0x08 等）
        :param timeout_ms: 超时时间（毫秒）
        :param process_events: 可选的事件处理回调（如 self.loop.processEvents），在等待间隙调用以保持事件循环响应
        :return: 应答数据(bytes)；超时返回空 bytes

        设计说明：
        - 使用轮询方式（每 POLL_MS 毫秒检查一次 Receive_data 字典）
        - 轮询间隙调用 process_events() 保持线程事件循环响应
        - 保留 receive_cond/wakeAll 基础设施但不依赖（避免 QWaitCondition 在某些环境的兼容性问题）
        """
        start_time = time.time()
        POLL_MS = 50  # 轮询间隔（原来是20ms，改为50ms降低CPU占用）

        while True:
            # ① 检查是否已有应答
            data = self.get_data(cmd)
            if data:
                logging.info(f"wait_for_answer: 指令 0x{cmd:02X} 收到应答，耗时 {(time.time()-start_time)*1000:.2f}ms")
                return bytes(data)

            # ② 检查是否超时
            elapsed_ms = (time.time() - start_time) * 1000
            if elapsed_ms >= timeout_ms:
                logging.warning(f"wait_for_answer: 指令 0x{cmd:02X} 等待超时({timeout_ms}ms)")
                return b''

            # ③ 短暂等待 + 处理事件循环
            if process_events is not None:
                # 用 processEvents 作为等待机制（会处理事件循环）
                # 取较短的时间：POLL_MS 或 剩余时间
                remaining_ms = timeout_ms - elapsed_ms
                wait_ms = min(POLL_MS, remaining_ms)
                # 创建临时 QEventLoop 等待 wait_ms 毫秒（内部会处理事件）
                loop = QEventLoop()
                QTimer.singleShot(int(wait_ms), loop.quit)
                loop.exec_()
            else:
                # 没有事件循环可处理，直接 sleep
                QThread.msleep(POLL_MS)

    # 停止串口线程
    def stop(self):
        if self.ser and self.ser.is_open:
            self.ser.close()
        self.wait()  # 等待线程结束


'''自动对焦线程'''
class AutoFocus_Thread(QThread):
    signal_startAutoFocus = pyqtSignal(list)  # 主线程通知自动对焦
    signal_startFineTuning = pyqtSignal(list)  # 主线程通知微调
    signal_focusFinished = pyqtSignal(bool)  # 对焦/微调完成通知主线程（True=成功 False=失败/超时）

    def __init__(self, ser_thread, camera_thread):
        super().__init__()
        """构造函数，用于初始化实例变量"""
        self.ser_thread = ser_thread
        self.camera_thread = camera_thread
        
        self.FRAME_HEADER = 0xFF  # 帧头
        self.FRAME_TAIL = 0xFE    # 帧尾
        
        self.cmd_list = {'自动对焦': 0x01, '微调': 0x02}  # 指令序号列表！！
        self.cmd_auto = [0xFF, 0x01, 0xFE]  # 自动对焦指令
        self.cmd_fine_tuning = [0xFF, 0x02, 0x00, 0x00, 0x00, 0xFE]  # 微调指令 dir=0为cw方向（靠近步进电机的方向）
        self.focus_img_path = os.path.join(get_app_dir(), 'focus')
        self.score = []  # 记录评分
        self.dataBuffer = []  # 用作串口接收数据后发送的目标缓存区

        self.loop = None  # 保存事件循环的引用
        self.running = True
        self.signal_startAutoFocus.connect(self.Auto_focusing, Qt.QueuedConnection)  # 绑定自动对焦信号的槽函数
        self.signal_startFineTuning.connect(self.fine_tuning, Qt.QueuedConnection)  # 绑定微调信号的槽函数
        # self.ser_thread.signal_receiveData.connect(self.pass_DataBuffer)    # 绑定串口接收信号的槽函数

    def temp_delay(self, delay_ms):
        """函数内临时非阻塞延时，delay_ms：毫秒数"""
        loop = QEventLoop()
        QTimer.singleShot(delay_ms, loop.quit)  # 延时后退出临时事件循环
        loop.exec_()  # 启动临时循环（非阻塞当前线程的主循环）

    def run(self):
        self.loop = QEventLoop()  # 开启事件循环
        self.loop.exec_()

    def stop(self):
        """退出清理（非阻塞）：退出自动对焦事件循环。不调用 wait，避免阻塞主线程。"""
        if getattr(self, 'loop', None):
            self.loop.quit()

    # 计算图像对焦评分
    def calculate_img_score(self, img):
        # 转换灰度图
        image_grey = cv2.cvtColor(img, cv2.COLOR_RGB2GRAY)

        # 应用 Sobel 边缘检测
        image_sobel = cv2.Sobel(image_grey, cv2.CV_16U, 1, 1)

        # 计算 Sobel 图像的平均灰度
        mean_value = np.mean(image_sobel)

        return mean_value

    def _verify_response(self, response, data):
        """
        验证应答是否正确（只验证关键字段：帧头、功能码、帧尾）
        :param response: 接收到的应答数据（带长度字段）
        :param data: 原始发送数据（不带长度字段）
        :return: True表示应答正确，False表示应答失败
        """
        if not response or len(response) < 4:  # 最小帧：帧头+帧长+功能码+帧尾
            return False
        
        response_list = list(response)
        
        # 验证帧头
        if response_list[0] != self.FRAME_HEADER:
            logging.warning(f"帧头不匹配：期望{hex(self.FRAME_HEADER)}，实际{hex(response_list[0])}")
            return False
        
        # 验证帧尾
        if response_list[-1] != self.FRAME_TAIL:
            logging.warning(f"帧尾不匹配：期望{hex(self.FRAME_TAIL)}，实际{hex(response_list[-1])}")
            return False
        
        # 验证功能码（发送数据的功能码在索引1，应答数据的功能码在索引2）
        # 发送数据格式：[帧头, 功能码, 参数..., 帧尾]（不含帧长）
        # 应答数据格式：[帧头, 帧长, 功能码, 参数..., 帧尾]
        expected_cmd = data[1]  # 发送数据的功能码
        actual_cmd = response_list[2]  # 应答数据的功能码
        
        if expected_cmd != actual_cmd:
            logging.warning(f"功能码不匹配：期望{hex(expected_cmd)}，实际{hex(actual_cmd)}")
            return False
        
        # 可选：验证帧长是否合理
        frame_length = response_list[1]
        if frame_length != len(response_list):
            logging.warning(f"帧长不匹配：声明{frame_length}，实际{len(response_list)}")
            return False
        
        logging.info(f"应答验证成功：功能码{hex(actual_cmd)}")
        return True

    # 自动对焦流程
    @pyqtSlot(list)
    def Auto_focusing(self, arr):  # arr = [x, tick]   x=对焦次数 tick=对焦间隔步长
        x, tick = arr[:2]
        # （1）回零
        self.ser_thread.signal_sendData.emit(self.cmd_auto)
        # 等待应答
        response = self.waitForAnswer(self.cmd_list['自动对焦'], resend_data=self.cmd_auto)
        logging.debug("回零应答：{}".format(response))
        if self._verify_response(response, self.cmd_auto):
            logging.info("回零应答成功！")
        else:
            logging.warning("回零应答失败！")
            self.signal_focusFinished.emit(False)  # 通知主线程恢复按钮
            return

        # （2）移动到定点
        arr = [0x01, tick]
        self.score = []  # 每次用之前必须清空这个列表
        for i in range(0, x):
            logging.info('发送第{}次对焦移动'.format(i))
            flag = self.fine_tuning(arr)
            if flag:
                frame = self.camera_thread.get_frame()
                
                if frame is None:
                    logging.warning("自动对焦图像采集失败！")
                    self.signal_focusFinished.emit(False)  # 通知主线程恢复按钮
                    return
                
                mean_value = self.calculate_img_score(frame)
                logging.debug('mean_value:{}'.format(mean_value))
                self.score.append(mean_value)

                # 图片缩小展示
                temp = cv2.resize(frame, (0, 0), fx=0.3, fy=0.3)
                cv2.imshow('img{}'.format(i), temp)
                cv2.waitKey(1000)
                cv2.destroyAllWindows()
                cv2.imwrite(os.path.join(self.focus_img_path, 'img{}.bmp'.format(i)), frame)
            else:
                logging.warning('对焦移动应答失败！')
                self.signal_focusFinished.emit(False)  # 通知主线程恢复按钮
                return

        # 得到所有点位的图像的评分，计算最佳评分并驱动下位机移动到指定位置
        MaxScore_index = np.argmax(self.score)
        relative_tick = ((x - 1) - MaxScore_index) * tick
        # 最佳评分图像位置索引
        arr = [0x00, relative_tick]
        flag = self.fine_tuning(arr)
        if flag:  # 成功移动到对焦位置，显示当前的对焦图像
            logging.info('对焦成功 {}'.format(response))
            frame = self.camera_thread.get_frame()
            
            if frame is None:
                logging.warning("自动对焦图像采集失败！")
                self.signal_focusFinished.emit(False)  # 通知主线程恢复按钮
                return
            
            mean_value = self.calculate_img_score(frame)
            logging.debug('Current mean_value is :{}'.format(mean_value))
            logging.debug('{}%'.format(mean_value / self.score[MaxScore_index] * 100))
            temp = cv2.resize(frame, (0, 0), fx=0.5, fy=0.5)
            cv2.imshow('img', temp)
            cv2.waitKey()
            cv2.destroyAllWindows()
        else:
            logging.warning('移动最佳对焦位置应答失败！')
            self.signal_focusFinished.emit(False)  # 通知主线程恢复按钮
            return

        # 固定偏移至流道高度
        arr = [0x01, 14250]
        flag = self.fine_tuning(arr)
        if flag:  # 成功移动到对焦位置，显示当前的对焦图像
            frame = self.camera_thread.get_frame()
            
            if frame is None:
                logging.warning("自动对焦图像采集失败！")
                self.signal_focusFinished.emit(False)  # 通知主线程恢复按钮
                return
            
            temp = cv2.resize(frame, (0, 0), fx=0.5, fy=0.5)
            # cv2.imshow('img', temp)
            # cv2.waitKey()
            # cv2.destroyAllWindows()
        else:
            logging.warning('对焦失败！')
            self.signal_focusFinished.emit(False)  # 通知主线程恢复按钮
            return

        # 自动对焦全流程成功完成
        self.signal_focusFinished.emit(True)  # 通知主线程恢复按钮

    @pyqtSlot(list)
    def fine_tuning(self, arr):  # arr = [dir, tick] dir=方向 tick=步长
        start_time = time.time()
        logging.debug(f"[{start_time:.3f}] fine_tuning 开始，参数: {arr}")
        
        dir, tick = arr
        self.cmd_fine_tuning[2] = dir
        self.cmd_fine_tuning[3] = (tick >> 8) & 0xFF
        self.cmd_fine_tuning[4] = tick & 0xFF
        
        # 打印完整指令数据
        logging.debug(f"[{time.time():.3f}] 微调指令数据：{[hex(x) for x in self.cmd_fine_tuning]}")
        logging.debug(f"[{time.time():.3f}] 指令十六进制：{bytes(self.cmd_fine_tuning).hex(sep=' ').upper()}")
        
        # 发送微调指令
        emit_time = time.time()
        logging.debug(f"[{emit_time:.3f}] 准备发送信号 signal_sendData")
        self.ser_thread.signal_sendData.emit(self.cmd_fine_tuning)
        after_emit_time = time.time()
        logging.debug(f"[{after_emit_time:.3f}] 信号发送完成，耗时: {(after_emit_time - emit_time)*1000:.2f}ms")
        
        wait_start = time.time()
        logging.debug(f"[{wait_start:.3f}] 开始 waitForAnswer")
        response = self.waitForAnswer(self.cmd_list['微调'], resend_data=self.cmd_fine_tuning)
        wait_end = time.time()
        logging.debug(f"[{wait_end:.3f}] waitForAnswer 结束，耗时: {(wait_end - wait_start)*1000:.2f}ms")
        
        if self._verify_response(response, self.cmd_fine_tuning):
            logging.info(f"[{time.time():.3f}] 微调应答成功！")
            self.signal_focusFinished.emit(True)  # 通知主线程恢复按钮
            return True
        else:
            logging.warning(f"[{time.time():.3f}] 微调失败！")
            self.signal_focusFinished.emit(False)  # 通知主线程恢复按钮
            return False

    def waitForAnswer(self, cmd, max_retries=2, resend_data=None):
        """
        等待串口应答，支持重试机制（轮询方式 + 间隙处理事件循环）
        :param cmd: 指令序号
        :param max_retries: 最大重试次数
        :param resend_data: 重试时需要重新发送的指令数据(list)，为None则不重发（仅重新等待）
        :return: 应答数据(bytes)或空 bytes

        修复说明：
        - 原实现重试时只清空缓存重新等待，但没有重新发送指令，导致重试无效
        - 现在重试时会重新发送指令（如果提供了 resend_data）
        """
        for retry in range(max_retries):
            start_time = time.time()
            # 分段等待，间隙处理事件循环保持线程响应性
            data = self.ser_thread.wait_for_answer(cmd, timeout_ms=15000, process_events=self.loop.processEvents)
            if data:
                elapsed = (time.time() - start_time) * 1000
                logging.debug(f"[{time.time():.3f}] waitForAnswer: 第 {retry+1} 次尝试收到数据，耗时 {elapsed:.2f}ms")
                return data

            logging.debug(f"[{time.time():.3f}] waitForAnswer: 第 {retry+1} 次尝试超时！耗时 {(time.time() - start_time)*1000:.2f}ms")

            # 超时后清空缓存并重试
            if retry < max_retries - 1:
                self.ser_thread.clear_data(cmd)
                # 重试时重新发送指令（关键修复！）
                if resend_data is not None:
                    logging.debug(f"[{time.time():.3f}] waitForAnswer: 重新发送指令 {resend_data}")
                    self.ser_thread.signal_sendData.emit(resend_data)
                logging.debug(f"[{time.time():.3f}] waitForAnswer: 准备进行第 {retry+2} 次重试...")

        # 所有重试都失败
        logging.warning(f"[{time.time():.3f}] waitForAnswer: 所有 {max_retries} 次尝试都超时！")
        self.ser_thread.clear_data(cmd)
        return b''

    def stop(self):
        self.loop.quit()
        self.wait()  # 等待线程结束

# 相机线程
class CameraThread(QThread):
    new_frame = pyqtSignal(object)  # 传递相机画面数据到主线程信号
    signal_set_parameter = pyqtSignal(list)  # 修改相机参数

    def __init__(self, camera_index = 41):
        super().__init__()
        self.camera_index = camera_index  # 默认打开第一个相机（0）
        self.capture = None
        self.running = False
        self.mutex = QMutex()  # 线程间互斥锁
        self.frame_cond = QWaitCondition()  # 帧到达条件变量（替代轮询）
        self.frame_version = 0  # 帧版本号，每次写入新帧+1

        self.latest_frame = None
        self.signal_set_parameter.connect(self.set_parameter)
        # self.video_file_path = 'vedio.mp4'

    def temp_delay(self, delay_ms):
        """函数内临时非阻塞延时，delay_ms：毫秒数"""
        loop = QEventLoop()
        QTimer.singleShot(delay_ms, loop.quit)  # 延时后退出临时事件循环
        loop.exec_()  # 启动临时循环（非阻塞当前线程的主循环）

    def run(self):
        # 打开摄像头
        self.capture = cv2.VideoCapture(self.camera_index, cv2.CAP_V4L2)

        self.capture.set(cv2.CAP_PROP_FRAME_WIDTH, 1920)
        self.capture.set(cv2.CAP_PROP_FRAME_HEIGHT, 1080)

        if not self.capture.isOpened():
            logging.error("无法打开摄像头")
            return

        self.running = True
        frame_timeout = 5000  # 读取超时时间（毫秒）
        
        # 设置超时参数（OpenCV 4.5+ 支持）
        try:
            self.capture.set(cv2.CAP_PROP_OPEN_TIMEOUT_MSEC, frame_timeout)
            self.capture.set(cv2.CAP_PROP_READ_TIMEOUT_MSEC, frame_timeout)
        except:
            pass  # 某些版本不支持这些参数

        while self.running:
            try:
                ret, frame = self.capture.read()
                if not ret:
                    logging.warning("相机无法读取数据！！！")
                    self.capture.release()  # 释放相机
                    QThread.msleep(500)  # 等待500ms后重试，避免频繁重试
                    self.capture = cv2.VideoCapture(self.camera_index, cv2.CAP_V4L2)  # 重启相机
                    self.latest_frame = None
                    continue  # 如果无法获取帧，则重新读取

                with QMutexLocker(self.mutex):
                    self.latest_frame = frame.copy()    # 深拷贝图像数据并删除原图像的数据
                    self.frame_version += 1  # 帧版本号+1
                    self.frame_cond.wakeAll()  # 通知所有等待帧的线程

                # 发射信号到主线程传递数据
                self.new_frame.emit(frame)

                # 模拟帧率：假设每秒刷新30帧
                self.temp_delay(30)

            except Exception as e:
                logging.error(f"相机读取异常: {str(e)}")
                self.latest_frame = None
                QThread.msleep(500)

        # 释放摄像头资源
        self.capture.release()

    def get_frame(self):
        """
        获取相机帧（直接返回缓存的最新帧，非阻塞）
        :return: 成功返回帧，失败返回None
        """
        try:
            with QMutexLocker(self.mutex):
                if self.latest_frame is not None:
                    return self.latest_frame.copy()  # 返回帧的副本，避免线程安全问题
                else:
                    logging.warning("相机帧缓存为空！")
                    return None
        except Exception as e:
            logging.error(f"获取图像异常: {str(e)}")
            return None

    def wait_for_frame(self, timeout_ms=5000, skip_version=0, process_events=None):
        """
        阻塞等待新帧到达（轮询方式 + 间隙处理事件循环）
        :param timeout_ms: 超时时间（毫秒）
        :param skip_version: 跳过此版本号及之前的帧（用于等待"下一帧"），默认0表示只要当前有帧就返回
        :param process_events: 可选的事件处理回调，在等待间隙调用以保持事件循环响应
        :return: 成功返回帧副本，超时返回None
        """
        start_time = time.time()
        POLL_MS = 50  # 轮询间隔

        while True:
            # ① 检查是否有新帧
            with QMutexLocker(self.mutex):
                if self.latest_frame is not None and self.frame_version > skip_version:
                    return self.latest_frame.copy()

            # ② 检查是否超时
            elapsed_ms = (time.time() - start_time) * 1000
            if elapsed_ms >= timeout_ms:
                return None

            # ③ 短暂等待 + 处理事件循环
            if process_events is not None:
                remaining_ms = timeout_ms - elapsed_ms
                wait_ms = min(POLL_MS, remaining_ms)
                loop = QEventLoop()
                QTimer.singleShot(int(wait_ms), loop.quit)
                loop.exec_()
            else:
                QThread.msleep(POLL_MS)

    @pyqtSlot(list)
    def set_parameter(self, param):
        self.capture.set(cv2.CAP_PROP_BRIGHTNESS, param[0])  # 曝光时间
        self.capture.set(cv2.CAP_PROP_SATURATION, param[1])  # 饱和度
        self.capture.set(cv2.CAP_PROP_GAIN, param[2])  # 增益

    def stop(self):
        # 置停止标志；
        # 相机未开启/未成功打开时 self.capture 可能为 None 或 isOpened()=False。
        # 仅对已打开的 capture 调 release()（既避免误释放，又能打断可能阻塞的 read()）。
        self.running = False
        try:
            cap = self.capture
            if cap is not None and cap.isOpened():
                cap.release()  # 释放摄像头并打断阻塞的 read()
        except Exception as e:
            logging.error(f"相机释放异常: {e}")


'''计数线程'''
class CountCell_Thread(QThread):
    signal_countCell = pyqtSignal()  # 定义信号，用于主线程触发计数流程
    signal_clearScroll = pyqtSignal()  # 定义信号，用于触发主线程清空scroll
    signal_refreshScroll = pyqtSignal(str, float)  # 定义信号，用于触发主线程刷新scroll
    signal_refreshChartData = pyqtSignal()  # 定义信号，用于触发主线程重新刷新图表数据
    signal_openKey = pyqtSignal()  # 一键采集接收后恢复按钮点击功能
    signal_step = pyqtSignal(str)  # 检测流程步骤进度（显示到信息小窗）

    signal_microPumpSample = pyqtSignal()  # 定义信号，微泵采集
    signal_initializeSample = pyqtSignal()  # 定义信号，初次进样
    signal_SampleEmptiness = pyqtSignal()  # 定义信号，样池排空
    signal_Ratioinjection = pyqtSignal()  # 定义信号，比例进样
    signal_sampleWash = pyqtSignal()  # 定义信号，奶路清洗
    signal_colorWash = pyqtSignal()  # 定义信号，染料清洗
    signal_chipWash = pyqtSignal()  # 定义信号，流道清洗
    signal_shakemotor = pyqtSignal()  # 定义信号，振动电机
    signal_standardTest = pyqtSignal()  # 定义信号，标测（标样测试流程）

    signal_uploadNumbers = pyqtSignal(int, float)  # 云上传：数字数据（img_num, cell_count）
    signal_uploadImages = pyqtSignal(str, int, float)  # 云上传：图片（folder, img_num, cell_count）

    def __init__(self, ser_thread, camera_thread):
        super().__init__()

        self.ser_thread = ser_thread
        self.camera_thread = camera_thread

        self.FRAME_HEADER = 0xFF  # 帧头
        self.FRAME_TAIL = 0xFE    # 帧尾

        self.camera_parameters_file = os.path.join(get_app_dir(), 'camera_parameters.json')  # 相机参数文件
        self.scc_history_file = os.path.join(get_app_dir(), 'scc_history.csv')  # 历史数据文件
        self.cmd_list = {'奶样进样': 0x03, '染料进样': 0x04, '共同进样': 0x05, '微泵进样': 0X06, '样池排空': 0x09, '比例进样': 0x0A, '清洗': 0x0B,
                         '抽样混样': 0x0C, '重启': 0x0D}
        self.repeat_num = 10
        self.loop = None
        self.sampling_mixing_flag = False
        self.is_running = False  # 防止重复触发的标志

        self.signal_countCell.connect(self.Count_Test)

        self.signal_microPumpSample.connect(self.microPumpSample)
        self.signal_initializeSample.connect(self.initializeSample)
        self.signal_SampleEmptiness.connect(self.SampleEmptiness)
        self.signal_Ratioinjection.connect(self.Ratioinjection)
        self.signal_sampleWash.connect(self.sampleWash)
        self.signal_colorWash.connect(self.colorWash)
        self.signal_chipWash.connect(self.cleanerWash)
        self.signal_shakemotor.connect(self.samplingMixing)
        self.signal_standardTest.connect(self.standardTest)

        # self.model, self.model_classes = detect_cell.load_model()

    def get_frame_with_timeout(self, timeout_ms=5000, interval_ms=100):
        """
        带超时的图像获取方法（基于 QWaitCondition，无轮询）
        :param timeout_ms: 超时时间（毫秒）
        :param interval_ms: 取消检查间隔（毫秒），仅在等待期间定期检查 is_running
        :return: 成功返回帧，超时返回None
        """
        start_time = time.time()
        elapsed_ms = 0

        while elapsed_ms < timeout_ms:
            # 检查是否被取消
            if not self.is_running:
                logging.info("检测被取消，停止等待图像")
                return None

            # 计算本次等待的最长时间（不超过取消检查间隔）
            remaining_ms = timeout_ms - elapsed_ms
            wait_ms = min(interval_ms, remaining_ms)
            if wait_ms <= 0:
                break

            # 用条件变量等待新帧（间隙处理事件循环保持线程响应性）
            frame = self.camera_thread.wait_for_frame(
                timeout_ms=int(wait_ms),
                process_events=self.loop.processEvents if hasattr(self, 'loop') else None
            )
            if frame is not None:
                elapsed_ms = (time.time() - start_time) * 1000
                logging.info(f"图像获取成功，耗时 {int(elapsed_ms)}ms")
                return frame

            elapsed_ms = (time.time() - start_time) * 1000

        logging.warning(f"图像获取超时！({timeout_ms}ms)")
        return None

    def initializeSample(self):
        """初始化进样方法"""
        self.restart_times = 0  # 执行重启需要经历的轮数，200轮后重启


    def run(self):
        self.loop = QEventLoop()  # 创建事件循环
        self.loop.exec_()  # 启动事件循环

    def stop(self):
        """退出清理（非阻塞）：退出计数线程事件循环。不调用 wait，避免阻塞主线程。"""
        if getattr(self, 'loop', None):
            self.loop.quit()

    def temp_delay(self, delay_ms):
        """函数内临时非阻塞延时，delay_ms：毫秒数"""
        loop = QEventLoop()
        QTimer.singleShot(delay_ms, loop.quit)  # 延时后退出临时事件循环
        loop.exec_()  # 启动临时循环（非阻塞当前线程的主循环）

    def clear_or_create_folder(self, folder_path):
        # 如果文件夹已经存在
        if os.path.exists(folder_path):
            # 清空文件夹中的所有文件
            for filename in os.listdir(folder_path):
                file_path = os.path.join(folder_path, filename)
                if os.path.isfile(file_path):  # 确保是文件而不是文件夹
                    os.remove(file_path)  # 删除文件
            logging.info(f"文件夹 {folder_path} 已清空。")
        else:
            # 如果文件夹不存在，创建文件夹
            os.makedirs(folder_path)
            logging.info(f"文件夹 {folder_path} 已创建。")

    # 十进制转hex字节
    def decimal_2_hex_bytes(self, n, num):
        hex_list = []
        for i in range(n):
            hex_list.insert(0, num & 0xFF)
            num = num >> 8
        return hex_list

    def _verify_response(self, response, data):
        """
        验证应答是否正确（只验证关键字段：帧头、功能码、帧尾）
        :param response: 接收到的应答数据（带长度字段）
        :param data: 原始发送数据（不带长度字段）
        :return: True表示应答正确，False表示应答失败
        """
        if not response or len(response) < 4:  # 最小帧：帧头+帧长+功能码+帧尾
            return False
        
        response_list = list(response)
        
        # 验证帧头
        if response_list[0] != self.FRAME_HEADER:
            logging.warning(f"帧头不匹配：期望{hex(self.FRAME_HEADER)}，实际{hex(response_list[0])}")
            return False
        
        # 验证帧尾
        if response_list[-1] != self.FRAME_TAIL:
            logging.warning(f"帧尾不匹配：期望{hex(self.FRAME_TAIL)}，实际{hex(response_list[-1])}")
            return False
        
        # 验证功能码（发送数据的功能码在索引1，应答数据的功能码在索引2）
        # 发送数据格式：[帧头, 功能码, 参数..., 帧尾]（不含帧长）
        # 应答数据格式：[帧头, 帧长, 功能码, 参数..., 帧尾]
        expected_cmd = data[1]  # 发送数据的功能码
        actual_cmd = response_list[2]  # 应答数据的功能码
        
        if expected_cmd != actual_cmd:
            logging.warning(f"功能码不匹配：期望{hex(expected_cmd)}，实际{hex(actual_cmd)}")
            return False
        
        # 可选：验证帧长是否合理
        frame_length = response_list[1]
        if frame_length != len(response_list):
            logging.warning(f"帧长不匹配：声明{frame_length}，实际{len(response_list)}")
            return False
        
        logging.info(f"应答验证成功：功能码{hex(actual_cmd)}")
        return True

    def _save_to_csv(self, num_list, current_time):
        """
        将采集结果追加保存到 CSV 文件（O(1) 追加写入）
        固定列数 = max(self.repeat_num, 现有CSV表头中的体细胞数列数)，确保所有行列数一致
        :param num_list: 体细胞数列表，如 [15, 18, 16]
        :param current_time: 时间字符串，如 "260830-1430"
        :return: True=保存成功，False=无数据
        """
        if len(num_list) == 0:
            logging.warning("_save_to_csv: num_list 为空，跳过保存")
            return False
        # 确定固定列数：取 repeat_num 和现有 CSV 表头列数的最大值
        total_cols = self.repeat_num
        if os.path.exists(self.scc_history_file):
            try:
                with open(self.scc_history_file, 'r', encoding='utf-8-sig') as f:
                    reader = csv.reader(f)
                    header = next(reader)
                    existing_cell_cols = sum(1 for h in header if h.startswith('体细胞数'))
                    total_cols = max(total_cols, existing_cell_cols)
            except Exception:
                pass  # 读取失败则用 repeat_num 默认值
        aver_num_raw = sum(num_list) / len(num_list)
        aver_num = 0.3433 * aver_num_raw - 2.8141  # 标曲 y=0.3433x-2.8141 换算公式
        if aver_num < 0:
            aver_num = 0
        # 构建固定长度的行数据，不足的填空字符串
        new_row = {f"体细胞数{i}": (num_list[i - 1] if i <= len(num_list) else "") for i in range(1, total_cols + 1)}
        new_row["时间"] = current_time
        new_row["平均体细胞数"] = aver_num
        new_row["炎症预警"] = 1
        fieldnames = ["时间", "平均体细胞数", "炎症预警"] + [f"体细胞数{i}" for i in range(1, total_cols + 1)]
        file_exists = os.path.exists(self.scc_history_file)
        try:
            with open(self.scc_history_file, 'a', newline='', encoding='utf-8-sig') as f:
                writer = csv.DictWriter(f, fieldnames=fieldnames)
                if not file_exists:
                    writer.writeheader()
                writer.writerow(new_row)
            logging.info(f"数据已保存至 CSV：{len(num_list)}/{total_cols} 次采集，平均 {aver_num:.2f}")
            return True
        except Exception as e:
            logging.error(f"保存 CSV 失败：{e}")
            return False

    def initializeSample(self):  # 初次进样 = 共同进样 + 奶路进样
        # 协议格式: 帧头(1) + 帧长(1，自动添加) + 功能码(1) + 脉冲数(4) + 奶样泵方向(1) + 染料泵方向(1) + ARR(2) + PSC(2) + 帧尾(1) = 14字节
        # 先共同进样（不含帧长，由send_data自动添加）
        data = [0xFF] + [self.cmd_list['共同进样']] + self.decimal_2_hex_bytes(4, 1000) + [0x01, 0x01] + self.decimal_2_hex_bytes(2, 39) + self.decimal_2_hex_bytes(2, 143) + [0xFE]
        logging.debug([hex(num) for num in data])
        self.ser_thread.signal_sendData.emit(data)
        response = self.waitForAnswer('共同进样')
        if self._verify_response(response, data):
            logging.info("初次进样应答成功！")
            

    def SampleEmptiness(self):  # 样池排空
        data = [0xFF] + [self.cmd_list['样池排空']] + self.decimal_2_hex_bytes(4, 20000) + [0x01] + self.decimal_2_hex_bytes(2,
                                                                                                                59) + self.decimal_2_hex_bytes(
            2, 143) + [0xFE]
        # data = [0xFF, 0x09, 0x00, 0x01, 0x11, 0x70, 0x00, 0x27, 0x00, 0x8F, 0xFE]   # 要调整下
        self.ser_thread.signal_sendData.emit(data)
        response = self.waitForAnswer('样池排空')
        # print(response.hex(sep=' ').upper())
        logging.debug(response)

    def Ratioinjection(self):  # 比例进样
        data = [0xFF] + [self.cmd_list['比例进样']] + self.decimal_2_hex_bytes(4, 9200) + [0x01] + [0x01] + self.decimal_2_hex_bytes(2,
                                                                                                               59) + self.decimal_2_hex_bytes(
            2, 143) + [0xFE]
        # data = [0xFF, 0x0A, 0x00, 0x00, 0x4B, 0x00, 0x00, 0x4f, 0x00, 0x8F, 0xFE]
        self.ser_thread.signal_sendData.emit(data)
        response = self.waitForAnswer('比例进样')
        if self._verify_response(response, data):
            logging.info("比例进样应答成功！")

    def microPumpSample(self):  # 微泵进样 n次（这个函数暂时不能再用了）
        if self.is_running:
            logging.info("microPumpSample 正在执行中，跳过重复触发")
            return
        self.is_running = True  # 标记正在运行，防止 get_frame_with_timeout 误判取消
        try:
            self.signal_clearScroll.emit()  # 每轮测试计数前需要清空srcoll
            # 从 JSON 读取相机参数
            # with open(self.camera_parameters_file, 'r', encoding='utf-8') as f:
            #     camera_params = json.load(f)
            # threshold = camera_params['threshold']
            current_time = datetime.now().strftime("%y%m%d-%H%M%S%f")  # 获取当前时间（含微秒，目录唯一性极高，避免云端上传按文件名判重撞名）
            folder_path = os.path.join(get_app_dir(), 'scc_img', current_time)  # 文件夹路径
            logging.info("新计数图像文件路径：{}".format(folder_path))
            self.clear_or_create_folder(folder_path)  # 创建保存体细胞图片的文件夹
            data = [0xFF] + [self.cmd_list['微泵进样']] + self.decimal_2_hex_bytes(4, 2048) + [0x01] + self.decimal_2_hex_bytes(2,
                                                                                                                39) + self.decimal_2_hex_bytes(
                2, 143) + [0xFE]
            # data = [0xFF, 0x06, 0x00, 0x00, 0x08, 0x00, 0x00, 0x4f, 0x00, 0x8f, 0xFE]
            num = []
            aver_num = 0  # 修复：改为数字类型，初始化为0
            for i in range(self.repeat_num):
                self.ser_thread.signal_sendData.emit(data)
                response = self.waitForAnswer('微泵进样')
                logging.debug(response)
                if self._verify_response(response, data):
                    # 图片不能太大，否则计算速度很慢
                    # self.frame = cv2.imread(r'C:\Users\HP\Desktop\UI\testjiemian7\scc_img\0002.bmp')
                    frame = self.get_frame_with_timeout(timeout_ms=5000)
                    
                    if frame is None:
                        logging.warning("微泵进样图像采集失败！")
                        # 保存已采集的数据（如果有），避免丢失
                        if len(num) > 0:
                            self._save_to_csv(num, current_time)
                            self.signal_refreshChartData.emit()
                        self.is_running = False
                        self.signal_openKey.emit()
                        return
                    
                    resize_frame = cv2.resize(frame, None, fx=0.5, fy=0.5)

                    '''
                    # 体细胞计数
                    new_num, result = cell_count(resize_frame, threshold)
                    num.append(new_num)
                    '''
                    # 创建新图像处理线程，并设置识别图片
                    imageProcess_thread = ImageProcessThread()
                    imageProcess_thread.set_image(frame.copy())
                    imageProcess_thread.start()  # 启动图像处理线程（独立线程，数秒级）

                    # 等待图像识别完毕
                    success = imageProcess_thread.wait_for_finish(timeout_ms=10000)  # 超时10秒
                    # 2. 第一步校验：等待是否成功
                    if not success:
                        logging.warning("图像处理超时/未完成！")
                        # 可添加弹窗提示
                        continue  # 跳过当前循环
                    # 3. 获取结果并校验是否为有效字典
                    result = imageProcess_thread.get_result()
                    if not isinstance(result, dict):
                        logging.warning(f"处理结果异常：不是字典类型，值为 {result}")
                        continue
                    # 4. 校验是否有错误信息
                    if result.get("error") is not None:
                        logging.warning(f"图像处理失败：{result['error']}")
                        continue
                    # 5. 校验关键数据是否存在且有效
                    if "result_img" not in result or "processed_count" not in result:
                        logging.warning("处理结果不完整：缺少关键字段")
                        continue
                    stitched_img = result['result_img']
                    processed_count = result['processed_count']  # 修复：先提取计数结果
                    num.append(processed_count)  # 修复：添加到列表中

                    # 先保存原图和计数后图片（时间戳取保存该张图片的时刻，微秒级唯一；OneNET 按文件名判重，必须保证 basename 唯一）
                    try:
                        save_time = datetime.now().strftime("%y%m%d-%H%M%S%f")
                        file_time = save_time[2:6] + '-' + save_time[7:19]  # 月日-时分秒-微秒（去掉年，作图片文件名前缀，避免云端按文件名判重撞名）
                        saved1 = cv2.imwrite(folder_path + '/' + f"{file_time}-{str(i).zfill(4)}.bmp", stitched_img)
                        saved2 = cv2.imwrite(folder_path + '/' + f"{file_time}-{str(i).zfill(4)}_0.bmp", frame)
                        if not saved1:
                            logging.warning(f'保存处理后图片失败: {file_time}-{str(i).zfill(4)}.bmp')
                        if not saved2:
                            logging.warning(f'保存原图失败: {file_time}-{str(i).zfill(4)}_0.bmp')
                        # cv2.imwrite(r'C:/Users/Administrator/Desktop/111' + '/' + f"{str(i).zfill(4)}-0.bmp",
                        #             resize_frame)

                        # 计算平均值
                        aver_num = sum(num) / len(num)
                        # 用标曲 y = 0.3433x - 2.8141 将平均细胞数转换为 W/mL（万/mL）
                        aver_num = 0.3433 * aver_num - 2.8141
                        if aver_num < 0:
                            aver_num = 0
                        self.signal_refreshScroll.emit(folder_path, aver_num)  # 更新scroll中的图片
                    except Exception as e:
                        logging.error(e)
                else:
                    # QMessageBox.critical(self, "Error", "微泵进样失败！")
                    logging.warning("微泵进样应答失败，继续尝试...")  # 修复：增加提示信息
                    continue  # 修复：改为continue继续尝试，而不是return退出

                logging.info('第{}次图像已采集'.format(i+1))

            # 统一保存数据至 CSV 中（O(1) 追加写入）
            if self._save_to_csv(num, current_time):
                # 刷新图表数据（从文件夹中重新读取）！！！！！
                self.signal_refreshChartData.emit()
                # 投递云上传任务（UploadThread 后台执行，不阻塞本线程）
                self.signal_uploadNumbers.emit(len(num), aver_num)
                self.signal_uploadImages.emit(folder_path, len(num), aver_num)
        except Exception as e:
            logging.error(f"发生了错误: {e}")
        finally:
            self.is_running = False  # 无论成功/失败，结束时重置标志

    def sampleWash(self):
        data = [0xFF] + [self.cmd_list['奶样进样']] + self.decimal_2_hex_bytes(4, 25000) + [0x01] + self.decimal_2_hex_bytes(2,
                                                                                                                39) + self.decimal_2_hex_bytes(
            2, 143) + [0xFE]
        # data = [0xFF, 0x03, 0x00, 0x01, 0x38, 0x80, 0x00, 0x27, 0x00, 0x8f, 0xFE]
        self.ser_thread.signal_sendData.emit(data)
        response = self.waitForAnswer('奶样进样')
        if self._verify_response(response, data):
            logging.info("奶路清洗应答成功！")
        else:
            logging.warning("奶路清洗应答失败！")

    def colorWash(self):
        data = [0xFF] + [self.cmd_list['染料进样']] + self.decimal_2_hex_bytes(4, 25000) + [0x01] + self.decimal_2_hex_bytes(2,
                                                                                                                 39) + self.decimal_2_hex_bytes(
            2, 143) + [0xFE]
        # data = [0xFF, 0x04, 0x00, 0x01, 0x11, 0x70, 0x00, 0x27, 0x00, 0x8f, 0xFE]
        self.ser_thread.signal_sendData.emit(data)
        response = self.waitForAnswer('染料进样')
        if self._verify_response(response, data):
            logging.info("染剂清洗应答成功！")
        else:
            logging.warning("染剂清洗应答失败！")

    def cleanerWash(self):
        data = [0xFF] + [self.cmd_list['清洗']] + self.decimal_2_hex_bytes(4, 28000) + [0x01] + self.decimal_2_hex_bytes(2,
                                                                                                              39) + self.decimal_2_hex_bytes(
            2, 143) + [0xFE]
        # data = [0xFF, 0x0B, 0x00, 0x00, 0x6D, 0x60, 0x00, 0x4f, 0x00, 0x8f, 0xFE]
        self.ser_thread.signal_sendData.emit(data)
        response = self.waitForAnswer('清洗')
        if self._verify_response(response, data):
            logging.info("清洗剂清洗应答成功！")
        else:
            logging.warning("清洗剂清洗应答失败！")

    def samplingMixing(self):  # 抽样混样按钮，每次点击发送一次指令
        # 协议: 帧头(1) + 帧长(1，自动添加) + 功能码(1)=0x0C + 重复次数(1) + 抽脉冲数(2) + 推脉冲数(2) + ARR(2) + PSC(2) + 帧尾(1)
        data = [0xFF, 0x0C, 0x0A] + self.decimal_2_hex_bytes(2, 30000) + self.decimal_2_hex_bytes(2, 20000) + self.decimal_2_hex_bytes(2, 39) + self.decimal_2_hex_bytes(2, 143) + [0xFE]
        self.ser_thread.signal_sendData.emit(data)
        response = self.waitForAnswer('抽样混样')
        if self._verify_response(response, data):
            logging.info("抽样混样应答成功！")
        else:
            logging.warning("抽样混样应答失败！")

    def standardTest(self):  # 标测：标样测试流程
        try:
            logging.info("标测流程开始...")
            # 1. 奶路清洗 ×3
            for i in range(3):
                logging.info(f"标测：奶路清洗 第{i + 1}/3 次")
                self.sampleWash()
            # 2. 混样振动 ×1
            logging.info("标测：混样振动")
            self.samplingMixing()
            # 3. 样池排空 ×1
            logging.info("标测：样池排空")
            self.SampleEmptiness()
            # 4. 微泵采集 ×1
            logging.info("标测：微泵采集")
            self.microPumpSample()
            # 5. 样池排空 ×2
            for i in range(2):
                logging.info(f"标测：样池排空 第{i + 1}/2 次")
                self.SampleEmptiness()
            logging.info("标测流程完毕！")
        except Exception as e:
            logging.error(f"标测流程发生错误: {e}")
        finally:
            self.is_running = False
            self.signal_openKey.emit()  # 恢复按钮点击功能

    def waitForAnswer(self, cmd):
        """等待串口应答，分段等待：长动作（抽样混样/排空等）真实执行时间可超 20s，
        且假下位机按脉冲数模拟延迟，这里统一放宽到 90s，避免长动作未完即被判定超时中止。"""
        cmd_code = self.cmd_list[cmd]
        # 分段等待，间隙处理事件循环保持线程响应性
        data = self.ser_thread.wait_for_answer(cmd_code, timeout_ms=90000, process_events=self.loop.processEvents)
        if not data:
            logging.warning(f"{cmd_code}->下位机超时无应答！")
        return data

    def Count_Test(self):  
        if self.is_running:
            logging.info("Count_Test 正在执行中，跳过重复触发")
            return
        self.is_running = True  # 设置正在执行标志
        
        # 每轮测试计数前需要先清空srcoll
        self.signal_clearScroll.emit()

        # 01-初次进样（make sure milk and color arrive mixpool）
        self.signal_step.emit("① 初次进样")
        data = [0xFF] + [self.cmd_list['共同进样']] + self.decimal_2_hex_bytes(4, 1000) + [0x01, 0x01] + self.decimal_2_hex_bytes(2,
                                                                                                               39) + self.decimal_2_hex_bytes(
            2, 143) + [0xFE]
        
        self.ser_thread.signal_sendData.emit(data)
        response = self.waitForAnswer('共同进样')
        if self._verify_response(response, data):
            logging.info("一键采集：初次进样应答成功！")

        else:
            logging.warning("一键采集：初次进样应答失败！")
            logging.warning(f"指令 = [{data}]   应答 = [{list(response)}]")
            self.signal_openKey.emit()  # 重新开启按钮点击功能
            self.is_running = False  # 重置执行标志
            return
        
        # second: in remain and out all mixpool
        self.signal_step.emit("② 排除旧奶样")
        data = [0xFF] + [self.cmd_list['奶样进样']] + self.decimal_2_hex_bytes(4, 25000) + [0x01] + self.decimal_2_hex_bytes(2,
                                                                                                                39) + self.decimal_2_hex_bytes(
            2, 143) + [0xFE]
        self.ser_thread.signal_sendData.emit(data)
        data1 = [0xFF] + [self.cmd_list['样池排空']] + self.decimal_2_hex_bytes(4, 85000) + [0x01] + self.decimal_2_hex_bytes(2,
                                                                                                                39) + self.decimal_2_hex_bytes(
            2, 143) + [0xFE]
        self.ser_thread.signal_sendData.emit(data1)
        response = self.waitForAnswer('奶样进样')
        if self._verify_response(response, data):
            logging.info("remove old milk应答成功！")
        else:
            logging.warning("一键采集:remove old milk 应答失败！")
            logging.warning(f"指令 = [{data}]   应答 = [{list(response)}]")
            self.is_running = False  # 重置执行标志
            return

        # 02-清空混样池
        response = self.waitForAnswer('样池排空')
        if self._verify_response(response, data1):
            logging.info("一键采集：样池排空应答成功！")

        else:
            logging.warning("一键采集：样池排空应答失败！")
            logging.warning(f"指令 = [{data1}]   应答 = [{list(response)}]")
            self.signal_openKey.emit()  # 重新开启按钮点击功能
            self.is_running = False  # 重置执行标志
            return
        self.temp_delay(100)  # 开始下个指令前延时一会

        # 03-比例进样
        self.signal_step.emit("④ 比例进样")
        data = [0xFF] + [self.cmd_list['比例进样']] + self.decimal_2_hex_bytes(4, 14000) + [0x01] + [0x01] + self.decimal_2_hex_bytes(2, 59) + self.decimal_2_hex_bytes(2, 143) + [0xFE]
        self.ser_thread.signal_sendData.emit(data)
        response = self.waitForAnswer('比例进样')
        if self._verify_response(response, data):
            logging.info("一键采集：比例进样应答成功！")
        else:
            logging.warning("一键采集：比例进样应答失败！")
            logging.warning(f"指令 = [{data}]   应答 = [{list(response)}]")
            self.signal_openKey.emit()  # 重新开启按钮点击功能
            self.is_running = False  # 重置执行标志
            return

        self.temp_delay(200)  # 开始下个指令前延时一会

        # 开启抽样混样，循环10次 
        # 协议: 帧头(1) + 帧长(1，自动添加) + 功能码(1)=0x0C + 重复次数(1) + 抽脉冲数(2) + 推脉冲数(2) + ARR(2) + PSC(2) + 帧尾(1)
        self.signal_step.emit("⑤ 抽样混样")
        data = [0xFF, 0x0C, 0x0A] + self.decimal_2_hex_bytes(2, 30000) + self.decimal_2_hex_bytes(2, 20000) + self.decimal_2_hex_bytes(2, 39) + self.decimal_2_hex_bytes(2, 143) + [0xFE]
        logging.info(f"开启抽样混样: {data}")
        self.ser_thread.signal_sendData.emit(data)
        response = self.waitForAnswer('抽样混样')  # 添加应答等待
        if self._verify_response(response, data):
            logging.info("一键采集：抽样混样应答成功！")
        else:
            logging.warning("一键采集：抽样混样应答失败！")
            self.signal_openKey.emit()
            self.is_running = False  # 重置执行标志
            return
            
        # 05-驱动进样泵填充流道
        self.signal_step.emit("⑥ 填充流道")
        data = [0xFF] + [self.cmd_list['样池排空']] + self.decimal_2_hex_bytes(4, 20000) + [0x01] + self.decimal_2_hex_bytes(2, 39) + self.decimal_2_hex_bytes(2, 143) + [0xFE]
        # data = [0xFF] + [self.cmd_list['样池排空']] + self.decimal_2_hex_bytes(4, 70000) + [0x00] + self.decimal_2_hex_bytes(2, 39) + self.decimal_2_hex_bytes(2, 143) + [0xFE]        print(data)
        # data = [0xFF, 0x09, 0x00, 0x00, 0x0E, 0x10, 0x00, 0x27, 0x00, 0x8F, 0xFE]  # 要调整下
        self.ser_thread.signal_sendData.emit(data)
        response = self.waitForAnswer('样池排空')
        if self._verify_response(response, data):
            logging.info("一键采集：流道填充应答成功！")
        else:
            logging.warning("一键采集：流道填充应答失败！")
            logging.warning(f"指令 = [{data}]   应答 = [{list(response)}]")
            self.signal_openKey.emit()  # 重新开启按钮点击功能
            self.is_running = False  # 重置执行标志
            return

        # 06-微泵进样采集数据
        self.signal_step.emit("⑦ 微泵进样·图像采集")
        # 数据采集前的准备
        current_time = datetime.now().strftime("%y%m%d-%H%M%S%f")  # 获取当前时间（含微秒，目录唯一性极高，避免云端上传按文件名判重撞名）
        folder_path = os.path.join(get_app_dir(), 'scc_img', current_time)  # 文件夹路径
        logging.info(f"新计数图像文件路径：{folder_path}")
        self.clear_or_create_folder(folder_path)  # 创建保存体细胞图片的文件夹
        data = [0xFF] + [self.cmd_list['微泵进样']] + self.decimal_2_hex_bytes(4, 2048) + [0x01] + self.decimal_2_hex_bytes(2, 59) + self.decimal_2_hex_bytes(2, 143) + [0xFE]
        # data = [0xFF, 0x06, 0x00, 0x00, 0x08, 0x00, 0x00, 0x4f, 0x00, 0x8f, 0xFE]
        num = []
        aver_num = 0
        try_time = 0  # 记录总采集次数
        suc_time = 0  # 记录成功采集次数

        while suc_time < self.repeat_num:
            try_time = try_time + 1

            self.ser_thread.signal_sendData.emit(data)
            response = self.waitForAnswer('微泵进样')
            self.temp_delay(500)
            if self._verify_response(response, data):
                # 使用带超时的图像获取
                frame = self.get_frame_with_timeout(timeout_ms=5000)
                
                if frame is None:
                    logging.warning("微泵进样图像采集失败！")
                    # 保存已采集的数据（如果有），避免丢失
                    if len(num) > 0:
                        self._save_to_csv(num, current_time)
                        self.signal_refreshChartData.emit()
                    self.is_running = False
                    self.signal_openKey.emit()
                    return

                # 创建新图像处理线程，并设置识别图片
                imageProcess_thread = ImageProcessThread()
                # imageProcess_thread.model = self.model
                # imageProcess_thread.model_classes = self.model_classes
                imageProcess_thread.set_image(frame.copy())
                imageProcess_thread.start()     # 启动图像处理线程（独立线程，数秒级）

                # 等待图像识别完毕
                success = imageProcess_thread.wait_for_finish(timeout_ms=10000)  # 超时10秒
                # 2. 第一步校验：等待是否成功
                if not success:
                    logging.warning("图像处理超时/未完成！")
                    # 可添加弹窗提示
                    continue  # 跳过当前循环
                # 3. 获取结果并校验是否为有效字典
                result = imageProcess_thread.get_result()
                if not isinstance(result, dict):
                    logging.warning(f"处理结果异常：不是字典类型，值为 {result}")
                    continue
                # 4. 校验是否有错误信息
                if result.get("error") is not None:
                    logging.warning(f"图像处理失败：{result['error']}")
                    continue
                # 5. 校验关键数据是否存在且有效
                if "result_img" not in result or "processed_count" not in result:
                    logging.warning("处理结果不完整：缺少关键字段")
                    continue
                stitched_img = result['result_img']
                processed_count = result['processed_count']
                # 时间戳取保存该张图片的时刻，微秒级唯一；OneNET 按文件名判重，必须保证 basename 唯一
                save_time = datetime.now().strftime("%y%m%d-%H%M%S%f")
                file_time = save_time[2:6] + '-' + save_time[7:19]  # 月日-时分秒-微秒（去掉年，作图片文件名前缀，避免云端按文件名判重撞名）
                saved1 = cv2.imwrite(folder_path + '/' + f"{file_time}-{str(suc_time + 1).zfill(4)}.bmp", stitched_img)  # 标记后的图片
                saved2 = cv2.imwrite(folder_path + '/' + f"{file_time}-{str(suc_time + 1).zfill(4)}_0.bmp", frame)  # 原图
                if not saved1:
                    logging.warning(f'保存处理后图片失败: {file_time}-{str(suc_time + 1).zfill(4)}.bmp')
                if not saved2:
                    logging.warning(f'保存原图失败: {file_time}-{str(suc_time + 1).zfill(4)}_0.bmp')
                num.append(processed_count)

                suc_time = suc_time + 1

                # 实时计算平均值
                aver_num = sum(num) / len(num)
                # aver_num = aver_num * 3 / 0.00321 / 10000     # 放大倍数2x
                aver_num = 0.3433 * aver_num - 2.8141      # 标曲 y=0.3433x-2.8141
                if aver_num < 0:
                    aver_num = 0
                self.signal_refreshScroll.emit(folder_path, aver_num)  # 更新scroll中的图片
            
            else:
                logging.warning("一键采集：微泵应答失败！")
                logging.warning(f"指令 = [{data}]")
                logging.warning(f"应答 = [{list(response)}]")
                continue
                # QMessageBox.critical(self, "Error", "微泵进样失败！")

            # 回收内存
            del frame
            del result
            del stitched_img
            del imageProcess_thread
            gc.collect()
            gc.collect()

            # 打印信息
            logging.info(f"已成功采集{suc_time}次图像  {suc_time}/{try_time}")
            self.signal_step.emit(f"微泵采集 {suc_time}/{self.repeat_num}")
            self.temp_delay(500)

        try:
            # 统一保存数据至 CSV 中（O(1) 追加写入）
            if self._save_to_csv(num, current_time):
                # 刷新图表数据（从文件夹中重新读取）！！！！！
                self.signal_refreshChartData.emit()
                # 投递云上传任务（UploadThread 后台执行，不阻塞本线程）
                self.signal_uploadNumbers.emit(len(num), aver_num)
                self.signal_uploadImages.emit(folder_path, len(num), aver_num)

            # 07-清空流道（把奶样冲出流道即可，不用完全排出）
            self.signal_step.emit("⑧ 清空流道")
            data = [0xFF] + [self.cmd_list['样池排空']] + self.decimal_2_hex_bytes(4, 85000) + [0x01] + self.decimal_2_hex_bytes(2, 39) + self.decimal_2_hex_bytes(2, 143) + [0xFE]
            self.ser_thread.signal_sendData.emit(data)
            response = self.waitForAnswer('样池排空')
            if self._verify_response(response, data):
                logging.info("一键采集：清空流道应答成功！")
            else:
                logging.warning("一键采集：清空流道应答失败！")
                logging.warning(f"指令 = [{data}]   应答 = [{list(response)}]")
                self.signal_openKey.emit()  # 重新开启按钮点击功能
                self.is_running = False  # 重置执行标志
                return
        except Exception as e:
            logging.error(f"保存数据过程报错：{e}")

        # # 08-清洗剂填充混样池（填充60%就行）（同时开启振动电机）
        # data = [0xFF, 0x0C, 0x01, 0xFE]
        # self.ser_thread.signal_sendData.emit(data)
        # self.msleep(100)  # 开启振动电机后延时一会
        #
        # data = [0xFF] + [self.cmd_list['清洗']] + self.decimal_2_hex_bytes(4, 12800) + self.decimal_2_hex_bytes(2, 39) + self.decimal_2_hex_bytes(2, 143) + [0xFE]
        # # data = [0xFF, 0x0B, 0x00, 0x00, 0x32, 0x00, 0x00, 0x4f, 0x00, 0x8f, 0xFE]
        # self.ser_thread.signal_sendData.emit(data)
        # response = self.waitForAnswer(self.cmd_list['清洗'])
        # if list(response) == data:
        #     print("一键采集：混样池清洗应答成功！")
        # else:
        #     print("一键采集：混样池清洗应答失败！")
        #     return
        #
        # # 09-排空清洗剂（随后关闭振动电机）
        # data = [0xFF] + [self.cmd_list['样池排空']] + self.decimal_2_hex_bytes(4, 92160) + self.decimal_2_hex_bytes(2, 39) + self.decimal_2_hex_bytes(2, 143) + [0xFE]
        # # data = [0xFF, 0x09, 0x00, 0x01, 0x68, 0x00, 0x00, 0x27, 0x00, 0x8F, 0xFE]  # 要调整下
        # self.ser_thread.signal_sendData.emit(data)
        # response = self.waitForAnswer(self.cmd_list['样池排空'])
        # if list(response) == data:
        #     print("一键采集：清洗剂排空应答成功！")
        # else:
        #     print("一键采集：清洗剂排空应答失败！")
        #     return
        #
        # data = [0xFF, 0x0C, 0x00, 0xFE]
        # self.ser_thread.signal_sendData.emit(data)
        # self.msleep(100)  # 关闭振动电机后延时一会

        # 10-结束
        self.signal_step.emit("✓ 检测完成")
        self.signal_openKey.emit()  # 重新开启按钮点击功能
        logging.info(f"一键采集：全流程完毕！！！")

        # self.restart_times = self.restart_times + 1
        # if self.restart_times > 200:
        #     self.restart_times = 0
        #    data = [0xFF] + [self.cmd_list['重启']] + [0xFE]
        #     self.ser_thread.signal_sendData.emit(data)
        #     logging.info(f"下位机重启...")
            
        self.is_running = False  # 重置执行标志



# 流量计线程
class FlowMeter_Thread(QThread):
    signal_refreshFlow = pyqtSignal(float)  # 流量刷新signal
    signal_triggerCountCell = pyqtSignal()  # 触发自动计数

    def __init__(self, ser_thread, countCell_thread):
        super().__init__()
        self.loop = None
        self.serthread = ser_thread
        self.countCell_thread = countCell_thread
        self.cmd_request = [0xFF, 0x08, 0xFE]  # 请求流量计数据（帧长由send_data自动添加）
        self.seconds_for_sampling = 1000  # 采样间隔
        self.refresh_n = 3  # 采样n次后刷新屏显流量数据
        # 数据存储列表：初始化self.refresh_n个空数据，方便调用列表中最后self.refresh_n个数据来计算流量平均值流量
        self.single_production = [0] * self.refresh_n
        self.total_production = 0  # 总奶量
        self.PULSES_PER_LITER = 150  # 每升脉冲数（150脉冲=1L，需实测标定）
        self.calibration = 0.2034 * 1.8194  # 流量校准系数（首次实测后：量筒实测体积L / 上位机示值L，改这里即可）

        self.n = 0  # 计数变量，当计数5时触发刷新实时显示流量的函数
        self.start_threshold = 0.15 * self.calibration  # 流量统计起始阈值（原始0.15 L/s × 校准系数）
        self.end_threshold = 0.01 * self.calibration  # 流量统计结束阈值（原始0.01 L/s × 校准系数）
        # 有效触发窗口（L/min）：正常奶流量<10，正式采奶前开真空会使流量冲到100+ L/min，
        # 需过滤该尖峰；仅当流量稳定在窗口内才触发采奶检测
        self.DETECT_FLOW_MIN_LMIN = 3.0    # 有效流量下界（L/min）
        self.DETECT_FLOW_MAX_LMIN = 8.0    # 有效流量上界（L/min），高于此视为尖峰干扰忽略
        self.STABILIZE_SAMPLES = 3         # 流量需连续稳定在窗口内这么多次采样（每秒1次）才触发
        self._in_window_count = 0          # 连续稳定在窗口内的采样计数

        self.flow_started = False  # 流量开始统计标志位
        self.flow_test_mode = False  # 流量测试页标志位（True=在流量测试页时屏蔽自动触发计数）
        self.flow_test_running = False  # 流量测试进行中标志位（True=计量中时屏蔽自动触发计数）
        self.cleaning_running = False  # 清洗进行中标志位（True=清洗中屏蔽自动触发计数）
        self.n = 0

        self.flow_logger = logging.getLogger('flowmeter')

    def temp_delay(self, delay_ms):
        """函数内临时非阻塞延时，delay_ms：毫秒数"""
        loop = QEventLoop()
        QTimer.singleShot(delay_ms, loop.quit)  # 延时后退出临时事件循环
        loop.exec_()  # 启动临线时循环（非阻塞当前程的主循环）


    def run(self):
        self.loop = QEventLoop()

        timer = QTimer()
        timer.timeout.connect(self.requestFlowData)
        timer.start(self.seconds_for_sampling)  # 1s请求一次流量数据

        self.loop.exec()

    def stop(self):
        """退出清理（非阻塞）：退出流量线程事件循环。不调用 wait，避免阻塞主线程。"""
        if getattr(self, 'loop', None):
            self.loop.quit()

    def requestFlowData(self):
        self.n += 1
        # print(self.n)
        flow_aver = 0
        try:
            if self.serthread.com_isconnect():
                # 请求流量数据
                self.serthread.signal_sendData.emit(self.cmd_request)
                response = self.waitForAnswer(self.cmd_request[1])
                if list(response)[0] == self.cmd_request[0] and list(response)[-1] == self.cmd_request[-1]:
                    flow_data = (response[3] << 8) | response[4]
                    # if flow_data > 100:
                    #     flow_data = 0
                    self.single_production.append(flow_data / self.PULSES_PER_LITER * self.calibration)  # 脉冲数转录为流量（乘校准系数）
                    # print('flow_data:{}'.format(flow_data))
                    # print('self.single_production[-1]:{}'.format(self.single_production[-1]))
                    # print("({})流量计应答成功！-> 当前流量：{}L".format(self.n, self.single_production[-1]), flush=True)
                else:
                    self.flow_logger.warning(f"流量计应答失败！")
                    self.single_production.append(0)

                # 功能一：计算并刷新流量数据，取末尾3个数，保留4位小数
                flow_aver = round(sum(self.single_production[-self.refresh_n:]) / self.refresh_n, 4)
                # print('平均流量：{:.2f}'.format(flow_aver))
                self.signal_refreshFlow.emit(flow_aver)
                self.flow_logger.info(f"({self.n}) 当前流量{self.single_production[-1]:.2f} 平均流量{flow_aver:.2f}")
                mem = psutil.virtual_memory()
                # self.flow_logger.info(f"系统总内存：{mem.total / 1024 / 1024:.2f}MB | 已用：{mem.used / 1024 / 1024:.2f}MB | 程序占用：{psutil.Process(os.getpid()).memory_info().rss / 1024 / 1024:.2f}MB")

                # 功能二：流量统计（在流量测试页/计量中/清洗中时屏蔽自动触发计数）
                if not (self.flow_test_mode or self.flow_test_running or self.cleaning_running):
                    flow_lmin = flow_aver * 60  # 平均流量 L/min
                    flow_cur_lmin = self.single_production[-1] * 60  # 当前次采样流量 L/min
                    if self.flow_started == False:
                        # 平均流量 AND 当前流量都必须落在有效窗口内，连续 STABILIZE_SAMPLES 次才视为采奶开始。
                        # 平均流量用滑动窗口（初值0）会被瞬时脉冲拉成假稳定段，故必须叠加当前流量门槛，
                        # 否则开机头几秒的瞬时脉冲会误触发自动检测。
                        if (self.DETECT_FLOW_MIN_LMIN <= flow_lmin <= self.DETECT_FLOW_MAX_LMIN and
                                self.DETECT_FLOW_MIN_LMIN <= flow_cur_lmin <= self.DETECT_FLOW_MAX_LMIN):
                            self._in_window_count += 1
                            if self._in_window_count >= self.STABILIZE_SAMPLES:
                                self._in_window_count = 0
                                self.flow_started = True
                                self.countCell_thread.signal_countCell.emit()  # 触发信号
                        else:
                            self._in_window_count = 0  # 出窗（流量过低或尖峰过高）清零稳定计数

                    elif (self.flow_started == True) and (flow_aver < self.end_threshold):
                        self.flow_started = False
                        self.total_production = sum(self.single_production)  # 统计总流量，后续用于分析
                        self.single_production.clear()  # 清空列表

            else:
                self.flow_logger.warning(f"串口未连接")

        except Exception as e:
            self.flow_logger.warning(f"报错：{e}")

    def get_current_flow(self):
        """读取当前流量均值（L/s）：取最近 refresh_n 个采样平均，供清洗流程阈值判断"""
        if not self.single_production:
            return 0.0
        return round(sum(self.single_production[-self.refresh_n:]) / self.refresh_n, 4)

    def waitForAnswer(self, cmd):
        """
        等待串口应答（基于 QWaitCondition，分段等待 + 间隙处理事件循环）
        :param cmd: 指令序号（int）
        :return: 应答数据(bytes)；超时返回占位帧 bytes([0xFF, 0x00, 0x00, 0xFF]) 保持调用方兼容
        """
        # 分段等待，间隙处理事件循环保持线程响应性
        data = self.serthread.wait_for_answer(cmd, timeout_ms=500, process_events=self.loop.processEvents)
        if not data:
            self.flow_logger.warning(f"下位机超时无应答！")
            return bytes([0xFF, 0x00, 0x00, 0xFF])  # 占位帧，调用方原逻辑使用 list 索引
        return data


# 清洗流程线程
class Cleaning_Thread(QThread):
    """清洗模式硬件流程：
    1. 等待检测(countCell_thread)结束，未结束则等它完成
    2. 轮次监测（流量计自动判定）：流量升到起始阈值视为新一轮开始，
       跑一轮完整渐进循环（1x,1.5x,...,6x 共约11轮，每轮=抽入n倍+排空n倍），
       小水量快排空，尽快稀释容器内污物浓度；流量降到结束阈值视为本轮结束，等待下一轮
    3. 整个清洗结束（状态切回"工作"触发 request_abort()）时执行一次收尾：
       抽入4x + 排空5x，彻底清空容器及管道内残留液体（重点冲洗容器底部）
    仅使用 奶样泵(0x03) 和 排空泵(0x09)。
    注：清洗为手动控制，本线程不负责状态自动切换。
    """
    # 清洗参数（实验标定后可修改）
    MILK_WASH_PULSES = 25000  # 基准：奶路清洗(sampleWash)的脉冲数，抽入以它为基准
    PROGRESS_STEP = 0.5       # 渐进循环每轮增加0.5倍基准脉冲
    PROGRESS_MAX = 6.0        # 渐进到6倍基准脉冲为止（1x,1.5x,2x,...,6x 共约11轮）
    FINAL_DRAW_MULT = 4.0     # 收尾抽入倍数（4x=100000），冲刷容器底部
    FINAL_EMPTY_MULT = 5.0    # 收尾排空倍数（5x=125000），彻底清空容器与管道
    FLOW_START_LMIN = 3.0     # 轮次开始阈值（L/min）：流量≥该值视为新一轮开始
    FLOW_MAX_LMIN = 8.0       # 轮次开始流量上界（L/min）：超出视为真空尖峰干扰，忽略
    FLOW_END_LMIN = 0.5       # 轮次结束阈值（L/min）：流量<该值视为本轮结束
    CMD_MILK = 0x03           # 奶样泵（奶样进样）
    CMD_EMPTY = 0x09          # 排空泵（样池排空）
    # 泵速统一按奶样泵速度 ARR=39/PSC=143（比样池排空的 59/143 快，清洗时两泵同速提高效率，避免排空时间过长）

    def __init__(self, ser_thread, flow_thread, countCell_thread):
        super().__init__()
        self.ser_thread = ser_thread
        self.flow_thread = flow_thread
        self.countCell_thread = countCell_thread
        self._start_flag = False  # 主线程置位 → run 轮询到后开始清洗
        self._abort = False       # 主线程置位 → 中止循环（仍执行最后排空）
        self._active = False      # 当前是否正在执行清洗
        self._stop = False        # 退出清理标志 → run 循环退出

    # ---- 主线程调用 ----
    def request_start(self):
        if self._active:
            logging.info("清洗：当前清洗流程仍在进行，忽略重复触发")
            return
        self._start_flag = True

    def request_abort(self):
        if self._active:
            logging.info("清洗：收到中止请求（状态切回工作），结束轮次监测后执行收尾清空")
        self._abort = True

    # ---- 线程主体 ----
    def run(self):
        while not self._stop:
            if self._start_flag:
                self._start_flag = False
                try:
                    self._do_cleaning()
                except Exception as e:
                    logging.error(f"清洗流程异常: {e}")
                finally:
                    self._active = False
                    self.flow_thread.cleaning_running = False
            self._temp_delay(300)

    def stop(self):
        """退出清理（非阻塞）：中止清洗并置退出标志。不调用 wait，避免阻塞主线程。"""
        self._abort = True   # 中止当前清洗（线程会在最后排空后结束）
        self._stop = True

    def _temp_delay(self, delay_ms):
        """非阻塞延时（局部事件循环）"""
        loop = QEventLoop()
        QTimer.singleShot(delay_ms, loop.quit)
        loop.exec_()

    def _do_cleaning(self):
        """执行一次清洗流程（异常由 run 捕获，无需返回值）"""
        self._abort = False
        self._active = True
        self.flow_thread.cleaning_running = True
        logging.info("清洗流程开始：等待检测完成...")
        # 1. 等待当前检测结束（检测未完成则等它完成）
        while self.countCell_thread.is_running:
            if self._abort:
                logging.info("清洗：等待检测期间被中止，取消本次清洗")
                return
            self._temp_delay(500)
        logging.info("清洗：检测已结束，进入轮次监测")
        # 2. 轮次监测（流量计自动判定）：
        #    流量升到起始阈值 → 新一轮开始，跑一轮完整渐进循环(1x~6x)
        #    流量降到结束阈值 → 本轮结束，等待下一轮（轮间有几分钟停歇）
        #    一轮渐进循环完成后若流量仍高（同一轮未结束），不会重复触发
        did_cycle = False  # 是否至少执行过一轮渐进循环（决定是否做收尾）
        in_round = False   # 当前是否已在本轮内（防止同一轮重复触发）
        while not self._abort:
            # get_current_flow 返回 L/s，×60 换算成 L/min 与界面显示/阈值单位一致
            flow_lmin = self.flow_thread.get_current_flow() * 60
            if (not in_round) and self.FLOW_START_LMIN <= flow_lmin <= self.FLOW_MAX_LMIN:
                in_round = True
                did_cycle = True
                logging.info(f"清洗：检测到新一轮（流量 {flow_lmin:.2f}L/min≥{self.FLOW_START_LMIN}），执行渐进循环")
                self._run_progressive_cycle()
            elif flow_lmin < self.FLOW_END_LMIN:
                if in_round:
                    logging.info(f"清洗：流量 {flow_lmin:.2f}L/min<{self.FLOW_END_LMIN}，本轮结束，等待下一轮")
                in_round = False
            # 无条件延时让出 CPU，避免空转（流量为0的停歇期最频繁）
            if not self._abort:
                self._temp_delay(500)
        # 3. 收尾（整个清洗结束/状态切回工作）：抽入4x + 排空5x
        #    彻底清空容器及管道内残留液体（重点冲刷容器底部）
        if did_cycle:
            final_draw = int(self.MILK_WASH_PULSES * self.FINAL_DRAW_MULT)
            final_empty = int(self.MILK_WASH_PULSES * self.FINAL_EMPTY_MULT)
            logging.info(f"清洗：收尾 奶样泵抽入 {final_draw} 脉冲（冲刷容器底部）")
            self._send_pump(self.CMD_MILK, final_draw)
            logging.info(f"清洗：收尾 排空泵排空 {final_empty} 脉冲（彻底清空容器与管道）")
            self._send_pump(self.CMD_EMPTY, final_empty)
            logging.info("清洗流程完成")
        else:
            logging.info("清洗：未执行任何轮次，跳过收尾")

    def _run_progressive_cycle(self):
        """一轮完整渐进循环：从1倍基准脉冲开始，每轮增加0.5倍，直至6倍（1x,1.5x,...,6x 共11轮）。
        每轮 = 抽入 n 倍脉冲 + 排空同样 n 倍脉冲。
        小水量快进快出，尽快稀释容器内污物浓度（污物主要沉积在容器底部）。
        中止请求：完成当前轮次（抽入+排空）后停止渐进，由主流程决定是否收尾。
        """
        mult = 1.0
        cycle_no = 1
        while mult <= self.PROGRESS_MAX:
            pulses = int(self.MILK_WASH_PULSES * mult)
            logging.info(f"清洗：渐进 第{cycle_no}轮（{mult}x），奶样泵抽入 {pulses} 脉冲")
            self._send_pump(self.CMD_MILK, pulses)
            logging.info(f"清洗：渐进 第{cycle_no}轮（{mult}x），排空泵排空 {pulses} 脉冲")
            self._send_pump(self.CMD_EMPTY, pulses)
            cycle_no += 1
            mult += self.PROGRESS_STEP
            if self._abort:
                # 完成当前轮次的抽入+排空后才停下，保证容器不残留液体
                logging.info("清洗：渐进循环期间收到中止请求，已完成当前轮次抽入+排空，停止渐进")
                break

    def _send_pump(self, cmd_code, pulses):
        """发送泵指令并等待下位机应答（方向0x01；泵速统一用奶样泵速度 ARR=39/PSC=143，
        比样池排空的 59/143 快，避免排空时间过长）"""
        if not self.ser_thread.com_isconnect():
            logging.warning("清洗：串口未连接，跳过泵指令")
            return False
        data = [0xFF] + [cmd_code] + self.decimal_2_hex_bytes(4, pulses) + [0x01] + \
               self.decimal_2_hex_bytes(2, 39) + self.decimal_2_hex_bytes(2, 143) + [0xFE]
        logging.debug(f"清洗发送：{bytes(data).hex(sep=' ').upper()}")
        self.ser_thread.signal_sendData.emit(data)
        response = self.ser_thread.wait_for_answer(cmd_code, timeout_ms=90000)
        if response and len(response) >= 4 and response[0] == 0xFF and response[-1] == 0xFE:
            logging.info(f"清洗：指令0x{cmd_code:02X} 应答成功")
            return True
        logging.warning(f"清洗：指令0x{cmd_code:02X} 应答失败或超时")
        return False

    @staticmethod
    def decimal_2_hex_bytes(n, num):
        hex_list = []
        for i in range(n):
            hex_list.insert(0, num & 0xFF)
            num = num >> 8
        return hex_list


# 图像处理线程
class ImageProcessThread(QThread):
    process_finished = pyqtSignal(dict)
    def __init__(self):
        super().__init__()
        self.image = None
        self.result = None  # 存储处理结果
        self.is_processing = False  # 处理中标记
        self.mutex = QMutex()
        self.cond = QWaitCondition()  # 条件变量（用于非阻塞等待）

        # DoG 圆顶匹配细胞计数器（复用实例，避免每帧重建）
        # 算法参数可在 new_dog.DEFAULT_PARAMS 中查看，需要微调时传 params={...}
        self._counter = DogCellCounter()

    def set_image(self, image):
        """设置待处理图像，重置状态"""
        with QMutexLocker(self.mutex):
            self.image = image
            self.result = None
            self.is_processing = True

    def get_result(self):
        """获取处理结果（线程安全）"""
        with QMutexLocker(self.mutex):
            return self.result

    def is_finished(self):
        """判断是否处理完成（线程安全）"""
        with QMutexLocker(self.mutex):
            return not self.is_processing and self.result is not None

    def process_single_image(self, img):
        """
        单张图完整流程：调用 new_dog.DogCellCounter 完成计数 + 彩色叠加
        :return: (cell_num, overlay_img)  与原接口约定一致
        """
        # save_compare=False：上位机实时计数不写磁盘，避免 IO 抖动
        # 需要保存四联对比图时传 save_compare=True, img_name="xxx"
        return self._counter.count(img)

    def run(self):
        """执行耗时图像处理"""
        # 定义局部变量，用于存储从共享变量读取的值（全程无锁使用）
        local_image = None
        try:
            # 1. 先加锁检查图像是否有效
            with QMutexLocker(self.mutex):
                if self.image is None:
                    self.result = {"error": "无待处理图像"}
                    self.is_processing = False
                    self.cond.wakeAll()  # 唤醒等待的线程
                    self.process_finished.emit(self.result)
                    return

                local_image = self.image.copy()  # 深拷贝，避免原图像被外部修改

            logging.debug("图像处理线程：开始计数")
            cell_num = 0
            result_img = None
            # 2. 耗时处理逻辑（体细胞计数）- 这里不需要持锁，避免阻塞
            if local_image is not None:
                cell_num, result_img = self.process_single_image(local_image)
                logging.debug("图像处理线程：计数完成")

            # 4. 保存结果（加锁保证线程安全）
            with QMutexLocker(self.mutex):
                self.result = {
                    "result_img": result_img,
                    "processed_count": cell_num,
                    "error": None
                }
                self.is_processing = False
                self.cond.wakeAll()  # 处理完成，唤醒等待的线程

        except Exception as e:
            # 异常处理（加锁保证状态一致）
            with QMutexLocker(self.mutex):
                self.result = {"error": f"处理失败：{str(e)}"}
                self.is_processing = False
                self.cond.wakeAll()
            self.process_finished.emit(self.result)

    def wait_for_finish(self, timeout_ms=10000):
        """非阻塞等待处理完成（超时时间：10秒）
        返回值：True=处理完成，False=超时/未完成
        """
        # 1. 先加锁（QMutexLocker会自动锁定self.mutex）
        locker = QMutexLocker(self.mutex)

        # 2. 循环等待：防止虚假唤醒（Qt官方推荐做法）
        wait_result = False
        start_time = self.currentTime()  # 记录开始等待时间
        remaining_time = timeout_ms

        while self.is_processing and remaining_time > 0:
            # 关键修复：wait的第一个参数是QMutex（self.mutex），不是QMutexLocker
            # wait会自动解锁mutex，等待条件满足后重新加锁
            if not self.cond.wait(self.mutex, remaining_time):
                break  # 超时退出

            # 更新剩余等待时间
            elapsed_time = self.currentTime() - start_time
            remaining_time = max(0, timeout_ms - elapsed_time)

        # 3. 判断最终状态
        if not self.is_processing and self.result is not None:
            wait_result = True

        # 4. QMutexLocker会在函数结束时自动解锁
        return wait_result

    def currentTime(self):
        """获取当前毫秒级时间（兼容PyQt5）"""
        from PyQt5.QtCore import QDateTime
        return QDateTime.currentMSecsSinceEpoch()


'''云上传线程：独立线程消费任务队列，上传数字+图片到 OneNET，不阻塞 UI'''
class UploadThread(QThread):
    def __init__(self, uploader, parent=None):
        super().__init__(parent)
        self.uploader = uploader
        self.task_queue = queue.Queue()  # 上传任务队列（线程安全）
        self._stop = False

    def stop(self):
        self._stop = True
        # 清空未完成任务（退出时不强制上传，避免阻塞退出）
        while True:
            try:
                self.task_queue.get_nowait()
            except queue.Empty:
                break

    def add_task(self, task):
        """投递一个上传任务（线程安全，O(1) 不阻塞调用方）
        task 格式：
            {"type": "numbers", "img_num": int, "cell_count": float}         数字上传
            {"type": "images", "folder": str, "img_num": int, "cell_count": float}  图片上传
            {"type": "status", "value": int}                                  状态切换（上报+广播）
        """
        self.task_queue.put(task)

    def run(self):
        while not self._stop:
            try:
                task = self.task_queue.get(timeout=0.5)
            except queue.Empty:
                continue
            try:
                self._handle(task)
            except Exception as e:
                logging.error(f"云上传任务失败: {e}")

    def _handle(self, task):
        ttype = task.get("type")
        if ttype == "numbers":
            self._upload_numbers(task)
        elif ttype == "images":
            self._upload_images(task)
        elif ttype == "status":
            self._upload_status(task)

    def _upload_numbers(self, task):
        """上传数字数据（图片张数 + 平均体细胞数）"""
        ok = self.uploader.publish(task["img_num"], task["cell_count"])
        if ok:
            logging.info(f"云上传成功：img_num={task['img_num']}, cell_count={task['cell_count']:.2f}")
        else:
            logging.warning(f"云上传失败：数字数据（img_num={task['img_num']}）")

    def _upload_images(self, task):
        """上传图片：逐个上传拿 fid，最后把最新 fid 随数字一起上报。
        只上传原图（文件名以 _0.bmp 结尾），处理后的图片不上传云端。"""
        folder = task["folder"]
        if not os.path.isdir(folder):
            logging.warning(f"云上传：图片目录不存在 {folder}")
            return
        files = sorted(
            f for f in os.listdir(folder)
            if f.lower().endswith('_0.bmp')  # 仅原图
        )
        if not files:
            logging.warning(f"云上传：目录 {folder} 没有图片")
            return
        fids = []
        for fn in files:
            path = os.path.join(folder, fn)
            fid = self.uploader.upload_image_to_onenet(
                path,
                ONENET_CONFIG["api_access_key"],
                ONENET_CONFIG["user_id"],
            )
            if fid:
                fids.append(fid)
                logging.info(f"云上传图片：{fn} -> fid={fid}")
            else:
                logging.warning(f"云上传图片失败：{fn}")
        if fids:
            self.uploader.publish_with_fid(task["img_num"], task["cell_count"], fids[-1])

    def _upload_status(self, task):
        """状态切换：先上报本机状态到云端记录，再广播给其它设备（双向）"""
        value = task["value"]
        logging.info(f"状态切换上报前 MQTT连接状态: _connected={self.uploader._connected}")
        self.uploader.publish_status(value)
        ok_devices = self.uploader.broadcast_status(value)
        logging.info(f"状态切换处理完成：status={value}，广播成功 {len(ok_devices)} 台设备")


class Window_added(QMainWindow, Ui_MainWindow):
    status_changed = pyqtSignal(int)  # 云端下发的 status 变化（跨线程到主线程）
    status_synced = pyqtSignal(int)   # 重启对齐完成，携带由在线设备多数态得到的 status

    def __init__(self):
        super(Window_added, self).__init__()
        self.setupUi(self)

        # Linux缺少Windows设计字体时，L/min会变宽；固定留足宽度，避免UI重生成后再次被裁切。
        self.page21_label_ml_2.setMinimumWidth(80)
        self.page21_label_ml_2.resize(80, self.page21_label_ml_2.height())

        # 首页新加的三个控件位于背景图右侧，确保文字清晰且始终在最上层。
        self.page1_label_average_3.setStyleSheet(
            "color: rgb(0, 0, 0); background-color: rgb(226, 226, 226);")
        self.page1_label_cell_num_3.setStyleSheet(
            "color: rgb(0, 0, 0); background-color: rgb(255, 255, 255); border-radius: 10px;")
        self.page1_label_ml_3.setStyleSheet(
            "color: rgb(0, 0, 0); background-color: rgb(226, 226, 226);")
        self.page21_label_average_3.setStyleSheet(
            "color: rgb(0, 0, 0); background-color: rgb(226, 226, 226);")
        self.page21_label_cell_num_3.setStyleSheet(
            "color: rgb(0, 0, 0); background-color: rgb(255, 255, 255); border-radius: 10px;")
        self.page21_label_ml_3.setStyleSheet(
            "color: rgb(0, 0, 0); background-color: rgb(226, 226, 226);")
        for label in (self.page1_label_average_3,
                      self.page1_label_cell_num_3,
                      self.page1_label_ml_3,
                      self.page21_label_average_3,
                      self.page21_label_cell_num_3,
                      self.page21_label_ml_3):
            label.raise_()

        # 确保数据目录存在（scc_img / focus / captured）
        ensure_data_dirs()

        # 日志面板：把 warning/error 等关键日志实时显示到计数测试页右侧的 listWidget
        self.log_bridge = QtLogBridge()
        self.log_bridge.setFormatter(logging.Formatter('%(asctime)s %(levelname)s: %(message)s', '%H:%M:%S'))
        self.log_bridge.setLevel(logging.WARNING)
        self.log_bridge.log_signal.connect(self._on_log_msg)
        self.log_bridge.log_signal.connect(self._on_flowtest_log_msg)
        logging.getLogger().addHandler(self.log_bridge)

        # listWidget 基础样式（深色底 + 自动换行）
        self.listWidget.setWordWrap(True)
        self.listWidget.setVerticalScrollMode(QAbstractItemView.ScrollPerPixel)
        self.listWidget.setStyleSheet(
            "#listWidget{background-color:rgb(25,25,25);border:1px solid rgb(80,80,80);"
            "border-radius:6px;color:rgb(220,220,220);}"
        )

        # 去上边框
        # self.setWindowFlags(QtCore.Qt.FramelessWindowHint | QtCore.Qt.WindowStaysOnTopHint)
        self.setWindowFlags(QtCore.Qt.FramelessWindowHint)
        # # 去下边框
        # self.setStatusBar(None)

        # 相机线程
        self.camera_thread = CameraThread()
        self.camera_thread.new_frame.connect(self.update_frame)  # 连接信号
        self.camera_thread.start()

        self.frame = []  # 相机实时刷新画面
        self.flip_h = False
        self.flip_v = False

        # 相机基础参数 初值
        self.brightness = 0
        self.hue = 0
        self.saturation = 64
        self.contrast = 37
        self.gamma = 300
        self.gain = 64
        self.exposure = -6

        self.camera_parameters_file = os.path.join(get_app_dir(), 'camera_parameters.json')  # 相机参数文件
        self.scc_history_file = os.path.join(get_app_dir(), 'scc_history.csv')  # 历史数据文件

        # 旧文件自动迁移（首次运行时将 .xlsx 转为 .json/.csv）
        self._migrate_old_files()

        # 串口线程，默认连接 /dev/ttyS3
        self.serial_thread = SerialThread()
        self.serial_thread.signal_serialLED.connect(self.homePage_setLED)
        self.serial_thread.start()
        # 自动连接指定串口 /dev/ttyS3：该串口存在才连接，不存在则不连接任何串口
        if os.path.exists('/dev/ttyS3'):
            logging.info('检测到 /dev/ttyS3，自动连接...')
            self.serial_thread.signal_serialConnect.emit('/dev/ttyS3')
        else:
            logging.warning('未检测到 /dev/ttyS3，本次启动不连接任何串口')

        # 自动对焦线程
        self.autoFocus_thread = AutoFocus_Thread(self.serial_thread, self.camera_thread)
        self.autoFocus_thread.start()

        # 测试计数线程
        self.countCell_thread = CountCell_Thread(self.serial_thread, self.camera_thread)
        self.countCell_thread.signal_clearScroll.connect(self.clear_scroll)
        self.countCell_thread.signal_refreshScroll.connect(self.refresh_scroll)
        self.countCell_thread.signal_refreshChartData.connect(self.Refresh_data)
        self.countCell_thread.signal_openKey.connect(self.Open_Key)
        self.countCell_thread.signal_step.connect(self._on_step)
        self.countCell_thread.start()

        # 云上传线程（OneNET）：独立后台线程 + 任务队列，上传数字/图片不阻塞UI
        self.uploader = OneNETUploader()
        # 建立 MQTT 连接（后台执行，避免阻塞 UI 启动；连接前上报/广播会被跳过）
        threading.Thread(target=self.uploader.connect, daemon=True).start()
        self.upload_thread = UploadThread(self.uploader)
        self.countCell_thread.signal_uploadNumbers.connect(self._enqueue_upload_numbers)
        self.countCell_thread.signal_uploadImages.connect(self._enqueue_upload_images)
        self.upload_thread.start()

        # 工作/清洗状态（0=工作, 1=清洗）：初始为工作
        self._work_status = onenet_uploader.STATUS_WORK
        # 接收云端下发的 status：MQTT线程回调 -> Qt信号切回主线程
        self.uploader.set_control_callback(self._on_cloud_status)
        self.status_changed.connect(self._apply_status)
        # 重启对齐：MQTT 连接就绪后，后台统计在线设备多数态并应用（不回广播）
        self._shutting_down = False  # 退出标志，供重启对齐线程随退出提前中断
        self.status_synced.connect(self._apply_synced_status)
        threading.Thread(target=self._sync_status_at_startup, daemon=True).start()

        # 加载模型
        # self.imageProcess_thread.model, self.imageProcess_thread.model_classes = detect_cell.load_model()

        # 流量计线程
        self.flow_thread = FlowMeter_Thread(self.serial_thread, self.countCell_thread)
        self.flow_thread.signal_refreshFlow.connect(self.refresh_flow)
        self.flow_thread.start()

        # 清洗流程线程：状态切换为"清洗"时启动，切回"工作"时中止
        self.cleaning_thread = Cleaning_Thread(self.serial_thread, self.flow_thread, self.countCell_thread)
        self.cleaning_thread.start()

        # 流量测试：状态初始化
        self.flow_test_running = False        # 是否正在计量
        self.flow_test_total = 0.0            # 累计总流量 (L)
        self.flow_test_start_time = None      # 计量起始时间
        self.flow_test_timer = QTimer(self)   # 每秒刷新测试时长
        self.flow_test_timer.timeout.connect(self._update_flow_test_duration)
        self.flowtest_toolbutton_start.clicked.connect(self._on_flowtest_start_clicked)
        self.flowtest_toolbutton_reset.clicked.connect(self._on_flowtest_reset_clicked)
        # 流量测试日志面板样式（与计数测试页 listWidget 一致）
        self.flowtest_listwidget_log.setWordWrap(True)
        self.flowtest_listwidget_log.setVerticalScrollMode(QAbstractItemView.ScrollPerPixel)
        self.flowtest_listwidget_log.setStyleSheet(
            "#flowtest_listwidget_log{background-color:rgb(25,25,25);border:1px solid rgb(80,80,80);"
            "border-radius:6px;color:rgb(220,220,220);}"
        )
        self.flowtest_label_status.setTextFormat(Qt.RichText)
        self._set_flowtest_status('就绪', '#2ecc71')

        # 体细胞图片路径
        self.image_folder = os.path.join(get_app_dir(), 'scc_img')
        # 存储文件夹中的文件名字
        self.last_seen_files = set()

        # 设置一个用于显示滚动图像的垂直布局
        self.scroll_layout = QVBoxLayout()
        self.scroll_layout.setSpacing(20)
        # self.scroll_layout.setAlignment(Qt.AlignHCenter)
        self.container.setLayout(self.scroll_layout)

        # 设置默认页面
        self.stackedWidget.setCurrentIndex(0)
        self.page2_stackedwidget_test.setCurrentIndex(0)
        self.page4_stackedwidget_maintain.setCurrentIndex(0)

        # 槽函数 P1-P4页面切换
        self.page1_toolbutton_home.clicked.connect(lambda: self.stackedWidget.setCurrentIndex(0))
        self.page2_toolbutton_test.clicked.connect(self.open_test_page_with_password)
        self.page3_toolbutton_history.clicked.connect(lambda: self.stackedWidget.setCurrentIndex(2))
        self.page4_toolbutton_maintain.clicked.connect(lambda: self.stackedWidget.setCurrentIndex(3))
        self.page_toolbutton_close.clicked.connect(lambda: self.close())  # 调用 close → 触发 closeEvent 清理

        # 槽函数 P21-P22页面切换
        # 相机对焦/流量测试页面已移动到维护页作为子页(index 3/4)
        self.page22_toolbutton_camerafocus.clicked.connect((lambda: self.page4_stackedwidget_maintain.setCurrentIndex(3)))
        self.page22_toolbutton_camerafocus_2.clicked.connect(lambda: self.page4_stackedwidget_maintain.setCurrentIndex(4))
        self.page2_stackedwidget_test.currentChanged.connect(
            lambda i: self.on_test_page_changed(i, "test"))
        self.page4_stackedwidget_maintain.currentChanged.connect(
            lambda i: self.on_test_page_changed(i, "maintain"))

        self.page21_toolButton_capture_2.clicked.connect(self.microPumpSample)  # 微泵采集
        self.page21_toolButton_capture_3.clicked.connect(self.initializeSample)  # 初次进样
        self.page21_toolButton_capture_4.clicked.connect(self.sampleWash)  # 奶路清洗
        self.page21_toolButton_capture_5.clicked.connect(self.colorWash)  # 染料清洗
        self.page21_toolButton_capture_8.clicked.connect(self.Ratioinjection)  # 比例进样
        self.page21_toolButton_capture_7.clicked.connect(self.SampleEmptiness)  # 样池排空
        self.page21_toolButton_capture_9.clicked.connect(self.chipWash)  # 流道清洗
        self.page21_toolButton_capture_10.clicked.connect(self.samplingMixing)  # 抽样混样
        self.page21_toolButton_capture_11.clicked.connect(self.capture)  # 图像截图
        self.page21_toolButton_capture_6.clicked.connect(self.standardTest)  # 标测（标样测试流程）
        self.page21_toolButton_status_toggle.toggled.connect(self.on_status_toggle)  # 工作/清洗状态切换

        # 槽函数 P41-P43维护页面切换
        self.page41_toolbutton_camerabasics.clicked.connect(
            lambda: self.page4_stackedwidget_maintain.setCurrentIndex(0))
        self.page42_toolButton_threshold.clicked.connect(lambda: self.page4_stackedwidget_maintain.setCurrentIndex(1))
        self.page43_toolButton_maintenance.clicked.connect(lambda: self.page4_stackedwidget_maintain.setCurrentIndex(2))

        # 槽函数 p21按钮采集功能
        self.page21_toolButton_capture.clicked.connect(self.Count_Test)
        self.page21_slider_light_set.valueChanged.connect(self.Light_PWM_Set)

        # 槽函数 P22自动对焦功能
        self.page22_toolbutton_autofocus.clicked.connect(self.focus_trigger)
        self.page22_toolbutton_add_plus.clicked.connect(self.focus_trigger)
        self.page22_toolbutton_add.clicked.connect(self.focus_trigger)
        self.page22_toolButton_subtract.clicked.connect(self.focus_trigger)
        self.page22_toolButton_subtract_plus.clicked.connect(self.focus_trigger)
        # 对焦/微调完成后恢复按钮（跨线程信号自动 QueuedConnection 到主线程）
        self.autoFocus_thread.signal_focusFinished.connect(self._on_focus_finished)

        # P3图表显示 初始化
        self.chart = QChart()
        self.series = QLineSeries()  # 折线图
        self.scatter_series = QScatterSeries()  # 散点图

        self.Chart_Init()
        self.Refresh_data()

        # 槽函数 P41控件功能
        self.page41_toolbutton_read.clicked.connect(self.Open_Param_File)  # 读取参数
        self.page41_toolbutton_save.clicked.connect(self.Save_Param_File)  # 保存参数

        self.page41_toolbutton_flip_horizontal.clicked.connect(
            partial(self.Image_Flip, self.page41_toolbutton_flip_horizontal))
        self.page41_toolbutton_flip_vertical.clicked.connect(
            partial(self.Image_Flip, self.page41_toolbutton_flip_vertical))

        self.page41_slider_brightness.valueChanged.connect(partial(self.Slider_Change, self.page41_slider_brightness))
        self.page41_slider_hue.valueChanged.connect(partial(self.Slider_Change, self.page41_slider_hue))
        self.page41_slider_saturation.valueChanged.connect(partial(self.Slider_Change, self.page41_slider_saturation))
        self.page41_slider_contrast.valueChanged.connect(partial(self.Slider_Change, self.page41_slider_contrast))
        self.page41_slider_gamma.valueChanged.connect(partial(self.Slider_Change, self.page41_slider_gamma))
        self.page41_slider_gain.valueChanged.connect(partial(self.Slider_Change, self.page41_slider_gain))
        self.page41_slider_exposure.valueChanged.connect(partial(self.Slider_Change, self.page41_slider_exposure))
        self.Slider_Init()



        # 槽函数 P42控件功能
        self.page42_toolButton_gather.clicked.connect(self.Get_Temp_Img)  # 图像采集处理按钮
        self.page42_toolButton_save.clicked.connect(self.Save_Threshold_param)  # 图像采集处理按钮
        self.page42_slider_8.valueChanged.connect(partial(self.Slider_Change, self.page42_slider_8))  # 计数阈值滑块
        self.need_deal_img = []  # "图像采集处理"按钮会将一帧图像保存在该变量中，改变滑条阈值后都对这个图像进行处理

        # 槽函数 串口相关
        '''下拉框中的串口号不一定是连接上的，需要提前确认，然后选择对应串口号后再连接，确保主页的提示灯全绿才可进行下一步测试'''
        self.page43_comboBox_serial.activated[str].connect(self.COM_Connect)
        self.HEAD = 0xFF
        self.TAIL = 0xFE

        # 每三秒刷新一次串口列表
        self.time_refresh_ports = QTimer(self)
        self.time_refresh_ports.timeout.connect(self.Refresh_ports)
        self.time_refresh_ports.start(3000)

    @pyqtSlot(int, float)
    def _enqueue_upload_numbers(self, img_num, cell_count):
        """收到计数线程信号后，把数字上传任务投递到 UploadThread 队列"""
        self.upload_thread.add_task({
            "type": "numbers",
            "img_num": img_num,
            "cell_count": cell_count,
        })

    @pyqtSlot(str, int, float)
    def _enqueue_upload_images(self, folder, img_num, cell_count):
        """收到计数线程信号后，把图片上传任务投递到 UploadThread 队列"""
        self.upload_thread.add_task({
            "type": "images",
            "folder": folder,
            "img_num": img_num,
            "cell_count": cell_count,
        })

    def _append_log_item(self, listwidget, msg, level, color_override=None):
        """把一条日志追加到指定面板；带颜色与"粘底"自动滚动（不打断用户回看）。"""
        color = {
            logging.ERROR: QColor('#ff6b6b'),
            logging.WARNING: QColor('#f0c040'),
            logging.INFO: QColor('#d0d0d0'),
            logging.DEBUG: QColor('#8a8a8a'),
        }.get(level, QColor('#d0d0d0'))
        if color_override is not None:
            color = color_override
        item = QtWidgets.QListWidgetItem(msg)
        item.setForeground(color)

        # 先判断用户当前是否已在底部（追加前判断，避免 maximum() 变化影响结果）
        scrollbar = listwidget.verticalScrollBar()
        at_bottom = scrollbar.value() >= scrollbar.maximum() - 4

        listwidget.addItem(item)
        # 只保留最近 200 条，避免长时间运行占用内存
        while listwidget.count() > 200:
            listwidget.takeItem(0)

        # 仅当原本就在底部时才自动跟随；用户向上回看时不打扰
        if at_bottom:
            listwidget.scrollToBottom()

    @pyqtSlot(str, int)
    def _on_log_msg(self, msg, level):
        """计数测试页日志面板：显示 warning/error 等关键日志。"""
        self._append_log_item(self.listWidget, msg, level)

    @pyqtSlot(str)
    def _on_step(self, step):
        """检测流程步骤进度：用醒目颜色追加到计数测试页信息小窗。"""
        self._append_log_item(self.listWidget, "▶ " + step, logging.INFO, QColor('#5ad1ff'))

    @pyqtSlot(str, int)
    def _on_flowtest_log_msg(self, msg, level):
        """流量测试页日志面板：显示 warning/error 等关键日志。"""
        self._append_log_item(self.flowtest_listwidget_log, msg, level)

    def open_test_page_with_password(self):
        """进入调试页前验证密码；每次离开后再次进入都需要重新验证。"""
        password, ok = QInputDialog.getText(
            self, "调试页面验证", "请输入调试页面密码：", QLineEdit.Password)
        if not ok:
            return
        if password == "123456":
            self.stackedWidget.setCurrentIndex(1)
            return
        QMessageBox.warning(self, "密码错误", "密码不正确，无法进入调试页面。")

    # 首页4个LED灯的状态开关
    @pyqtSlot(str)
    def homePage_setLED(self, text):
        # 串口LED开
        if text == 'serial on':
            self.page1_label_com_led.setStyleSheet(
                "#page1_label_com_led{border-radius:8px;background-color: rgb(85, 255, 127);}")
        # 串口LED关
        elif text == 'serial off':
            self.page1_label_com_led.setStyleSheet(
                "#page1_label_com_led{border-radius:8px;background-color: rgb(255, 85, 85);}")
        # # 电机LED开
        # elif text == 'serial on':
        #     self.page1_label_com_led.setStyleSheet(
        #         "#page1_label_com_led{border-radius:8px;background-color: rgb(85, 255, 127);}")
        # # 电机LED关
        # elif text == 'serial on':
        #     self.page1_label_com_led.setStyleSheet(
        #         "#page1_label_com_led{border-radius:8px;background-color: rgb(85, 255, 127);}")
        # # 相机LED开
        # elif text == 'serial on':
        #     self.page1_label_com_led.setStyleSheet(
        #         "#page1_label_com_led{border-radius:8px;background-color: rgb(85, 255, 127);}")
        # # 相机LED关
        # elif text == 'serial on':
        #     self.page1_label_com_led.setStyleSheet(
        #         "#page1_label_com_led{border-radius:8px;background-color: rgb(85, 255, 127);}")
        # # 对焦LED开
        # elif text == 'serial on':
        #     self.page1_label_com_led.setStyleSheet(
        #         "#page1_label_com_led{border-radius:8px;background-color: rgb(85, 255, 127);}")
        # # 对焦LED关
        # elif text == 'serial on':
        #     self.page1_label_com_led.setStyleSheet(
        #         "#page1_label_com_led{border-radius:8px;background-color: rgb(85, 255, 127);}")

    def Open_Param_File(self):
        try:
            options = QtWidgets.QFileDialog.Options()
            file_path, _ = QtWidgets.QFileDialog.getOpenFileName(None, "选择文件", "",
                                                                 "所有文件 (*);;文本文件 (*.txt)", options=options)
            if file_path:
                file_Type = file_path.split('/')[-1].split('.')[-1]
                # if file_Type == 'xlsx':
            else:
                pass
                # print(f"选中的文件路径: {file_path}")
                # print(file_Type)

        except Exception as ex:
            logging.error("traceback.format_exc():\n%s" % traceback.format_exc())

    def Load_Threshold_param(self):
        with open(self.camera_parameters_file, 'r', encoding='utf-8') as f:
            camera_params = json.load(f)
        self.page42_slider_8.setValue(camera_params['threshold'])

    def Save_Threshold_param(self):
        with open(self.camera_parameters_file, 'r', encoding='utf-8') as f:
            camera_params = json.load(f)
        camera_params['threshold'] = self.page42_slider_8.value()
        with open(self.camera_parameters_file, 'w', encoding='utf-8') as f:
            json.dump(camera_params, f, indent=2)

        msg = QMessageBox()
        # msg.setWindowFlags(QtCore.Qt.windowStaysOnTopHint)
        msg.setText('阈值参数已保存!')
        msg.setWindowTitle('保存成功')
        msg.setStandardButtons(QMessageBox.Ok)
        msg.exec_()  # 显示弹窗并等待用户关闭

    def Save_Param_File(self):
        camera_param = {}
        camera_param.update({'brightness': self.page41_slider_brightness.value()})
        camera_param.update({'hue': self.page41_slider_hue.value()})
        camera_param.update({'saturation': self.page41_slider_saturation.value()})
        camera_param.update({'contrast': self.page41_slider_contrast.value()})
        camera_param.update({'gamma': self.page41_slider_gamma.value()})
        camera_param.update({'gain': self.page41_slider_gain.value()})
        camera_param.update({'exposure': self.page41_slider_exposure.value()})
        # 如果已有阈值参数，一并保留
        if os.path.exists(self.camera_parameters_file):
            with open(self.camera_parameters_file, 'r', encoding='utf-8') as f:
                old_params = json.load(f)
            if 'threshold' in old_params:
                camera_param['threshold'] = old_params['threshold']
        with open(self.camera_parameters_file, 'w', encoding='utf-8') as f:
            json.dump(camera_param, f, indent=2)

        msg = QMessageBox()
        # msg.setWindowFlags(QtCore.Qt.windowStaysOnTopHint)
        msg.setText('相机参数已保存!')
        msg.setWindowTitle('保存成功')
        msg.setStandardButtons(QMessageBox.Ok)
        msg.exec_()  # 显示弹窗并等待用户关闭

    def Refresh_ports(self):
        # 保存当前选中的端口名
        selected_port = self.page43_comboBox_serial.currentText()

        # 清空下拉框并重新加载选项
        self.page43_comboBox_serial.clear()
        
        valid_devices = []
        
        # 方法1：通过 pyserial 枚举串口
        try:
            ports = serial.tools.list_ports.comports()
            for port in ports:
                dev = port.device
                dev_lower = dev.lower()
                if any(keyword in dev_lower for keyword in [
                    '/dev/ttyusb',      # USB转串口
                    '/dev/ttyacm',      # USB ACM设备
                    '/dev/ttyama',      # 蓝牙串口
                    '/dev/ttyths',      # Rockchip SoC UART
                    '/dev/ttys',        # 标准串口（含RK3588自带485）
                    'com'               # Windows COM口
                ]):
                    valid_devices.append(dev)
        except Exception as e:
            logging.error(f"serial err: {e}")
        
        # 方法2：补充扫描 /dev/ 目录（处理pyserial可能无法列出ttyS的情况）
        try:
            import platform
            if platform.system() == 'Linux':
                import glob
                # 扫描所有 ttyS* 和 ttyTHS* 设备
                extra_devices = glob.glob('/dev/ttyS*') + glob.glob('/dev/ttyTHS*')
                for dev in extra_devices:
                    if dev not in valid_devices:
                        valid_devices.append(dev)
        except Exception as e:
            logging.error(f"补充扫描串口出错: {e}")
        
        # 去重并添加到下拉框
        seen = set()
        for dev in valid_devices:
            if dev not in seen:
                seen.add(dev)
                self.page43_comboBox_serial.addItem(dev)
        
        # 恢复之前选中的端口
        if selected_port:
            index = self.page43_comboBox_serial.findText(selected_port)
            if index >= 0:
                self.page43_comboBox_serial.setCurrentIndex(index)

    def COM_Connect(self, text):
        logging.debug('COM_Connect')
        self.serial_thread.signal_serialConnect.emit(text)  # 发送信号，连接指定端口

    def on_status_toggle(self, checked):
        """工作状态/清洗状态二值按钮：checked=True -> 清洗(1)，False -> 工作(0)。
        仅在状态真的变化时才触发本地切换 + 上报 + 广播（走 UploadThread 后台，不阻塞UI）。
        检测流程进行中禁止切到清洗——等待检测结束才能切换。"""
        new_status = onenet_uploader.STATUS_CLEAN if checked else onenet_uploader.STATUS_WORK
        if new_status == self._work_status:
            return  # 状态未变，忽略（防程序化 setChecked 引起的重复触发）
        # 拦截：细胞检测进行中不允许切到清洗
        if new_status == onenet_uploader.STATUS_CLEAN:
            detecting = (getattr(self, 'countCell_thread', None) and
                         getattr(self.countCell_thread, 'is_running', False))
            if detecting:
                logging.warning("切换清洗被拦截：细胞检测进行中")
                QMessageBox.warning(self, "无法切换",
                                    "细胞检测正在进行中，请等待检测结束后再切换到清洗状态。")
                self._refresh_status_ui()  # 回滚按钮到当前（工作）状态，blockSignals 防递归
                return
        # 本地立即切换 UI 与状态
        self._work_status = new_status
        self._refresh_status_ui()
        # 后台执行：上报本机状态 + 广播给其它设备
        self.upload_thread.add_task({"type": "status", "value": new_status})
        logging.info(f"本机状态切换为：{'清洗' if new_status == onenet_uploader.STATUS_CLEAN else '工作'}")
        # 触发/中止清洗硬件流程
        if new_status == onenet_uploader.STATUS_CLEAN:
            self.cleaning_thread.request_start()
        else:
            self.cleaning_thread.request_abort()

    def closeEvent(self, event):
        """退出清理：先立即关闭界面（视觉上秒退），再由后台线程完成资源清理。
        不重置云端状态（保留退出前状态，重启后由"重启对齐"纠正）。
        检测进行中或正处于清洗状态时，禁止退出并弹窗警告。"""
        # 0. 检测进行中 或 清洗进行中 → 禁止退出，弹窗警告
        condition = []
        if getattr(self, 'countCell_thread', None) and getattr(self.countCell_thread, 'is_running', False):
            condition.append("细胞检测")
        if getattr(self, 'cleaning_thread', None) and getattr(self.cleaning_thread, '_active', False):
            condition.append("清洗")
        if condition:
            msg = QMessageBox(self)
            msg.setIcon(QMessageBox.Warning)
            msg.setWindowTitle("无法退出")
            msg.setText("当前正在进行" + "、".join(condition) + "，请先完成或中途停止后再退出。")
            msg.setStandardButtons(QMessageBox.Ok)
            msg.exec_()
            event.ignore()  # 阻止关闭
            return

        # ★ 立即关闭界面（视觉优先），清理放到后台线程执行
        event.accept()

        # 重启对齐线程随退出提前中断：置停止标志
        self._shutting_down = True

        def _cleanup():
            """后台清理线程：停止各线程、断开云平台、释放相机/串口，最后结束事件循环"""
            # 兜底：无论下面哪一步阻塞，5 秒后强制结束进程
            def _force_exit():
                time.sleep(5)
                logging.warning("退出清理超时，强制结束进程")
                os._exit(0)
            threading.Thread(target=_force_exit, daemon=True).start()

            logging.info("开始退出清理...")
            # 停止清洗线程（若在运行则中止并完成排空）——非阻塞
            try:
                if hasattr(self, 'cleaning_thread'):
                    self.cleaning_thread.stop()
            except Exception as e:
                logging.warning(f"清洗线程停止异常: {e}")
            # 停止各后台线程（自动对焦/计数/流量/上传）——非阻塞
            for name, thr in (('自动对焦', 'autoFocus_thread'), ('计数', 'countCell_thread'),
                              ('流量', 'flow_thread'), ('上传', 'upload_thread')):
                try:
                    t = getattr(self, thr, None)
                    if t is not None:
                        t.stop()
                except Exception as e:
                    logging.warning(f"{name}线程停止异常: {e}")
            # 断开云平台 MQTT 连接（主动离线）
            try:
                if hasattr(self, 'uploader'):
                    self.uploader.disconnect()
            except Exception as e:
                logging.warning(f"云平台断开异常: {e}")
            # 停止相机线程（释放摄像头）——非阻塞
            try:
                if hasattr(self, 'camera_thread'):
                    self.camera_thread.stop()
            except Exception as e:
                logging.warning(f"相机线程停止异常: {e}")
            # 停止串口线程（释放串口资源）——非阻塞
            try:
                if hasattr(self, 'serial_thread'):
                    self.serial_thread.stop()
            except Exception as e:
                logging.warning(f"串口线程停止异常: {e}")
            logging.info("退出清理完成")

            # 清理结束：正常结束事件循环（界面已关闭，不再显示）
            from PyQt5.QtWidgets import QApplication
            QApplication.instance().quit()

        threading.Thread(target=_cleanup, daemon=True).start()

    def _on_cloud_status(self, key, value):
        """云端下发回调（MQTT 线程）：只关心 status，通过信号切回主线程"""
        if key != "status":
            return
        try:
            self.status_changed.emit(int(value))
        except (TypeError, ValueError):
            logging.warning(f"云端 status 解析失败: {value}")

    def _apply_status(self, status):
        """主线程收云端 status：若与本地不同则应用（本地切换流程无需处理，因发起者已排除自身）"""
        if status == self._work_status:
            return
        self._work_status = status
        self._refresh_status_ui()
        # 广播接收方：下发指令只是“指示”，自身云端 status 记录不会自动改变，须主动上报一次（只上报、不广播，避免循环）
        threading.Thread(target=self.uploader.publish_status, args=(status,), daemon=True).start()
        logging.info(f"收到云端状态广播，切换为：{'清洗' if status == onenet_uploader.STATUS_CLEAN else '工作'}")
        # 触发/中止清洗硬件流程
        if status == onenet_uploader.STATUS_CLEAN:
            self.cleaning_thread.request_start()
        else:
            self.cleaning_thread.request_abort()

    def _sync_status_at_startup(self):
        """后台线程：等 MQTT 连接就绪，统计在线设备多数态，通过信号切回主线程应用"""
        deadline = time.time() + 8
        while not self.uploader._connected and time.time() < deadline:
            if getattr(self, '_shutting_down', False):  # 退出时提前中断
                logging.warning("重启对齐: 退出请求，提前中断等待")
                return
            time.sleep(0.2)
        if not self.uploader._connected:
            logging.warning("重启对齐: MQTT 未连接，跳过对齐，保持默认工作状态")
            return
        try:
            synced = self.uploader.sync_status_from_online_devices(
                stop_check=lambda: getattr(self, '_shutting_down', False))
        except Exception as e:
            logging.error(f"重启对齐异常: {e}")
            return
        self.status_synced.emit(int(synced))

    def _apply_synced_status(self, status):
        """主线程应用重启对齐结果：更新本地状态与 UI，并上报本机云端保持一致（只上报、不广播）"""
        logging.info(f"重启对齐应用: 新状态={'清洗' if status == onenet_uploader.STATUS_CLEAN else '工作'}")
        self._work_status = status
        self._refresh_status_ui()

        # 触发/中止清洗硬件流程
        if status == onenet_uploader.STATUS_CLEAN:
            self.cleaning_thread.request_start()
        else:
            self.cleaning_thread.request_abort()

        # 云端必须同步：MQTT 上报 + HTTP 直写双保险（实测 MQTT 偶发不刷新"最新属性"）
        def _sync_cloud(s):
            self.uploader.publish_status(s)
            self.uploader.set_status_via_http(s)
        threading.Thread(target=_sync_cloud, args=(status,), daemon=True).start()

    def _refresh_status_ui(self):
        """按 _work_status 刷新状态按钮的文字与样式（工作=绿/清洗=红）"""
        btn = self.page21_toolButton_status_toggle
        # 同步按钮勾选态（避免云端下发后 checked 与 _work_status 不一致）；blockSignals 防 on_status_toggle 递归
        btn.blockSignals(True)
        btn.setChecked(self._work_status == onenet_uploader.STATUS_CLEAN)
        btn.blockSignals(False)
        if self._work_status == onenet_uploader.STATUS_CLEAN:
            btn.setText("●  清洗状态")
            btn.setStyleSheet(
                "QToolButton{background-color:#b03a2e;color:#ffffff;border-radius:6px;"
                "font-size:14px;font-weight:bold;}")
        else:
            btn.setText("●  工作状态")
            btn.setStyleSheet(
                "QToolButton{background-color:#1e8449;color:#ffffff;border-radius:6px;"
                "font-size:14px;font-weight:bold;}")

    def display_frame_on_label(self, label):
        try :
            if self.frame is None:
                logging.warning('采集图像为None，无法显示！')
                return
            if self.flip_h:
                self.frame = cv2.flip(self.frame, 1)
            if self.flip_v:
                self.frame = cv2.flip(self.frame, 0)

            # 转换图像为 RGB 格式
            rgb_image = cv2.cvtColor(self.frame, cv2.COLOR_BGR2RGB)
            h, w, ch = rgb_image.shape
            bytes_per_line = ch * w
            q_image = QImage(rgb_image.data, w, h, bytes_per_line, QImage.Format_RGB888)

            # 将 QImage 转为 QPixmap，并调整大小以适应 QLabel
            pixmap = QPixmap.fromImage(q_image)
            pixmap = pixmap.scaled(label.size(), Qt.KeepAspectRatio, Qt.SmoothTransformation)

            # 设置 QLabel 显示图像
            label.setAlignment(Qt.AlignCenter)
            label.setPixmap(pixmap)

            # 销毁引用，避免内存泄露
            del self.frame
            del rgb_image
        except Exception as e:
            logging.error(f"显示图像出错: {e}")

    def Camera_Open_Check(self):
        # 首先确认是否在2/4page，如果是，则具体确定是21/22/41/42后在具体是画面在哪个地方显示
        index1 = self.stackedWidget.currentIndex() + 1
        if index1 == 2:
            index2 = self.page2_stackedwidget_test.currentIndex() + 1
        elif index1 == 4:
            index2 = self.page4_stackedwidget_maintain.currentIndex() + 1
        else:
            index2 = 0

        index = f'{index1}{index2}'

        if index == '21':
            self.display_frame_on_label(self.page21_label_img_show)
        elif index == '22':
            self.display_frame_on_label(self.page22_label_img_show)
        elif index == '41':
            self.display_frame_on_label(self.page41_label_img_show)
        elif index == '42':
            self.display_frame_on_label(self.page42_label_original_img)
        elif index == '44':
            # 对焦界面：page_10 挂在 page4_stackedwidget_maintain 的第4个子页（'44'），
            # 其主画面 label 为 page22_label_img_show（'22' 仅继承历史命名）。
            self.display_frame_on_label(self.page22_label_img_show)


    # 接收相机线程周期性传递的图像画面，frame在这里随着函数结束会自动销毁引用
    def update_frame(self, frame):
        self.frame = frame
        self.Camera_Open_Check()

    def focus_trigger(self):
        # 01 自动对焦
        # 02 + 00/01（方向）+ FF FF（距离）微调

        # 确定点击的按钮名称
        sender = self.sender()

        # 自动对焦对象
        if sender is not None:
            button_text = sender.objectName()
            if button_text == 'page22_toolbutton_autofocus':  # 自动对焦
                # 禁用所有对焦按钮，防止重入导致任务堆积
                self._set_focus_buttons_enabled(False)
                self.autoFocus_thread.signal_startAutoFocus.emit([5, 250])
                # print('自动对焦')
            elif button_text == 'page22_toolbutton_add_plus':  # 大步进+
                self._set_focus_buttons_enabled(False)
                self.autoFocus_thread.signal_startFineTuning.emit([1, 2500])
                # print('++')
            elif button_text == 'page22_toolbutton_add':  # 小步进+
                self._set_focus_buttons_enabled(False)
                self.autoFocus_thread.signal_startFineTuning.emit([1, 250])
                # print('+')
            elif button_text == 'page22_toolButton_subtract_plus':  # 大步进-
                self._set_focus_buttons_enabled(False)
                self.autoFocus_thread.signal_startFineTuning.emit([0, 2500])
                # print('--')
            elif button_text == 'page22_toolButton_subtract':  # 小步进-
                self._set_focus_buttons_enabled(False)
                self.autoFocus_thread.signal_startFineTuning.emit([0, 250])
                # print('-')
            else:
                return

    def _set_focus_buttons_enabled(self, enabled):
        """统一启用/禁用 5 个对焦按钮"""
        self.page22_toolbutton_autofocus.setEnabled(enabled)
        self.page22_toolbutton_add_plus.setEnabled(enabled)
        self.page22_toolbutton_add.setEnabled(enabled)
        self.page22_toolButton_subtract.setEnabled(enabled)
        self.page22_toolButton_subtract_plus.setEnabled(enabled)

    def _on_focus_finished(self, success):
        """对焦/微调完成后恢复按钮"""
        self._set_focus_buttons_enabled(True)

    def Slider_Init(self):
        with open(self.camera_parameters_file, 'r', encoding='utf-8') as f:
            df = json.load(f)
        self.brightness = df['brightness']
        self.hue = df['hue']
        self.saturation = df['saturation']
        self.contrast = df['contrast']
        self.gamma = df['gamma']
        self.gain = df['gain']
        self.exposure = df['exposure']

        self.page41_slider_brightness.setMinimum(1)
        self.page41_slider_brightness.setMaximum(1000)
        self.page41_slider_brightness.setValue(df['brightness'])
        self.page41_label_brightness_num.setText(str(df['brightness']))

        # self.page41_slider_hue.setMinimum(-180)
        # self.page41_slider_hue.setMaximum(180)
        # self.page41_slider_hue.setValue(df['hue'])
        # self.page41_label_hue_num.setText(str(df['hue']))

        self.page41_slider_saturation.setMinimum(0)
        self.page41_slider_saturation.setMaximum(255)
        self.page41_slider_saturation.setValue(df['saturation'])
        self.page41_label_saturation_num.setText(str(df['saturation']))

        # self.page41_slider_contrast.setMinimum(0)
        # self.page41_slider_contrast.setMaximum(100)
        # self.page41_slider_contrast.setValue(df['contrast'])
        # self.page41_label_contrast_num.setText(str(df['contrast']))

        # self.page41_slider_gamma.setMinimum(100)
        # self.page41_slider_gamma.setMaximum(500)
        # self.page41_slider_gamma.setValue(df['gamma'])
        # self.page41_label_gamma_num.setText(str(df['gamma']))

        self.page41_slider_gain.setMinimum(0)
        self.page41_slider_gain.setMaximum(500)
        self.page41_slider_gain.setValue(df['gain'])
        self.page41_label_gain_num.setText(str(df['gain']))

        # self.page41_slider_exposure.setMinimum(0)
        # self.page41_slider_exposure.setMaximum(500)
        # self.page41_slider_exposure.setValue(df['exposure'])
        # self.page41_label_exposure_num.setText(str(df['exposure']))

        # self.page42_slider_8.setMinimum(0)
        # self.page42_slider_8.setMaximum(255)
        # self.page42_slider_8.setValue(df['threshold'])
        # self.page42_label_thresholddata.setText(str(df['threshold']))
        parameter = []
        parameter.append(self.page41_slider_brightness.value())  # 曝光时间（占用了亮度）
        parameter.append(self.page41_slider_saturation.value())  # 饱和度
        parameter.append(self.page41_slider_gain.value())  # 增益
        self.camera_thread.signal_set_parameter.emit(parameter)

    def Slider_Change(self, slider):
        parameter = []
        parameter.append(self.page41_slider_brightness.value())  # 曝光时间（占用了亮度）
        parameter.append(self.page41_slider_saturation.value())  # 饱和度
        parameter.append(self.page41_slider_gain.value())  # 增益
        self.camera_thread.signal_set_parameter.emit(parameter)

        self.page41_label_brightness_num.setText(f'{self.page41_slider_brightness.value()}')
        self.page41_label_hue_num.setText(f'{self.page41_slider_hue.value()}')
        self.page41_label_saturation_num.setText(f'{self.page41_slider_saturation.value()}')
        self.page41_label_contrast_num.setText(f'{self.page41_slider_contrast.value()}')
        self.page41_label_gamma_num.setText(f'{self.page41_slider_gamma.value()}')
        self.page41_label_gain_num.setText(f'{self.page41_slider_gain.value()}')
        self.page41_label_exposure_num.setText(f'{self.page41_slider_exposure.value()}')
        logging.debug(f"相机参数: {parameter}")
        # slider_name = slider.objectName()
        # num = slider.value()
        #
        # # 目前只有亮度和色调这两个参数能调节，其他的参数当前相机不支持
        # if slider_name == 'page41_slider_brightness':
        #     self.page41_label_brightness_num.setText(f'{num}')
        # elif slider_name == 'page41_slider_hue':
        #     self.page41_label_hue_num.setText(f'{num}')
        #     self.cap.set(cv2.CAP_PROP_HUE, num)
        # elif slider_name == 'page41_slider_saturation':
        #     self.page41_label_saturation_num.setText(f'{num}')
        #     # self.cap.set(cv2.CAP_PROP_SATURATION, num)
        # elif slider_name == 'page41_slider_contrast':
        #     self.page41_label_contrast_num.setText(f'{num}')
        #     # self.cap.set(cv2.CAP_PROP_CONTRAST, num)
        # elif slider_name == 'page41_slider_gamma':
        #     self.page41_label_gamma_num.setText(f'{num}')
        #     # self.cap.set(cv2.CAP_PROP_GAMMA, num)
        # elif slider_name == 'page41_slider_gain':
        #     self.page41_label_gain_num.setText(f'{num}')
        #     # self.cap.set(cv2.CAP_PROP_GAIN, num)
        # elif slider_name == 'page41_slider_exposure':
        #     self.page41_label_exposure_num.setText(f'{num}')
        #     self.camera_thread.capture.set(cv2.CAP_PROP_EXPOSURE, num)
        # elif slider_name == 'page42_slider_8':
        #     self.page42_label_thresholddata.setText(f'{num}')
        #     self.Count_Cell_Num(num)
        # else:
        #     print('Unknown slider name!')

    def Image_Flip(self, toolbutton):
        button_name = toolbutton.objectName()
        if button_name == 'page41_toolbutton_flip_horizontal':
            self.flip_h = ~self.flip_h
        elif button_name == 'page41_toolbutton_flip_vertical':
            self.flip_v = ~self.flip_v

    @pyqtSlot(int)
    def Light_PWM_Set(self):
        num = self.page21_slider_light_set.value()
        self.page21_label_light_num.setText('{}%'.format(num))
        ratio = num * 5
        data = [0xFF, 0x07, (ratio >> 8) & 0xFF, ratio & 0xFF, 0xFE]
        self.serial_thread.signal_sendData.emit(data)

    def _sync_home_cell_display(self):
        """让首页的平均体细胞数跟测试页保持一致。"""
        self.page1_label_average_3.setText(self.page21_label_average.text())
        self.page1_label_cell_num_3.setText(self.page21_label_cell_num.text())
        self.page1_label_ml_3.setText(self.page21_label_ml.text())

    @pyqtSlot()
    def Count_Test(self):
        try:
            self.page21_label_img_num.setText('0')
            self.page21_label_cell_num.setText('0.0')
            self._sync_home_cell_display()
            self.page21_toolButton_capture.setEnabled(False)  # 禁用按钮
            self.countCell_thread.signal_countCell.emit()  # 发送计数信号
        except Exception as e:
            logging.error(f"Count_Test 触发异常: {e}")

    def Open_Key(self):
        self.page21_toolButton_capture.setEnabled(True)  # 使能按钮
        self.page21_toolButton_capture_6.setEnabled(True)  # 使能标测按钮

    def Chart_Init(self):
        # 折线参数设置
        self.series.setColor(Qt.gray)
        pen = QPen(Qt.lightGray)
        pen.setWidth(3)  # 设置线宽
        self.series.setPen(pen)

        # 散点参数设置
        self.scatter_series.setMarkerShape(QScatterSeries.MarkerShapeCircle)
        self.scatter_series.setColor(Qt.white)  # 设置空心圆的填充颜色
        # self.scatter_series.setBorderColor(Qt.black)  # 设置圆形的边框颜色
        self.scatter_series.setMarkerSize(8)  # 设置圆形的大小

        # 设置散点颜色为蓝色，宽度为3
        pen = QPen(Qt.red)  # 红色边框
        pen.setWidth(2)  # 边框宽度
        self.scatter_series.setPen(pen)

        # 选中散点参数设置
        self.scatter_point = QScatterSeries()  # 绘制选中点
        self.scatter_point.setMarkerShape(QScatterSeries.MarkerShapeCircle)  # 设置标记形状为圆
        self.scatter_point.setMarkerSize(6)  # 设置标记尺寸
        self.scatter_point.setColor(Qt.red)  # 设置空心圆的填充颜色

        # self.chart().series()[2] ----索引：1-折线  2-散点  3-选择点
        self.chart.addSeries(self.series)
        self.chart.addSeries(self.scatter_series)
        self.chart.addSeries(self.scatter_point)

        # 设置图表边框间距为0
        self.chart.setMargins(QMargins(0, 5, 0, 0))

        # # 关闭图例
        self.chart.legend().setVisible(False)

        # 设置背景和边框
        # self.chart.setBackgroundBrush(QBrush(QColor(240, 240, 240)))  # 浅灰色背景
        # self.chart.setBackgroundBrush(QColor(255, 255, 255))  # 设置背景颜色为白色
        self.chart.setBackgroundRoundness(5)  # 设置背景圆角（如果需要）

        # 设置边框颜色
        # self.chart.setFrameBorder(QColor(100, 100, 100))  # 设置深灰色边框

        font = QFont("Times New Roman", 8, QFont.Bold)  # 设置字体为 Arial，大小为 12，粗体

        # # 设置坐标轴
        self.axisX = QValueAxis()
        self.axisX.setRange(0, 60)
        self.axisX.setLabelFormat("%.0f")
        self.axisX.setTickCount(13)
        self.axisX.setLabelsFont(font)  # 设置 X 轴标签的字体
        self.chart.setAxisX(self.axisX, self.series)
        self.chart.setAxisX(self.axisX, self.scatter_series)
        self.chart.setAxisX(self.axisX, self.scatter_point)

        self.axisY = QValueAxis()
        self.axisY.setRange(0, 60)
        self.axisY.setLabelFormat("%.2f")
        self.axisY.setTickCount(6)  # 用固定刻度数，便于随数据范围自适应
        self.axisY.setLabelsFont(font)  # 设置 Y 轴标签的字体
        self.axisY.setTitleText("W/mL")  # Y 轴单位：万/毫升
        self.chart.setAxisY(self.axisY, self.series)
        self.chart.setAxisY(self.axisY, self.scatter_series)
        self.chart.setAxisY(self.axisY, self.scatter_point)

        # x 轴滚动滑条：数据多时按固定窗口显示，向右滑动查看更多数据
        self.chart_window = 60  # 每页最多显示的数据点数
        self.chart_scrollbar = QtWidgets.QScrollBar(Qt.Horizontal)
        self.chart_scrollbar.setRange(0, 0)
        self.chart_scrollbar.setPageStep(self.chart_window)
        self.chart_scrollbar.valueChanged.connect(self._on_chart_scroll)
        self.chart_scrollbar.hide()  # 数据少时不显示滑条

        # # 创建一个 QChartView 来显示图表
        self.chartview = ChartView(self.chart, self.tableWidget)
        self.chartview.setRenderHint(QPainter.Antialiasing)  # 启用抗锯齿效果
        self.chartview.setCursor(Qt.PointingHandCursor)  # 设置鼠标为手势

        # # 设置布局并显示
        self.gridLayout_4.addWidget(self.chartview, 0, 0)
        self.gridLayout_4.addWidget(self.chart_scrollbar, 1, 0)

    def _on_chart_scroll(self, value):
        """x 轴滑条拖动时，更新图表显示的 x 轴窗口"""
        self.axisX.setRange(value, value + self.chart_window)

    def _migrate_old_files(self):
        """
        旧文件自动迁移：将 .xlsx 格式转为 .json/.csv
        仅在新文件不存在但旧文件存在时执行，迁移后重命名旧文件为 .bak
        """
        # 如果 openpyxl 未安装，跳过迁移（新环境不依赖 openpyxl）
        try:
            import openpyxl  # noqa: F401
        except ImportError:
            logging.warning("openpyxl 未安装，跳过旧文件迁移（新文件格式为 .json/.csv，无需 openpyxl）")
            return

        # 1. 迁移 camera_parameters.xlsx → camera_parameters.json
        old_xlsx = os.path.join(get_app_dir(), 'camera_parameters.xlsx')
        new_json = os.path.join(get_app_dir(), 'camera_parameters.json')
        if os.path.exists(old_xlsx) and not os.path.exists(new_json):
            try:
                df = pd.read_excel(old_xlsx, engine='openpyxl')
                params = df.iloc[0].to_dict()
                # 处理 NaN 值（pandas 读取空单元格会产生 NaN，JSON 不支持）
                params = {k: (None if isinstance(v, float) and pd.isna(v) else v) for k, v in params.items()}
                with open(new_json, 'w', encoding='utf-8') as f:
                    json.dump(params, f, indent=2, ensure_ascii=False)
                # 重命名旧文件为 .bak 备份
                os.rename(old_xlsx, old_xlsx + '.bak')
                logging.info(f"已迁移 {old_xlsx} → {new_json}（旧文件已重命名为 .bak）")
            except Exception as e:
                logging.warning(f"迁移 {old_xlsx} 失败: {e}")

        # 2. 迁移 scc_history.xlsx → scc_history.csv
        old_xlsx = os.path.join(get_app_dir(), 'scc_history.xlsx')
        new_csv = os.path.join(get_app_dir(), 'scc_history.csv')
        if os.path.exists(old_xlsx) and not os.path.exists(new_csv):
            try:
                df = pd.read_excel(old_xlsx, engine='openpyxl')
                df.to_csv(new_csv, index=False, encoding='utf-8-sig')
                os.rename(old_xlsx, old_xlsx + '.bak')
                logging.info(f"已迁移 {old_xlsx} → {new_csv}（旧文件已重命名为 .bak）")
            except Exception as e:
                logging.warning(f"迁移 {old_xlsx} 失败: {e}")

    def Refresh_data(self):
        # 清空原数据
        self.series.clear()
        self.scatter_series.clear()
        self.scatter_point.clear()

        # 读取文件数据
        try:
            data = pd.read_csv(self.scc_history_file, encoding='utf-8-sig')
        except FileNotFoundError:
            return

        # 根据文件内的数据设置表格行列数
        self.tableWidget.setRowCount(data.shape[0])
        self.tableWidget.setColumnCount(data.shape[1])

        # 填充 QTableWidget 数据
        for row in range(data.shape[0]):
            for col in range(data.shape[1]):
                if col != 0 and col != data.shape[1] - 1:
                    item = QTableWidgetItem(f"{float(data.iloc[row, col]):.2f}")  # 读取每个单元格数据并转换为字符串
                else:
                    item = QTableWidgetItem(f"{data.iloc[row, col]}")  # 读取每个单元格数据并转换为字符串
                item.setTextAlignment(Qt.AlignCenter)
                item.setFlags(item.flags() & ~Qt.ItemIsEditable)
                self.tableWidget.setItem(row, col, item)

        # 加入chart数据
        index = 1  # 初始索引
        for row in range(self.tableWidget.rowCount()):
            self.series.append(index, float(self.tableWidget.item(row, 6).text()))
            index += 1

        for i in range(self.series.count()):
            self.scatter_series.append(self.series.at(i).x(), self.series.at(i).y())

        # 根据数据大小自动调整 y 轴上下限（上下各留 10% 余量）
        count = self.series.count()
        if count > 0:
            ys = [self.series.at(i).y() for i in range(count)]
            ymin = min(ys)
            ymax = max(ys)
            if ymin == ymax:
                pad = abs(ymax) * 0.1 if ymax != 0 else 1.0
            else:
                pad = (ymax - ymin) * 0.1
            self.axisY.setRange(ymin - pad, ymax + pad)

        # 数据多时按固定窗口显示，x 轴滑条向右滑动查看更多数据
        self.chart_scrollbar.blockSignals(True)
        if count > self.chart_window:
            latest_start = count - self.chart_window + 1  # 最新窗口的起始 x（旧数据在左、新数据在右）
            self.chart_scrollbar.setRange(1, latest_start)
            self.chart_scrollbar.setValue(latest_start)  # 初始化时定位到最新数据
            self.chart_scrollbar.show()
            self.axisX.setRange(latest_start, latest_start + self.chart_window)
        else:
            self.chart_scrollbar.setRange(0, 0)
            self.chart_scrollbar.hide()
            self.axisX.setRange(0, 60)
        self.chart_scrollbar.blockSignals(False)

        # 数据重绘
        self.chart.update()
        self.chartview.repaint()

    # 测试阈值效果
    def Count_Cell_Num(self, num):
        # 临时文件
        # self.need_deal_img = cv2.resize(cv2.imread('0003.bmp'), None, fx=0.3, fy=0.3)

        n, thres_result = cell_count(self.need_deal_img, num)
        self.page42_label_resultdata.setText(str(n))

        logging.debug(f'n = {n}')
        if n == 0:
            thres_result = self.need_deal_img
        # 转换图像为 RGB 格式
        rgb_image = cv2.cvtColor(thres_result, cv2.COLOR_BGR2RGB)
        h, w, ch = rgb_image.shape
        bytes_per_line = ch * w
        q_image = QImage(rgb_image.data, w, h, bytes_per_line, QImage.Format_RGB888)

        # 将 QImage 转为 QPixmap，并调整大小以适应 QLabel
        pixmap = QPixmap.fromImage(q_image)
        pixmap = pixmap.scaled(self.page42_label_count_show.size(), Qt.KeepAspectRatio, Qt.SmoothTransformation)

        # 设置 QLabel 显示图像
        # self.page42_label_count_show.setAlignment(Qt.AlignCenter)
        self.page42_label_count_show.setPixmap(pixmap)

    def Get_Temp_Img(self):
        try:
            self.need_deal_img = self.camera_thread.get_frame()
            self.need_deal_img = cv2.resize(self.need_deal_img, None, fx=0.3, fy=0.3)
            self.Count_Cell_Num(self.page42_slider_8.value())
        except Exception as e:
            logging.error(f"获取临时图像出错: {e}")

    @pyqtSlot()
    def clear_scroll(self):  # 清空scroll，每轮测试计数前，需要清空scroll中的所有控件
        try:
            self.last_seen_files = set()
            self.page21_label_img_num.setText('0')
            self.page21_label_cell_num.setText('0.0')
            self._sync_home_cell_display()

            # 迭代删除scroll中的控件，同时释放掉对应的图片内存！！！
            while self.scroll_layout.count():
                item = self.scroll_layout.takeAt(0)
                widget = item.widget()

                if widget is not None:
                    widget.setParent(None)  # 移除控件的父级关系
                    # 强制删除按钮里的图片（QPixmap/QImage）
                    if hasattr(widget, 'pixmap'):
                        pix = widget.pixmap()
                        if not pix.isNull():
                            widget.setPixmap(None)  # 释放图片
                    if hasattr(widget, 'icon'):
                        widget.setIcon(QIcon())  # 释放图标

                    widget.deleteLater()  # 计划删除控件
                    widget = None
                else:
                    # 递归清除子布局
                    sub_layout = item.layout()
                    if sub_layout:
                        self.clear_layout(sub_layout)

            # 强制清理 Qt 内存 + Python 垃圾回收
            self.scroll_layout.update()
            self.container.update()
            gc.collect()
        except Exception as e:
            logging.error(f"清空滚动区域出错: {e}")

    @staticmethod
    def _scroll_sort_key(filename):
        """
        图片文件名排序key，确保原图和处理后图成对出现。
        文件名形如  月日-时分秒微秒 编号_0.bmp ，如 1008-101500123456-0001_0.bmp：
          1008-101500123456-0001_0.bmp (原图) → (1, 0)
          1008-101500123456-0001.bmp   (处理后) → (1, 1)
          1008-101500123456-0002_0.bmp (原图) → (2, 0)
          1008-101500123456-0002.bmp   (处理后) → (2, 1)
        注意：编号取自最后一次 '-' 之后、'_' 之前的数字段；
        不能用 int(整段)，因为 '1008' 是月日前缀、'_' 会被 Python 当千位分隔符。
        """
        name = filename.split('.')[0]  # 去掉扩展名
        if '_' in name:
            num, suffix = name.rsplit('_', 1)
        else:
            num, suffix = name, '1'  # 没有后缀的视为处理后图，排在原图后面
        # 取最后一次 '-' 之后的数字段作为排序编号（兼容带月日时分前缀的命名）
        num = num.rsplit('-', 1)[-1]
        return (int(num), int(suffix))

    @pyqtSlot(str, float)
    def refresh_scroll(self, image_path, aver_num):  # 刷新scroll
        # 读取文件夹中图片，并将图片文件名都转化成一个集合，方便快速进行查找和相关的集合运算
        files = set(os.listdir(image_path))

        # 计算新增加的图片文件
        new_files = files - self.last_seen_files
        new_files = sorted(list(new_files), key=self._scroll_sort_key)

        # 更新已查看的文件集
        self.last_seen_files = files
        logging.debug(f"新增图片:{new_files}")

        # 如果有新文件，读取并添加到布局
        for new_file in new_files:
            # 创建一个 QPushButton 并设置图标
            button = DoubleClickButton(image_path, new_file, self)

            # 调试：检查 icon 是否加载成功
            if button.icon().isNull():
                logging.warning(f'DoubleClickButton icon 加载失败: {new_file}')
            else:
                logging.debug(f'DoubleClickButton icon 加载成功: {new_file}')

            # 将新图片添加到布局中
            self.scroll_layout.addWidget(button)

            # 更新界面数据
            self.page21_label_img_num.setText(str(len(self.last_seen_files)))
            self.page21_label_cell_num.setText('{:.2f}'.format(aver_num))
            self._sync_home_cell_display()

        # 关键修复：先添加按钮，再根据实际按钮数量计算并设置尺寸
        # （原来在 addWidget 之前算 num，时机不对导致尺寸算错）
        num = self.scroll_layout.count()  # 当前按钮总数
        container_height = num * 117 + (num + 1) * 20  # num 个按钮 + 垂直间距
        self.container.setFixedSize(208, container_height)
        self.scrollAreaWidgetContents.setGeometry(QtCore.QRect(0, 0, 220, container_height + 20))

        # 调试：打印当前尺寸信息
        sb = self.page21_scrollarea_list_2
        logging.debug(f'num={num}, container_height={container_height}, '
                      f'scrollbar.maximum={sb.verticalScrollBar().maximum()}, '
                      f'viewport.height={sb.viewport().height()}')

        # 延迟一帧后滚动到底部，确保布局和尺寸已经完全 settle
        QTimer.singleShot(0, self._scroll_to_bottom)

    def _scroll_to_bottom(self):
        """延迟滚动到底部，确保布局已经 settle"""
        scrollbar = self.page21_scrollarea_list_2.verticalScrollBar()
        logging.debug(f'scrollbar.maximum={scrollbar.maximum()}')
        scrollbar.setValue(scrollbar.maximum())


    @pyqtSlot(float)
    def refresh_flow(self, flowRate):  # 刷新流量数据（flowRate 单位 L/s）
        # 实时流量显示为 L/min（×60）
        flow_l_min = flowRate * 60
        flow_text = '{:.2f}'.format(flow_l_min)
        self.page21_label_cell_num_2.setText(flow_text)
        self.flowtest_label_realtime.setText(flow_text)
        # 首页流量与测试页显示同一个实时值
        self.page21_label_average_3.setText(self.page21_label_average_2.text())
        self.page21_label_cell_num_3.setText(flow_text)
        self.page21_label_ml_3.setText(self.page21_label_ml_2.text())
        # 累计总流量：每秒累加 L/s，得到 L
        if self.flow_test_running:
            self.flow_test_total += flowRate
            self.flowtest_label_total.setText('{:.3f}'.format(self.flow_test_total))

    def on_test_page_changed(self, index, source=None):
        """子页面切换：进入流量测试页时屏蔽其他功能自动触发，仅保留流量计。
        流量测试页面现位于维护页(page4_stackedwidget_maintain, index=4)。
        """
        if source is None:
            # 兼容旧调用：流量测试在维护页 index 4
            is_flow_test = (index == 4)
        else:
            is_flow_test = (source == "maintain" and index == 4)
        if hasattr(self, 'flow_thread'):
            self.flow_thread.flow_test_mode = is_flow_test
        logging.info(f"流量测试模式：{'开启' if is_flow_test else '关闭'}")

    def _on_flowtest_start_clicked(self):
        """流量测试：开始/停止累计流量统计。"""
        if not self.flow_test_running:
            self.flow_test_running = True
            self.flow_thread.flow_test_running = True
            self.flow_test_total = 0.0
            self.flow_test_start_time = time.monotonic()
            self.flowtest_label_total.setText('0.000')
            self.flowtest_label_duration.setText('00:00')
            self.flowtest_toolbutton_start.setText('停止计量')
            self._set_flowtest_status('测试中', '#e74c3c')
            self.flow_test_timer.start(1000)
            self._flowtest_log('开始计量')
        else:
            self.flow_test_running = False
            self.flow_thread.flow_test_running = False
            self.flow_test_timer.stop()
            self._update_flow_test_duration()
            self.flowtest_toolbutton_start.setText('开始计量')
            self._set_flowtest_status('已结束', '#f39c12')
            self._flowtest_log(f'停止计量，累计总流量 {self.flow_test_total:.4f} L')

    def _on_flowtest_reset_clicked(self):
        """流量测试：复位累计流量与时长。"""
        self.flow_test_running = False
        self.flow_thread.flow_test_running = False
        self.flow_test_timer.stop()
        self.flow_test_total = 0.0
        self.flow_test_start_time = None
        self.flowtest_label_total.setText('0.000')
        self.flowtest_label_realtime.setText('0.00')
        self.flowtest_label_duration.setText('00:00')
        self.flowtest_toolbutton_start.setText('开始计量')
        self._set_flowtest_status('就绪', '#2ecc71')
        self._flowtest_log('已复位')

    def _update_flow_test_duration(self):
        """刷新流量测试时长（MM:SS）。"""
        if self.flow_test_start_time is None:
            return
        elapsed = int(time.monotonic() - self.flow_test_start_time)
        mm = elapsed // 60
        ss = elapsed % 60
        self.flowtest_label_duration.setText(f'{mm:02d}:{ss:02d}')

    def _flowtest_log(self, msg):
        """向流量测试日志面板追加一条消息。"""
        stamp = datetime.now().strftime('%H:%M:%S')
        self.flowtest_listwidget_log.addItem(f'[{stamp}] {msg}')
        self.flowtest_listwidget_log.scrollToBottom()

    def _set_flowtest_status(self, text, color):
        """设置流量测试页状态标签，圆点按状态着色。"""
        self.flowtest_label_status.setText(
            '<span style="color:{0};font-weight:bold;">●</span>  {1}'.format(color, text)
        )

    def _set_button_busy(self, button, busy):
        """切换按钮“执行中”状态：执行时高亮并禁用，完成后恢复。"""
        if busy:
            if not hasattr(button, '_orig_text'):
                button._orig_text = button.text()
                button._orig_style = button.styleSheet()
            button.setEnabled(False)
            button.setStyleSheet("QToolButton{background-color:rgb(240,150,0);"
                                 "color:rgb(255,255,255);border-radius:10px;}")
            button.setText(button._orig_text + "…")
        else:
            button.setEnabled(True)
            button.setText(getattr(button, '_orig_text', button.text()))
            button.setStyleSheet(getattr(button, '_orig_style', ''))
        QtWidgets.QApplication.processEvents()  # 立即重绘，确保状态可见

    @pyqtSlot()
    def microPumpSample(self):
        self._set_button_busy(self.page21_toolButton_capture_2, True)
        try:
            self.countCell_thread.signal_microPumpSample.emit()
        finally:
            self._set_button_busy(self.page21_toolButton_capture_2, False)

    @pyqtSlot()
    def initializeSample(self):
        self._set_button_busy(self.page21_toolButton_capture_3, True)
        try:
            self.countCell_thread.signal_initializeSample.emit()
        finally:
            self._set_button_busy(self.page21_toolButton_capture_3, False)

    @pyqtSlot()
    def sampleWash(self):
        self._set_button_busy(self.page21_toolButton_capture_4, True)
        try:
            self.countCell_thread.signal_sampleWash.emit()
        finally:
            self._set_button_busy(self.page21_toolButton_capture_4, False)

    @pyqtSlot()
    def colorWash(self):
        self._set_button_busy(self.page21_toolButton_capture_5, True)
        try:
            self.countCell_thread.signal_colorWash.emit()
        finally:
            self._set_button_busy(self.page21_toolButton_capture_5, False)

    @pyqtSlot()
    def Ratioinjection(self):
        self._set_button_busy(self.page21_toolButton_capture_8, True)
        try:
            self.countCell_thread.signal_Ratioinjection.emit()
        finally:
            self._set_button_busy(self.page21_toolButton_capture_8, False)

    @pyqtSlot()
    def SampleEmptiness(self):
        self._set_button_busy(self.page21_toolButton_capture_7, True)
        try:
            self.countCell_thread.signal_SampleEmptiness.emit()
        finally:
            self._set_button_busy(self.page21_toolButton_capture_7, False)

    @pyqtSlot()
    def chipWash(self):
        self._set_button_busy(self.page21_toolButton_capture_9, True)
        try:
            self.countCell_thread.signal_chipWash.emit()
        finally:
            self._set_button_busy(self.page21_toolButton_capture_9, False)

    @pyqtSlot()
    def samplingMixing(self):
        self._set_button_busy(self.page21_toolButton_capture_10, True)
        try:
            self.countCell_thread.signal_shakemotor.emit()
        finally:
            self._set_button_busy(self.page21_toolButton_capture_10, False)

    @pyqtSlot()
    def standardTest(self):
        try:
            self.page21_toolButton_capture_6.setEnabled(False)  # 禁用标测按钮
            self.countCell_thread.signal_standardTest.emit()  # 发送标测信号
        except Exception as e:
            logging.error(f"标测触发异常: {e}")
            self.page21_toolButton_capture_6.setEnabled(True)

    @pyqtSlot()
    def capture(self):
        try:
            folder_path = os.path.join(get_app_dir(), 'captured')
            # 获取当前时间
            current_time = datetime.now()
            # 格式化时间为字符串（年月日时分秒）
            timestamp = current_time.strftime("%Y%m%d_%H%M%S")
            # 创建文件名
            file_name = f"{timestamp}.png"  # 你可以根据需要调整文件扩展名
            # 完整的保存路径
            save_path = os.path.join(folder_path, file_name)

            frame = self.camera_thread.get_frame()
            cv2.imwrite(save_path, frame)

            msg = QMessageBox()
            # msg.setWindowFlags(QtCore.Qt.windowStaysOnTopHint)
            msg.setText('当前图像已保存！')
            msg.setWindowTitle('保存成功')
            msg.setStandardButtons(QMessageBox.Ok)
            msg.exec_()  # 显示弹窗并等待用户关闭
        except Exception as e:
            logging.error(f"保存图像出错: {e}")
