import json
import time
import os
import base64
import hashlib
import hmac
import urllib.parse
from datetime import datetime, timedelta, timezone
import paho.mqtt.client as mqtt
import requests


def _log(msg):
    """带时间戳的打印：例如 10:30:01 [OneNET] ..."""
    print(f"{datetime.now().strftime('%H:%M:%S')} {msg}")

# ==================== 设备号配置（换设备时改这里） ====================
# 每台设备对应不同设备号，部署时按下列步骤修改本机常量：
#   1. 将 CLIENT_ID 改为当前设备名（如 device002 → device003）
#   2. 在 OneNET 控制台为"该设备名"生成设备专属密码（token），结果形如
#      version=2018-10-31&res=products%2FPRODUCT_ID%2Fdevices%2Fdevice003&et=...&method=md5&sign=...
#      替换下面的 PASSWORD（token 中资源路径绑定了设备名，必须是该设备自己的）
#   3. 上传图片/广播用的 API_ACCESS_KEY、ONENET_USER_ID 为账号级，各设备相同无需改
PRODUCT_ID = "P2zzwX3HRM"
CLIENT_ID = "device005"
PASSWORD = "version=2018-10-31&res=products%2FP2zzwX3HRM%2Fdevices%2Fdevice005&et=1817024880&method=md5&sign=p1kx33Xo%2BuaT3H96ncAmaQ%3D%3D"
# ======================================================================
BROKER = "mqtts.heclouds.com"
PORT = 1883
API_ACCESS_KEY = "16210953942d47f08070931298a16b5d"
ONENET_USER_ID = "475912"
STATUS_WORK = 0
STATUS_CLEAN = 1

class OneNETUploader:
    def __init__(self, product_id=PRODUCT_ID, client_id=CLIENT_ID,
                 password=PASSWORD, broker=BROKER, port=PORT):
        self.product_id = product_id
        self.client_id = client_id
        self.password = password
        self.broker = broker
        self.port = port
        self.topic = f"$sys/{product_id}/{client_id}/thing/property/post"
        self.device_prefix = "device"  # 广播/对齐目标设备名前缀过滤
        self.client = None
        self._connected = False
        self.control_callback = None
        self._last_status = None

    def set_control_callback(self, callback):
        self.control_callback = callback

    def _make_api_token(self, res, hours=1):
        version = "2020-05-29"
        method = "sha1"
        et = str(int(time.time()) + hours * 3600)
        key = base64.b64decode(API_ACCESS_KEY)
        str_to_sign = f"{et}\n{method}\n{res}\n{version}"
        sign = base64.b64encode(
            hmac.new(key, str_to_sign.encode('utf-8'), hashlib.sha1).digest()
        ).decode()
        return (
            f"version={version}"
            f"&res={urllib.parse.quote(res, safe='')}"
            f"&et={et}"
            f"&method={method}"
            f"&sign={urllib.parse.quote(sign, safe='')}"
        )

    def get_all_devices(self):
        names = []
        offset = 0
        limit = 20
        while True:
            url = "https://iot-api.heclouds.com/device/list"
            token = self._make_api_token(f"userid/{ONENET_USER_ID}")
            try:
                # 注意：该接口用 offset/limit 分页，page/size 参数会被忽略
                resp = requests.get(url, params={"product_id": self.product_id,
                                                 "offset": offset, "limit": limit},
                                    headers={"authorization": token}, timeout=10)
                lst = resp.json().get("data", {}).get("list", [])
            except Exception as e:
                _log(f"[OneNET] 设备列表拉取失败: {e}")
                break
            if not lst:
                break
            for x in lst:
                name = x.get("name")
                if not name or name == self.client_id:
                    continue  # 排除本机自己
                # 只广播/对齐本产品下以指定前缀命名的设备（默认 device），
                # 避免产品下其它命名（如 milk 测试设备）混入目标列表
                if not name.startswith(self.device_prefix):
                    continue
                names.append(name)
            offset += len(lst)
            if len(lst) < limit:  # 本页未满，说明已拉完
                break
        return names

    def broadcast_status(self, status_value):
        # 把status下发给产品下其它所有设备
        url = "https://iot-api.heclouds.com/thingmodel/set-device-property"
        token = self._make_api_token(f"userid/{ONENET_USER_ID}")
        devices = self.get_all_devices()
        _log(f"[OneNET] status广播目标({len(devices)}台): {devices}")
        ok_devices = []
        for dev in devices:
            body = {
                "product_id": self.product_id,
                "device_name": dev,
                "params": {"status": status_value}
            }
            try:
                resp = requests.post(url, json=body,
                                     headers={"authorization": token}, timeout=10)
                result = resp.json()
                if result.get("code") == 0:
                    _log(f"[OneNET] status广播成功 -> {dev}")
                    ok_devices.append(dev)
                else:
                    _log(f"[OneNET] status广播失败 -> {dev}: {result.get('msg')}")
            except Exception as e:
                _log(f"[OneNET] status广播异常 -> {dev}: {e}")
        return ok_devices

    def set_status_via_http(self, status_value):
        """HTTP 直写本机 status 到云端（set-device-property，不走 MQTT）。
        用途：重启对齐后作双保险，确保云端"最新属性"一定刷新——
        实测 MQTT 上报偶有平台侧缓存滞后（历史已记录、最新值未更新）。"""
        url = "https://iot-api.heclouds.com/thingmodel/set-device-property"
        token = self._make_api_token(f"userid/{ONENET_USER_ID}")
        body = {
            "product_id": self.product_id,
            "device_name": self.client_id,
            "params": {"status": int(status_value)}
        }
        try:
            resp = requests.post(url, json=body,
                                 headers={"authorization": token}, timeout=10)
            result = resp.json()
            if result.get("code") == 0:
                _log(f"[OneNET] HTTP状态写入成功: status={status_value}")
                return True
            _log(f"[OneNET] HTTP状态写入失败: {result.get('msg')}")
            return False
        except Exception as e:
            _log(f"[OneNET] HTTP状态写入异常: {e}")
            return False

    def _get_status(self, device):
        """查某设备云端最新 status；取不到返回 None"""
        url = "https://iot-api.heclouds.com/thingmodel/query-device-property"
        token = self._make_api_token(f"userid/{ONENET_USER_ID}")
        try:
            resp = requests.get(url, params={"product_id": self.product_id,
                                             "device_name": device},
                                headers={"authorization": token}, timeout=10)
            data = resp.json().get("data") or []
            for it in data:
                if it.get("identifier") == "status":
                    try:
                        return int(it.get("value"))
                    except (TypeError, ValueError):
                        return None
        except Exception as e:
            _log(f"[OneNET] 查询 {device} status失败: {e}")
        return None

    def sync_status_from_online_devices(self, stop_check=None):
        """设备重启后的状态对齐：统计其它【在线】设备的 status 多数态。
        在线判定：对该设备做一次 set-device-property(下发现值相同, 无副作用)，
        成功(code=0)即在线；返回"设备不在线"即离线，不计入统计。
        规则：有在线设备→取多数态；无在线设备→返回工作(0=STATUS_WORK)。
        stop_check：可选的可调用对象（返回 True 表示应中断），每台设备前检查，
        用于退出时提前终止对齐循环。
        """
        devices = self.get_all_devices()
        _log(f"[OneNET] 重启对齐: 可对齐设备({len(devices)}台): {devices}")
        token = self._make_api_token(f"userid/{ONENET_USER_ID}")
        url = "https://iot-api.heclouds.com/thingmodel/set-device-property"
        online_status = []  # 记录在线设备的 status
        for dev in devices:
            if stop_check is not None and stop_check():
                _log("[OneNET] 重启对齐: 检测到退出请求，提前中断")
                break
            cur = self._get_status(dev)  # 查该设备当前 status
            if cur is None:
                continue
            body = {"product_id": self.product_id, "device_name": dev,
                    "params": {"status": cur}}  # 写相同值，探测在线且不改状态
            try:
                resp = requests.post(url, json=body,
                                     headers={"authorization": token}, timeout=10)
                if resp.json().get("code") == 0:
                    online_status.append(cur)
                    _log(f"[OneNET] 重启对齐: {dev} 在线 status={cur}")
                else:
                    _log(f"[OneNET] 重启对齐: {dev} 不在线，跳过")
            except Exception as e:
                _log(f"[OneNET] 重启对齐探测异常 {dev}: {e}")
        if not online_status:
            _log("[OneNET] 重启对齐: 无在线设备，保持默认工作状态")
            return STATUS_WORK
        # 取多数态
        majority = 1 if online_status.count(1) > online_status.count(0) else 0
        _log(f"[OneNET] 重启对齐: 在线设备status列表={online_status}，多数态={majority}")
        return majority

    def connect(self):
        try:
            self.client = mqtt.Client(mqtt.CallbackAPIVersion.VERSION2,
                                      client_id=self.client_id,
                                      protocol=mqtt.MQTTv311)
            self.client.username_pw_set(self.product_id, self.password)

            def on_connect(c, ud, flags, rc, props):
                if rc == 0:
                    _log("[OneNET] MQTT连接成功")
                    self._connected = True
                    # 订阅属性设置下行主题
                    set_topic = f"$sys/{self.product_id}/{self.client_id}/thing/property/set"
                    self.client.subscribe(set_topic, qos=0)
                    _log(f"[OneNET] 已订阅控制主题: {set_topic}")
                else:
                    _log(f"[OneNET] MQTT连接失败，返回码={rc}")

            def on_message(client, userdata, msg):
                try:
                    payload = json.loads(msg.payload.decode())
                    req_id = payload.get("id", "")
                    # 解析下发参数并回调上层
                    if "params" in payload:
                        for key, value in payload["params"].items():
                            if self.control_callback:
                                self.control_callback(key, value)
                    if req_id:
                        reply_topic = f"$sys/{self.product_id}/{self.client_id}/thing/property/set_reply"
                        reply_data = {
                            "id": req_id,
                            "code": 0,
                            "msg": "success"
                        }
                        self.client.publish(reply_topic, json.dumps(reply_data), qos=0)
                        _log(f"[OneNET] 发送指令应答 req_id={req_id}")
                except Exception as e:
                    _log(f"[OneNET] 消息解析/应答错误: {e}")

            self.client.on_connect = on_connect
            self.client.on_message = on_message
            # 先启动后台网络循环，再尝试建连：开机无网络导致 connect 抛异常时，
            # loop 线程仍会按 paho 的重连策略等网络恢复后自动重连
            self.client.loop_start()
            try:
                self.client.connect(self.broker, self.port, keepalive=60)
            except Exception as e:
                _log(f"[OneNET] 首次连接失败，后台将自动重连: {e}")
            timeout = 5
            while not self._connected and timeout > 0:
                time.sleep(0.2)
                timeout -= 0.2
            return self._connected
        except Exception as e:
            _log(f"[OneNET] 连接异常: {e}")
            self._connected = False
            return False

    def publish(self, img_num, cell_count):
        if not self._connected or self.client is None:
            _log("[OneNET] 未连接，跳过上报")
            return False
        payload = {
            "id": str(int(time.time() * 1000)),
            "params": {
                "captured_img_num": {"value": img_num},
                "cell_count": {"value": float(cell_count)}
            }
        }
        try:
            result = self.client.publish(self.topic, json.dumps(payload), qos=0)
            if result.rc == mqtt.MQTT_ERR_SUCCESS:
                _log(f"[OneNET] 上报成功: img_num={img_num}, cell_count={cell_count}")
                return True
            else:
                _log(f"[OneNET] 发布失败，错误码={result.rc}")
                return False
        except Exception as e:
            _log(f"[OneNET] 发布异常: {e}")
            return False

    def upload_image_to_onenet(self, local_image_path, api_access_key, user_id,
                               product_id=None, device_name=None):
        if product_id is None:
            product_id = self.product_id
        version = "2020-05-29"
        method = "sha1"
        res = f"userid/{user_id}"
        et = str(int(time.time()) + 30 * 24 * 3600)
        try:
            key = base64.b64decode(api_access_key)
        except Exception as e:
            _log(f"[OneNET] AccessKey base64 解码失败: {e}")
            return None
        str_to_sign = f"{et}\n{method}\n{res}\n{version}"
        sign_bytes = hmac.new(key, str_to_sign.encode('utf-8'), hashlib.sha1).digest()
        sign = base64.b64encode(sign_bytes).decode('utf-8')
        token = (
            f"version={version}"
            f"&res={urllib.parse.quote(res, safe='')}"
            f"&et={et}"
            f"&method={method}"
            f"&sign={urllib.parse.quote(sign, safe='')}"
        )
        url = "https://iot-api.heclouds.com/device/file-upload"
        headers = {"Authorization": token}
        try:
            with open(local_image_path, 'rb') as f:
                files = {
                    'file': (os.path.basename(local_image_path), f, 'image/jpeg')
                }
                data = {
                    'product_id': product_id,
                    'device_name': device_name if device_name else self.client_id
                }
                response = requests.post(url, headers=headers, files=files, data=data, timeout=10)
            if response.status_code == 200:
                result = response.json()
                if result.get('code') == 0:
                    fid = result['data']['fid']
                    _log(f"[OneNET] 文件上传成功，文件ID: {fid}")
                    return fid
                else:
                    _log(f"[OneNET] 上传失败，错误码: {result.get('code')}, 消息: {result.get('msg')}")
                    return None
            else:
                _log(f"[OneNET] 上传请求失败，状态码: {response.status_code}, 返回: {response.text}")
                return None
        except Exception as e:
            _log(f"[OneNET] 上传异常: {e}")
            return None

    def publish_with_fid(self, img_num, cell_count, fid, status=None):
        if not self._connected or self.client is None:
            _log("[OneNET] 未连接，跳过上报")
            return False
        params = {
            "captured_img_num": {"value": img_num},
            "cell_count": {"value": float(cell_count)},
            "latest_image_fid": {"value": fid}
        }
        if status is not None:
            params["status"] = {"value": int(status)}  # status 为 enum，须用 int 类型云端才接收
        payload = {
            "id": str(int(time.time() * 1000)),
            "params": params
        }
        try:
            result = self.client.publish(self.topic, json.dumps(payload), qos=0)
            if result.rc == mqtt.MQTT_ERR_SUCCESS:
                _log(f"[OneNET] 上报成功（含FID）: img_num={img_num}, fid={fid}, status={status}")
                self._check_status_broadcast(status)
                return True
            else:
                _log(f"[OneNET] 发布失败，错误码={result.rc}")
                return False
        except Exception as e:
            _log(f"[OneNET] 发布异常: {e}")
            return False

    def publish_status(self, status_value):
        """本机 status 上报云端记录（不带数字/图片，仅更新发起者自身的云端 status）。
        status_value：枚举数字(0=工作/1=清洗)

        可靠性：等待 MQTT 连接就绪后再上报（最多等3秒），避免启动初期/断线重连时
        因 _connected=False 把状态上报静默丢掉（否则会出现"被广播设备变了、发起者云端未变"）。
        """
        deadline = time.time() + 3.0
        while not self._connected and time.time() < deadline:
            time.sleep(0.2)
        if not self._connected or self.client is None:
            _log("[OneNET] 未连接，跳过状态上报")
            return False
        payload = {
            "id": str(int(time.time() * 1000)),
            "params": {"status": {"value": int(status_value)}}  # status 为 enum，须用 int 类型云端才接收
        }
        try:
            result = self.client.publish(self.topic, json.dumps(payload), qos=0)
            if result.rc == mqtt.MQTT_ERR_SUCCESS:
                _log(f"[OneNET] 状态上报成功: status={status_value}")
                return True
            else:
                _log(f"[OneNET] 状态发布失败，错误码={result.rc}")
                return False
        except Exception as e:
            _log(f"[OneNET] 状态发布异常: {e}")
            return False

    def _check_status_broadcast(self, status_value):
        # status发生变化时, 双向广播给所有设备（工作↔清洗皆广播）
        # status_value传枚举数字(0=工作/1=清洗)
        if status_value is None:
            return
        if str(status_value) == "工作":
            status_value = STATUS_WORK
        elif str(status_value) == "清洗":
            status_value = STATUS_CLEAN
        status_value = int(status_value)
        if self._last_status is not None and self._last_status != status_value:
            _log(f"[OneNET] 状态变化: {self._last_status} -> {status_value}, 开始广播...")
            self.broadcast_status(status_value)
        self._last_status = status_value

    def disconnect(self):
        if self.client:
            # 重启对齐等并发云端访问已被 closeEvent 的 _shutting_down 提前中断，
            # 普通 loop_stop() 即可，无需 force 参数（部分 paho 版本不支持该参数）。
            try:
                self.client.loop_stop()
            except Exception as e:
                _log(f"[OneNET] loop_stop 异常: {e}")
            try:
                self.client.disconnect()
            except Exception as e:
                _log(f"[OneNET] disconnect 异常: {e}")
        self._connected = False
        _log("[OneNET] 已断开")