#!/bin/bash
# 安装桌面开机自启（开机登录桌面后自动运行 main.py，界面全屏显示）
# 用法：bash setup_autostart.sh
set -e

APP_DIR="$(cd "$(dirname "$0")" && pwd)"
SERVICE_NAME="jiemian-autostart"

# 自动修复 Windows 行符并加执行权限（可重复运行）
for f in "$APP_DIR/autostart.sh" "$0"; do
    [ -f "$f" ] && sed -i 's/\r$//' "$f" && chmod +x "$f"
done

if [ "$(id -u)" != "0" ]; then
    exec sudo bash "$0"
fi

# 先卸掉可能已装的 systemd 服务，避免与桌面自启同时启动互相冲突
systemctl disable "$SERVICE_NAME" 2>/dev/null || true
systemctl stop "$SERVICE_NAME" 2>/dev/null || true
rm -f "/etc/systemd/system/${SERVICE_NAME}.service"
systemctl daemon-reload

# 定位登录桌面会话的真实用户（sudo 时用 SUDO_USER，避免写入 root 的家目录）
REAL_USER="${SUDO_USER:-$USER}"
REAL_HOME="$(getent passwd "$REAL_USER" | cut -d: -f6)"

# 写入 .desktop 自启文件；Exec 必须加引号，否则路径含空格/中文时会被拆成多个参数导致启动失败
write_desktop() {
    mkdir -p "$(dirname "$1")"
    cat > "$1" <<EOF
[Desktop Entry]
Type=Application
Name=Jiemian
Exec="$APP_DIR/autostart.sh"
Terminal=false
X-GNOME-Autostart-enabled=true
EOF
    echo "  已写入 $1"
}

# 系统级 + 用户级双写（不同桌面环境读取位置不同，双写最保险）
write_desktop /etc/xdg/autostart/jiemian.desktop
write_desktop "$REAL_HOME/.config/autostart/jiemian.desktop"

echo
echo "安装成功！下次开机登录桌面后，上位机界面会自动全屏显示。"
echo "如需现在测试，可执行：bash $APP_DIR/autostart.sh"
echo
echo "提示：若重启后停在登录界面而没有进入桌面，说明未开启自动登录，"
echo "请在 设置 -> 用户 -> 自动登录 开启，否则自启不会触发。"
