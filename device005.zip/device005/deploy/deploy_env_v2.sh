#!/bin/bash
# =============================================================
# 一键部署软件环境脚本 v2
# 功能：
#   1. 使用 sudo dpkg -i 安装当前文件夹下的所有 deb 包
#   2. 安装 Python 依赖（含工程新增库）：
#      - apt 包：python3-pip、python3-pyqt5、python3-pyqt5.qtchart、
#        python3-opencv、python3-pandas、python3-psutil、python3-serial、
#        python3-requests、python3-paramiko、python3-matplotlib、
#        python3-pil、python3-openpyxl
#      - pip 兜底包：paho-mqtt（OneNET 上报必需）、psutil、pyserial
#   3. 关闭并删除盲用功能（brltty）
# v2 相对 v1 新增依赖：
#   paho-mqtt / requests / paramiko / matplotlib / Pillow / openpyxl
# 用法：
#   chmod +x deploy_env_v2.sh
#   ./deploy_env_v2.sh
# =============================================================

set -u   # 使用未定义变量时报错

# 自动修复 Windows 行符（防止从 Windows 拷贝导致 \r 报错），修复后自动重跑
if [ "${DEPLOY_ENV_REEXEC:-}" != "1" ]; then
    sed -i 's/\r$//' "$0" 2>/dev/null || true
    export DEPLOY_ENV_REEXEC=1
    exec bash "$0" "$@"
fi

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR" || exit 1

echo "============================================================="
echo "           一键部署软件环境 v2 - 开始"
echo "============================================================="

# -------------------------------------------------------------
# 第 1 步：安装当前文件夹下的所有 deb 包
# -------------------------------------------------------------
echo ""
echo "[1/3] 安装当前文件夹下的 deb 包 ..."

DEB_COUNT=$(find "$SCRIPT_DIR" -maxdepth 1 -name "*.deb" | wc -l)

if [ "$DEB_COUNT" -eq 0 ]; then
    echo "  当前文件夹下没有发现 .deb 包，跳过此步骤。"
else
    echo "  发现 $DEB_COUNT 个 deb 包："
    for deb in "$SCRIPT_DIR"/*.deb; do
        echo "  -> $(basename "$deb")"
    done

    # 先统一安装所有 deb 包
    sudo dpkg -i "$SCRIPT_DIR"/*.deb
    if [ $? -ne 0 ]; then
        echo "  dpkg 提示存在依赖问题，正在自动修复依赖 ..."
        sudo apt-get install -f -y
        # 依赖修复后重新配置，确保 deb 包安装完整
        sudo dpkg -i "$SCRIPT_DIR"/*.deb
    fi
    echo "  deb 包安装完成。"
fi

# -------------------------------------------------------------
# 第 2 步：安装 Python 相关软件包
# -------------------------------------------------------------
echo ""
echo "[2/3] 安装 Python 相关软件包 ..."

# 更新软件源索引
sudo apt-get update

# 通过 apt 安装系统级 Python 包（含工程新增库）
sudo apt-get install -y \
    python3-pip \
    python3-pyqt5 \
    python3-pyqt5.qtchart \
    python3-opencv \
    python3-pandas \
    python3-psutil \
    python3-serial \
    python3-requests \
    python3-paramiko \
    python3-matplotlib \
    python3-pil \
    python3-openpyxl

if [ $? -ne 0 ]; then
    echo "  apt 安装出现问题，请检查软件源配置。"
fi

# 通过 pip 兜底安装（paho-mqtt 为 OneNET 上报必需，apt 源通常没有；
# psutil/pyserial 防止某些系统 apt 包名不同）
if command -v pip3 >/dev/null 2>&1; then
    if ! pip3 install paho-mqtt psutil pyserial; then
        echo "  常规 pip 安装失败，尝试 --break-system-packages 模式 ..."
        pip3 install --break-system-packages paho-mqtt psutil pyserial
    fi
else
    echo "  警告：未找到 pip3，跳过 pip 兜底安装。"
fi

echo "  Python 软件包安装完成。"

# -------------------------------------------------------------
# 第 3 步：关闭并删除盲用功能（brltty）
# -------------------------------------------------------------
echo ""
echo "[3/3] 关闭并删除盲用功能（brltty）..."

# 停止服务（忽略服务不存在的报错）
sudo systemctl stop brltty 2>/dev/null
# 禁用开机自启
sudo systemctl disable brltty 2>/dev/null
# 卸载软件包
sudo apt remove -y brltty

echo "  brltty 已停止、禁用并卸载。"

# -------------------------------------------------------------
# 完成
# -------------------------------------------------------------
echo ""
echo "============================================================="
echo "            一键部署 v2 完成！"
echo "============================================================="
