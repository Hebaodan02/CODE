#!/usr/bin/env bash
# 一键安装 Ubuntu/Debian 依赖（PyQt5 + OpenCV 上位机环境）
# 用法：bash install_deps.sh
set -euo pipefail

PYTHON_BIN="${PYTHON_BIN:-python3}"
PIP_CMD="sudo -H ${PYTHON_BIN} -m pip"
APP_DIR="$(cd "$(dirname "$0")" && pwd)"
PROJECT_DIR="$(cd "$APP_DIR/.." && pwd)"

# 自动修复 Windows 行符并加执行权限（可重复运行）
for f in "$APP_DIR"/*.sh; do
    [ -f "$f" ] && sed -i 's/\r$//' "$f" && chmod +x "$f"
done

echo "[1/5] 更新 apt ..."
sudo apt update

echo "[2/5] 安装系统依赖（PyQt5/OpenCV 运行库）..."
sudo apt install -y \
  python3-pip \
  python3-venv \
  python3-dev \
  build-essential \
  libgl1 \
  libglib2.0-0 \
  libxkbcommon-x11-0 \
  libxcb-xinerama0 \
  libxcb-cursor0 \
  libxcb-icccm4 \
  libxcb-image0 \
  libxcb-keysyms1 \
  libxcb-render-util0 \
  libxcb-xinput0 \
  libegl1 \
  libdbus-1-3 \
  libfontconfig1 \
  libfreetype6

echo "[3/5] 移除可能与 pip 包冲突的 apt Python 包 ..."
sudo apt remove -y python3-pyqt5 python3-serial python3-opencv || true

echo "[4/5] 升级 pip ..."
${PIP_CMD} install --upgrade pip setuptools wheel || ${PIP_CMD} install --upgrade --break-system-packages pip setuptools wheel

echo "[5/5] 安装项目依赖 ..."
if ! ${PIP_CMD} install -r "$PROJECT_DIR/requirements.txt"; then
  ${PIP_CMD} install --break-system-packages -r "$PROJECT_DIR/requirements.txt"
fi

echo
echo "依赖安装完成！"
