#!/bin/bash
# 上位机启动入口（桌面自启 / 手动运行均用此脚本）
set -e

APP_DIR="$(cd "$(dirname "$0")" && pwd)"
# main.py 位于工程根目录（本脚本的上一级）
PROJECT_DIR="$(cd "$APP_DIR/.." && pwd)"
cd "$PROJECT_DIR"

# 单实例锁：多个自启位置同时触发时只保留一个实例
exec 9>"$PROJECT_DIR/.autostart.lock"
if ! flock -n 9; then
    echo "[$(date '+%F %T')] main.py 已在运行，跳过本次启动" >> "$PROJECT_DIR/app_autostart.log"
    exit 0
fi

# 等待桌面完全就绪再启动界面
sleep 3

export PYTHONUNBUFFERED=1

exec python3 main.py >> "$PROJECT_DIR/app_autostart.log" 2>&1
