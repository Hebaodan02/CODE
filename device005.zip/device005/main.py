# 日志
import logging
import traceback

import sys
import os

from PyQt5.QtWidgets import QApplication
from PyQt5.QtCore import Qt
        
from window_function import Window_added
from window_function import init_immediate_logger


if __name__ == '__main__':
    init_immediate_logger()
    app = QApplication(sys.argv)
    # 关闭主窗口后不立即退出事件循环：留给 closeEvent 的后台清理线程时间。
    # 清理完成后由 closeEvent 显式调用 app.quit() 结束。
    app.setQuitOnLastWindowClosed(False)
    window = Window_added()
    window.showFullScreen()
    sys.exit(app.exec_())
