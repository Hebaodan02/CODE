import os
import csv
import time
import hmac
import hashlib
import base64
import urllib.parse
import datetime
import requests

CONFIG = {
    "api_base": "https://iot-api.heclouds.com",
    "product_id": "P2zzwX3HRM",
    "api_access_key": "16210953942d47f08070931298a16b5d",
    "user_id": "475912",
    "history_days": 7,
    "history_limit_per_window": 500,
}
IMG_PROPS = ("latest_image_fid", "captured_img_fid", "image_fid")


class OneNETPull:

    def __init__(self, cfg):
        self.base = cfg["api_base"].rstrip("/")
        self.product_id = cfg["product_id"]
        self.access_key = base64.b64decode(cfg["api_access_key"])
        self.user_id = cfg["user_id"]

    def _token(self, et_hours=7 * 24):
        version, method = "2020-05-29", "sha1"
        et = str(int(time.time()) + et_hours * 3600)
        res = "userid/%s" % self.user_id
        to_sign = "%s\n%s\n%s\n%s" % (et, method, res, version)
        sign = base64.b64encode(
            hmac.new(self.access_key, to_sign.encode(), hashlib.sha1).digest()
        ).decode()
        return "version=%s&res=%s&et=%s&method=%s&sign=%s" % (
            version, urllib.parse.quote(res, safe=''), et, method,
            urllib.parse.quote(sign, safe=''))

    def _get(self, path, params=None, timeout=25):
        r = requests.get(self.base + path, params=params,
                         headers={"Authorization": self._token()}, timeout=timeout)
        try:
            return r.json()
        except Exception:
            return {"code": r.status_code, "msg": "非JSON响应", "raw": r.text[:300]}

    def latest_properties(self, device):
        """某设备最新物模型属性。返回属性名: {"value":..,"time":..}}, code, msg"""
        j = self._get("/thingmodel/query-device-property",
                      {"product_id": self.product_id, "device_name": device})
        data = (j or {}).get("data")
        out = {}
        if isinstance(data, list):
            for it in data:
                ident = it.get("identifier")
                if ident:
                    out[ident] = it
        return out, (j or {}).get("code"), (j or {}).get("msg", "")

    def _history_raw(self, device, identifier, s_ms, e_ms, limit=500):
        j = self._get("/thingmodel/query-device-property-history",
                      {"product_id": self.product_id, "device_name": device,
                       "identifier": identifier, "start_time": int(s_ms),
                       "end_time": int(e_ms), "limit": int(limit), "sort": 0})
        d = (j or {}).get("data") or {}
        return d.get("list", []), (j or {}).get("code"), (j or {}).get("msg", "")

    def history_windowed(self, device, identifier, s_ms, e_ms):
        if e_ms - s_ms > 30 * 24 * 3600 * 1000:
            print("[提示] 跨度超过30天，OneNET只保留最近30天")
        win = 7 * 24 * 3600 * 1000
        rows, seen, err = [], set(), ""
        cur = s_ms
        while cur <= e_ms:
            wend = min(cur + win, e_ms)
            lst, code, msg = self._history_raw(device, identifier, cur, wend,
                                               limit=CONFIG["history_limit_per_window"])
            if code != 0 or not isinstance(lst, list):
                err = msg or "code=%s" % code
                break
            for it in lst:
                try:
                    t = int(it.get("time", 0))
                except Exception:
                    continue
                if t in seen:
                    continue
                seen.add(t)
                rows.append({
                    "time_ms": t,
                    "time_str": datetime.datetime.fromtimestamp(t / 1000).strftime("%Y-%m-%d %H:%M:%S"),
                    "value": it.get("value"),
                })
            if wend == e_ms:
                break
            cur = wend + 1
        rows.sort(key=lambda r: r["time_ms"])
        return rows, err

    def download_file(self, fid):
        """按 fid下文件，返回 (HTTP状态码, content-type, 字节)"""
        r = requests.get(self.base + "/device/file-download", params={"fid": fid},
                         headers={"Authorization": self._token()}, timeout=30)
        return r.status_code, r.headers.get("content-type", "image/jpeg"), r.content


def query_property(device, prop, date=None, start=None, end=None, csv=None):
    """拉指定设备、指定某天的某个属性历史。
    参数:device-设备名，prop-属性的标识符，date-"YYYY-MM-DD"，精确某一天（给了就忽略 start/end），start/end-"YYYY-MM-DD" 起止日期；end 不写默认今天，csv-给了就自动存成 CSV 文件"""
    #示例：r = query_property("device002", "cell_count", start="2026-08-18", end="2026-08-20")拉取设备02的cell并且指定起止日期
    #示例：r = query_property("device002", "cell_count", days=3, csv="./count.csv")拉取设备02最近三天的cell_count属性并且存成csv
    p = OneNETPull(CONFIG)
    now = int(time.time() * 1000)
    if date:
        s = _to_ms(date)
        e = s + 24 * 3600 * 1000 - 1
        tag = "指定日 %s" % date
    else:
        e = _to_ms(end) if end else now
        s = _to_ms(start) if start else e - CONFIG["history_days"] * 24 * 3600 * 1000
        tag = "%s ~ %s" % (
            datetime.datetime.fromtimestamp(s / 1000).strftime("%Y-%m-%d %H:%M"),
            datetime.datetime.fromtimestamp(e / 1000).strftime("%Y-%m-%d %H:%M"))
    rows, err = p.history_windowed(device, prop, s, e)
    if csv:
        _save_csv(rows, csv)
    return {"device": device, "prop": prop, "tag": tag,
            "count": len(rows), "rows": rows, "error": err}


def download_images(device, date=None, out_dir="images"):
    """下载指定设备的图片。"""
    #示例：imgs = download_images("device002", date="2026-08-20", out_dir="./图")下载设备02在指定某天的所有照片
    #示例：imgs = download_images("device001", date="2026-08-20")out_dir不写就用"images"目录
    p = OneNETPull(CONFIG)
    os.makedirs(out_dir, exist_ok=True)

    fids = []
    if date:
        for k in IMG_PROPS:
            r = query_property(device, k, date=date)
            for row in r["rows"]:
                if row["value"]:
                    fids.append((row["value"], row["time_str"]))
    else:
        props, code, msg = p.latest_properties(device)
        for k in IMG_PROPS:
            v = props.get(k, {})
            val = v.get("value") if isinstance(v, dict) else v
            if val:
                fids.append((val, ""))
                break

    seen, results = set(), []
    for fid, tstr in fids:
        if not fid or fid in seen:
            continue
        seen.add(fid)
        code, ct, body = p.download_file(fid)
        if code != 200:
            results.append({"fid": fid, "error": "下载失败 code=%s" % code})
            continue
        path = os.path.join(out_dir, "%s_%s%s" % (device, fid, _ext_of(ct, body)))
        with open(path, "wb") as f:
            f.write(body)
        results.append({"fid": fid, "path": path, "code": code,
                        "time_str": tstr, "ct": ct})
    if not fids:
        results.append({"error": "未找到该设备的图片"})
    return results


def download_fid(fid, out_dir="images"):
    """按文件ID直接下载一张图片。
    参数:fid-件ID（属性latest_image_fid），out_dir-存图目录"""
    #示例：r = download_fid("m4aHJFXFPaJfiNOzMSJ7", out_dir="./图")
    #示例：先拉属性历史query_property的latest_images_fid，再把里面的图片 fid 取出来，再逐个下
    p = OneNETPull(CONFIG)
    os.makedirs(out_dir, exist_ok=True)
    code, ct, body = p.download_file(fid)
    if code != 200:
        return {"fid": fid, "error": "下载失败 code=%s" % code}
    path = os.path.join(out_dir, "%s%s" % (fid, _ext_of(ct, body)))
    with open(path, "wb") as f:
        f.write(body)
    return {"fid": fid, "path": path, "code": code, "ct": ct}


def _to_ms(s):
    try:
        return int(datetime.datetime.strptime(s, "%Y-%m-%d").replace(
            hour=0, minute=0, second=0).timestamp() * 1000)
    except Exception:
        raise SystemExit("日期格式错误: %s（请用 YYYY-MM-DD）" % s)


def _save_csv(rows, path):
    dirn = os.path.dirname(path)
    if dirn:
        os.makedirs(dirn, exist_ok=True)
    with open(path, "w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f)
        w.writerow(["time", "value"])
        for r in rows:
            w.writerow([r["time_str"], r["value"]])
    print("[OK] 已保存 %d 条 -> %s" % (len(rows), path))


def _ext_of(ct, body=b""):
    if "png" in (ct or ""):
        return ".png"
    if "jpeg" in (ct or "") or "jpg" in (ct or ""):
        return ".jpg"
    if body[:2] == b"BM":
        return ".bmp"
    if body[:3] == b"\xff\xd8\xff":
        return ".jpg"
    if body[:4] == b"\x89PNG":
        return ".png"
    return ".img"
