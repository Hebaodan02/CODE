"""
圆顶匹配检测（DoG）细胞计数算法 —— 低对比度弥散细胞图像专用
================================================================
适用场景：细胞只比背景亮几个灰度级（如6-8级），全局阈值失效；
         细胞形态为直径约10-15px的平滑圆顶，中心有亮核。
原理：DoG(σ1.5-σ5)匹配圆顶尺度，压制平坦背景/大团块/像素噪声；
      局部峰值 + 自适应阈值（中位数+4倍MAD）分离细胞与噪声。

调用方式（供上位机 window_function.py 等模块使用）：
    from new_dog import DogCellCounter, count_cells

    # 方式1：单次调用，最简接口（返回 cell_num, overlay_img）
    cell_num, overlay_img = count_cells(img)

    # 方式2：复用实例（避免重复构造，调参更方便）
    counter = DogCellCounter(save_root="./cell_processed_result")
    cell_num, overlay_img = counter.count(img)
    # 如需同时保存四联对比图：
    cell_num, overlay_img = counter.count(img, save_compare=True, img_name="sample_001")
"""

import cv2
import numpy as np
import os
from glob import glob


# --------------------------- 算法默认参数 ---------------------------
# DoG 圆顶匹配 + 灰度对比度过滤：针对高增益噪声下的低对比度弥散细胞图像
DEFAULT_PARAMS = {
    "DOG_SIGMA1": 1.5,        # DoG小核：匹配细胞亮核尺度
    "DOG_SIGMA2": 5.0,        # DoG大核：估计圆顶周边的局部背景
    "MAD_K": 4.0,             # 自适应阈值系数：阈值 = 峰响应中位数 + MAD_K × 1.4826×MAD
    "MIN_RESPONSE": 1.8,      # 峰响应绝对下限（防止全图无细胞时把噪声当细胞）
    "NMS_SIZE": 9,            # 局部最大值邻域（每个圆顶只取一个峰）
    "MERGE_DIST": 12,         # 近邻峰合并距离（同一细胞的多峰合并）
    "SIZE_WINDOW": 25,        # 轮廓提取窗口半径（px，应大于最大细胞半径）
    # 预处理滤波（相机增益高 → 噪点多 → DoG 假峰多，强化去噪）
    "MEDIAN_KERNEL": 5,       # 中值滤波核（3→5：更强的椒盐噪声抑制）
    "BILATERAL_D": 5,         # 双边滤波邻域直径（保边去高斯噪声）
    "BILATERAL_SIGMA_COLOR": 50,   # 双边滤波颜色空间σ
    "BILATERAL_SIGMA_SPACE": 50,   # 双边滤波坐标空间σ
    # 灰度对比度过滤（"肉眼可见"判据：剔除 DoG 放大的微弱假峰）
    # contrast = 峰位置灰度 - 环带背景灰度，断崖在 29→23，取 20 完美分离
    "GRAY_CONTRAST_MIN": 20.0,    # 灰度对比度下限，低于此值判定为噪声假峰剔除
    "GRAY_LOCAL_OFFSET": 3.0,    # 轮廓提取阈值 = 环带背景灰度 + 此偏移
    "RING_INNER": 8,              # 环带内半径（细胞核之外）
    "RING_OUTER": 16,             # 环带外半径（局部背景采样）
    "AREA_MIN": 20,               # 轮廓面积下限（px²）
    "AREA_MAX": 500,              # 轮廓面积上限（px²）
}


class DogCellCounter:
    """
    DoG 圆顶匹配细胞计数器（线程安全无状态：纯函数式调用，每次 count() 互不影响）

    Parameters
    ----------
    save_root : str
        结果保存根目录（仅在调用 save_compare=True / process_single_image / process_batch_images 时使用）
    params : dict, optional
        覆盖默认参数（见 DEFAULT_PARAMS）；为 None 时使用默认值
    """

    def __init__(self, save_root="./cell_processed_result", params=None):
        self.save_root = save_root
        # 合并参数（实例属性，便于运行时调参）
        merged = dict(DEFAULT_PARAMS)
        if params:
            merged.update(params)
        for k, v in merged.items():
            setattr(self, k, v)

    # ------------------------------------------------------------------
    #  各算法步骤（原模块级函数迁入，逻辑保持不变）
    # ------------------------------------------------------------------
    def preprocess_image(self, img):
        """
        彩色图适配预处理：保留彩色原图，提取亮度通道做后续处理
        高增益相机噪声大：中值滤波(去椒盐) + 双边滤波(保边去高斯噪声)
        :return: color_img(彩色图), denoise_gray(8位灰度亮度图, 双重去噪后)
        """
        if len(img.shape) == 3:
            color_img = img.copy()
            ycrcb = cv2.cvtColor(img, cv2.COLOR_BGR2YCrCb)
            gray = ycrcb[:, :, 0]
        else:
            gray = img.copy()
            color_img = cv2.cvtColor(gray, cv2.COLOR_GRAY2BGR)

        if gray.dtype == np.uint16:
            gray_8bit = cv2.normalize(gray, None, 0, 255, cv2.NORM_MINMAX, dtype=np.uint8)
        else:
            gray_8bit = gray

        # 中值去椒盐 + 双边保边去高斯噪声（双边保留细胞边缘，避免模糊）
        med = cv2.medianBlur(gray_8bit, self.MEDIAN_KERNEL)
        denoise_gray = cv2.bilateralFilter(
            med, d=self.BILATERAL_D,
            sigmaColor=self.BILATERAL_SIGMA_COLOR,
            sigmaSpace=self.BILATERAL_SIGMA_SPACE
        )
        # 供 cell_segment 做灰度对比度过滤与轮廓提取（DoG 仅用于定位峰）
        self._bilateral_gray = denoise_gray
        return color_img, denoise_gray

    def cell_enhance(self, denoise_img):
        """DoG圆顶匹配滤波，输出响应图（float32，越大越像细胞）"""
        g = denoise_img.astype(np.float32)
        dog = cv2.GaussianBlur(g, (0, 0), self.DOG_SIGMA1) - cv2.GaussianBlur(g, (0, 0), self.DOG_SIGMA2)
        return dog

    def cell_segment(self, dog):
        """
        在DoG响应图上检测细胞峰并提取真实轮廓：
        1) 局部最大值(NMS_SIZE邻域) + 自适应阈值(中位数+MAD_K*MAD，下限MIN_RESPONSE)
        2) 近邻峰(MERGE_DIST内)合并为一个细胞
        3) 每个峰在 SIZE_WINDOW 窗口内取 响应>峰值×HALF_MAX_RATIO 的连通区域，
           作为该细胞的真实轮廓（保留大小差异）
        :return: binary(二值图，真实轮廓填充), peaks, contours, thr(本次阈值)
        """
        dil = cv2.dilate(dog, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (self.NMS_SIZE, self.NMS_SIZE)))
        peak_mask = dog == dil
        vals = dog[peak_mask]
        if len(vals) == 0:
            return np.zeros(dog.shape, np.uint8), [], [], self.MIN_RESPONSE
        med = np.median(vals)
        mad = np.median(np.abs(vals - med))
        thr = max(med + self.MAD_K * 1.4826 * mad, self.MIN_RESPONSE)

        sel = (peak_mask & (dog > thr)).astype(np.uint8)
        # 近邻峰合并：向量化 scatter-max 找每个连通域内的最强峰
        # （原实现逐连通域 np.where 全图遍历，大图+多峰时耗时数百ms）
        mrg = cv2.dilate(sel, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (self.MERGE_DIST, self.MERGE_DIST)))
        n, lab = cv2.connectedComponents(mrg)
        peaks = []
        ys_sel, xs_sel = np.where(sel > 0)
        if len(ys_sel) > 0:
            labels_sel = lab[ys_sel, xs_sel]
            vals_sel = dog[ys_sel, xs_sel]
            n_lab = int(lab.max()) + 1
            best_val = np.full(n_lab, -np.inf, dtype=np.float32)
            np.maximum.at(best_val, labels_sel, vals_sel)
            # 取每个 label 内响应最大的像素（并列取第一个）
            is_best = vals_sel == best_val[labels_sel]
            _, first_idx = np.unique(labels_sel[is_best], return_index=True)
            xs_best = xs_sel[is_best][first_idx]
            ys_best = ys_sel[is_best][first_idx]
            vs_best = vals_sel[is_best][first_idx]
            peaks = [(int(x), int(y), round(float(v), 1))
                     for x, y, v in zip(xs_best, ys_best, vs_best) if v > 0]

        # 提取每个细胞的真实轮廓：原图灰度 + 灰度对比度过滤
        # （原半峰法在 DoG 尖锐峰上只提取到峰点附近几像素，掩码是小点；
        #  改在原图灰度上提取，并加灰度对比度过滤剔除"肉眼不可见"的假峰）
        gray = self._bilateral_gray
        H, Wd = dog.shape
        binary = np.zeros(dog.shape, np.uint8)
        contours = []
        ri, ro = self.RING_INNER, self.RING_OUTER
        SW = self.SIZE_WINDOW
        for x, y, v in peaks:
            # 环带局部背景采样（细胞核之外的环形区域）
            y0, y1 = max(0, y - ro), min(H, y + ro + 1)
            x0, x1 = max(0, x - ro), min(Wd, x + ro + 1)
            yy, xx = np.ogrid[(y0 - y):(y1 - y), (x0 - x):(x1 - x)]
            ring = ((xx ** 2 + yy ** 2) <= ro ** 2) & ((xx ** 2 + yy ** 2) >= ri ** 2)
            if ring.sum() == 0:
                continue
            gray_bg = float(gray[y0:y1, x0:x1][ring].mean())
            peak_gray = float(gray[y, x])
            gray_contrast = peak_gray - gray_bg
            # 灰度对比度过滤：剔除 DoG 放大的微弱假峰（"肉眼不可见"判据）
            if gray_contrast < self.GRAY_CONTRAST_MIN:
                continue
            # 在原图灰度上提取轮廓（低阈值覆盖真实细胞区域）
            local_thr = gray_bg + self.GRAY_LOCAL_OFFSET
            wy0, wy1 = max(0, y - SW), min(H, y + SW + 1)
            wx0, wx1 = max(0, x - SW), min(Wd, x + SW + 1)
            win_gray = gray[wy0:wy1, wx0:wx1]
            bw = (win_gray > local_thr).astype(np.uint8)
            nn, wlab = cv2.connectedComponents(bw)
            li = wlab[y - wy0, x - wx0]
            if li == 0:
                continue
            ys, xs = np.where(wlab == li)
            area = len(xs)
            if area < self.AREA_MIN or area > self.AREA_MAX:
                continue
            cnt = np.column_stack([xs + wx0, ys + wy0]).reshape(-1, 1, 2).astype(np.int32)
            contours.append(cnt)
            cv2.drawContours(binary, [cnt], -1, 255, -1)
        return binary, peaks, contours, thr

    def cell_count(self, binary_img, peaks, contours):
        """计数逻辑：有效轮廓数即细胞数"""
        return len(contours), contours

    def overlay_mask_to_original(self, color_img, binary_img, valid_contours):
        """在彩色原图上叠加红色掩码+白色编号"""
        overlay_img = color_img.copy()
        mask_red = np.zeros_like(overlay_img)
        mask_red[:, :, 2] = binary_img
        cv2.addWeighted(overlay_img, 1.0, mask_red, 0.8, 0, overlay_img)

        for idx, cnt in enumerate(valid_contours, 1):
            M = cv2.moments(cnt)
            if M["m00"] != 0:
                cX = int(M["m10"] / M["m00"])
                cY = int(M["m01"] / M["m00"])
            else:
                # 极小轮廓的几何面积为0，退化为轮廓点的均值中心
                pts = cnt.reshape(-1, 2)
                cX, cY = int(pts[:, 0].mean()), int(pts[:, 1].mean())
            cv2.putText(overlay_img, str(idx), (cX - 8, cY + 8),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.4, (255, 255, 255), 1)
        return overlay_img

    def _get_plt(self):
        """延迟导入 matplotlib 并切换到 Agg 后端，避免 import 时副作用"""
        import matplotlib
        matplotlib.use("Agg", force=True)
        import matplotlib.pyplot as _plt
        _plt.rcParams['font.sans-serif'] = ['SimHei']
        _plt.rcParams['axes.unicode_minus'] = False
        return _plt

    def visualize_and_save(self, color_img, dog, peaks, binary, overlay, cell_num, thr, save_path, img_name):
        """四联对比：原始彩色图 / DoG响应图(红圈标峰) / 二值分割图 / 彩色叠加图"""
        plt = self._get_plt()
        fig, axes = plt.subplots(1, 4, figsize=(24, 6))

        axes[0].imshow(cv2.cvtColor(color_img, cv2.COLOR_BGR2RGB))
        axes[0].set_title("原始彩色图", fontsize=14)
        axes[0].axis("off")

        # DoG响应图：分位数拉伸显示（98分位截断高亮，避免个别强响应把弱细胞压黑）
        # 并用红圈标出实际检测到的峰位置，与第三联一一对应
        hi = np.percentile(dog, 99.0)
        if hi <= 0:
            hi = dog.max() if dog.max() > 0 else 1.0
        dog_show = np.clip(dog, 0, hi) / hi * 255
        dog_show = cv2.cvtColor(dog_show.astype(np.uint8), cv2.COLOR_GRAY2BGR)
        for x, y, _ in peaks:
            cv2.circle(dog_show, (x, y), 10, (0, 0, 255), 1)
        axes[1].imshow(cv2.cvtColor(dog_show, cv2.COLOR_BGR2RGB))
        axes[1].set_title("DoG圆顶匹配响应图（红圈=检出峰）", fontsize=14)
        axes[1].axis("off")

        axes[2].imshow(binary, cmap="gray")
        axes[2].set_title(f"二值分割图（阈值={thr:.1f}）\n检测细胞数：{cell_num}", fontsize=14)
        axes[2].axis("off")

        axes[3].imshow(cv2.cvtColor(overlay, cv2.COLOR_BGR2RGB))
        axes[3].set_title(f"彩色原图+红色分割叠加\n检测细胞数：{cell_num}", fontsize=14)
        axes[3].axis("off")

        plt.tight_layout()
        plt.savefig(os.path.join(save_path, f"{img_name}_compare.png"), dpi=300, bbox_inches="tight")
        plt.close(fig)
        print(f"✅ 图片 {img_name} 处理完成，检测到细胞数：{cell_num}")

    # ------------------------------------------------------------------
    #  对外统一入口
    # ------------------------------------------------------------------
    def count(self, img, save_compare=False, img_name=None):
        """
        单张图完整流程，返回 (细胞数, 彩色叠加图) —— 与 window_function.py 调用约定一致

        Parameters
        ----------
        img : np.ndarray
            cv2 读取的彩色/灰度图（uint8 / uint16 均可）
        save_compare : bool
            是否保存四联对比图（默认 False，避免上位机调用时产生磁盘 IO）
        img_name : str, optional
            保存对比图时使用的文件名（不含扩展名）；save_compare=True 时必填

        Returns
        -------
        cell_num : int
        overlay_img : np.ndarray  与输入同尺寸的彩色叠加图（BGR）
        """
        color_img, gray_denoise = self.preprocess_image(img)
        dog = self.cell_enhance(gray_denoise)
        binary, peaks, contours, thr = self.cell_segment(dog)
        cell_num, contours = self.cell_count(binary, peaks, contours)
        overlay_img = self.overlay_mask_to_original(color_img, binary, contours)

        if save_compare and img_name:
            save_dir = os.path.join(self.save_root, "single_result")
            os.makedirs(save_dir, exist_ok=True)
            self.visualize_and_save(color_img, dog, peaks, binary, overlay_img,
                                    cell_num, thr, save_dir, img_name)
        return cell_num, overlay_img

    def count_with_area(self, img, save_compare=False, img_name=None):
        """
        单张图完整流程，返回 (细胞数, 彩色叠加图, 平均面积px²) —— 需要面积统计时使用
        """
        cell_num, overlay_img = self.count(img, save_compare=save_compare, img_name=img_name)
        # 重新跑一次分割拿 contours（count() 没回传，避免破坏其简洁接口）
        _, gray_denoise = self.preprocess_image(img)
        dog = self.cell_enhance(gray_denoise)
        _, _, contours, _ = self.cell_segment(dog)
        areas = [cv2.contourArea(c) for c in contours]
        mean_area = sum(areas) / len(areas) if areas else 0
        return cell_num, overlay_img, mean_area

    # ------------------------------------------------------------------
    #  脚本式批量入口（保留原行为）
    # ------------------------------------------------------------------
    XLSX_NAME = "计数汇总.xlsx"   # 保存在 batch_result 内，随结果一起剪切到 access

    def write_excel_summary(self, records):
        """
        汇总所有图片计数结果到 Excel：
        records = [(图片名, 细胞数, 平均面积px²), ...]
        蓝字=原始值，黑字=Excel 公式（合计/均值/最大/最小）
        保存至 <save_root>/batch_result/计数汇总.xlsx（随结果一起剪切到 access）
        写入前检测：文件不存在则新建，已存在则覆盖为本批最新结果
        """
        import openpyxl
        from openpyxl.styles import Font, PatternFill, Alignment, Border, Side

        out_dir = os.path.join(self.save_root, "batch_result")
        os.makedirs(out_dir, exist_ok=True)
        out_path = os.path.join(out_dir, self.XLSX_NAME)
        exists = os.path.exists(out_path)

        wb = openpyxl.Workbook()
        ws = wb.active
        ws.title = "计数汇总"
        ws.sheet_view.showGridLines = False

        thin = Side(style="thin", color="D9D9D9")
        border = Border(left=thin, right=thin, top=thin, bottom=thin)
        blue = Font(color="1F4E9C")       # 原始值
        black = Font(color="000000")      # 公式
        hdr_font = Font(bold=True, color="FFFFFF")
        hdr_fill = PatternFill("solid", fgColor="4472C4")
        stat_fill = PatternFill("solid", fgColor="FCE4D6")
        center = Alignment(horizontal="center", vertical="center")

        R_HDR, R0 = 2, 3
        headers = ["图片名", "细胞数", "平均面积(px²)"]
        for j, h in enumerate(headers):
            c = ws.cell(R_HDR, 2 + j, h)
            c.font = hdr_font
            c.fill = hdr_fill
            c.alignment = center
        for i, (name, num, area) in enumerate(records):
            r = R0 + i
            ws.cell(r, 2, name).alignment = center
            ws.cell(r, 3, num).font = blue
            ws.cell(r, 3).alignment = center
            c4 = ws.cell(r, 4, round(area, 1))
            c4.font = blue
            c4.alignment = center
        R_END = R0 + len(records) - 1

        labels = ["合计", "单张均值", "单张最大", "单张最小", "标准差"]
        funcs = {"合计": "SUM", "单张均值": "AVERAGE", "单张最大": "MAX",
                 "单张最小": "MIN", "标准差": "STDEV"}
        for k, label in enumerate(labels):
            r = R_END + 1 + k
            ws.cell(r, 2, label).font = Font(bold=True)
            ws.cell(r, 2).fill = stat_fill
            ws.cell(r, 2).alignment = center
            for cl, col in [("C", 3), ("D", 4)]:
                if label == "合计" and col == 4:
                    continue  # 面积不求合计
                cell = ws.cell(r, col, f"={funcs[label]}({cl}{R0}:{cl}{R_END})")
                cell.font = black
                cell.fill = stat_fill
                cell.alignment = center
                cell.number_format = "0.0" if label != "合计" else "0"

        for row in ws.iter_rows(min_row=R_HDR, max_row=R_END + len(labels), min_col=2, max_col=4):
            for cell in row:
                cell.border = border
        ws.column_dimensions["A"].width = 2
        ws.column_dimensions["B"].width = 26
        ws.column_dimensions["C"].width = 10
        ws.column_dimensions["D"].width = 14
        ws.freeze_panes = ws.cell(R0, 2)
        ws.auto_filter.ref = f"B{R_HDR}:D{R_END}"

        wb.save(out_path)
        action = "已存在，覆盖更新" if exists else "文件不存在，已新建"
        print(f"📑 计数汇总 Excel（{action}）：{os.path.abspath(out_path)}")

    def process_single_image(self, img_path):
        """脚本式单张处理：读图 → 计数 → 保存对比图 → 返回 (细胞数, 平均面积px²)"""
        if not os.path.exists(img_path):
            raise FileNotFoundError(f"图片路径不存在：{img_path}")
        save_dir = os.path.join(self.save_root, "single_result")
        os.makedirs(save_dir, exist_ok=True)
        img = cv2.imread(img_path, cv2.IMREAD_UNCHANGED)
        img_name = os.path.splitext(os.path.basename(img_path))[0]
        return self.count_with_area(img, save_compare=True, img_name=img_name)

    def process_batch_images(self, folder_path):
        """脚本式批量处理：扫描文件夹 → 逐张计数 → 写 Excel 汇总"""
        if not os.path.exists(folder_path):
            raise FileNotFoundError(f"文件夹不存在：{folder_path}")
        save_dir = os.path.join(self.save_root, "batch_result")
        os.makedirs(save_dir, exist_ok=True)

        img_formats = ["*.png", "*.jpg", "*.jpeg", "*.tif", "*.tiff"]
        img_paths = []
        for fmt in img_formats:
            img_paths.extend(glob(os.path.join(folder_path, fmt)))
        if len(img_paths) == 0:
            raise ValueError("文件夹中未找到支持的图片格式")

        print(f"📌 开始批量处理，共找到 {len(img_paths)} 张彩色图")
        total_cell_num = 0
        records = []  # (图片名, 细胞数, 平均面积px²)
        for idx, img_path in enumerate(img_paths, 1):
            try:
                img = cv2.imread(img_path, cv2.IMREAD_UNCHANGED)
                img_name = os.path.splitext(os.path.basename(img_path))[0]
                cell_num, _, mean_area = self.count_with_area(img, save_compare=True, img_name=img_name)
                total_cell_num += cell_num
                records.append((img_name, cell_num, mean_area))
                print(f"[{idx}/{len(img_paths)}] 处理完成：{img_name} | 单张细胞数：{cell_num}")
            except Exception as e:
                print(f"❌ 处理 {img_path} 失败：{str(e)}，跳过该图片")

        self.write_excel_summary(records)
        print(f"🎉 批量处理完成 | 累计检测细胞数：{total_cell_num} 个")
        print(f"📁 结果保存至：{os.path.abspath(save_dir)}")


# ----------------------------------------------------------------------
#  模块级便捷函数（最简调用入口，供 window_function.py 直接 import 使用）
# ----------------------------------------------------------------------
_default_counter = None


def count_cells(img, save_compare=False, img_name=None, save_root="./cell_processed_result",
                params=None):
    """
    单张图细胞计数便捷函数 —— 上位机推荐入口

    >>> from new_dog import count_cells
    >>> cell_num, overlay_img = count_cells(frame)

    Parameters
    ----------
    img : np.ndarray
        cv2 读取的彩色/灰度图
    save_compare : bool
        是否保存四联对比图（默认 False）
    img_name : str, optional
        保存对比图时的文件名（save_compare=True 时必填）
    save_root : str
        结果保存根目录
    params : dict, optional
        覆盖默认算法参数（见 DEFAULT_PARAMS）

    Returns
    -------
    cell_num : int
    overlay_img : np.ndarray  BGR 彩色叠加图
    """
    global _default_counter
    # 参数未变时复用单例，避免每次调用都重建对象
    if _default_counter is None or _default_counter.save_root != save_root:
        _default_counter = DogCellCounter(save_root=save_root, params=params)
    return _default_counter.count(img, save_compare=save_compare, img_name=img_name)


# ----------------------------------------------------------------------
#  脚本入口（保持原 __main__ 行为）
# ----------------------------------------------------------------------
if __name__ == "__main__":
    # 脚本式配置
    PROCESS_MODE = "batch"   # single(单张)/batch(批量)
    IMG_PATH = "./img"      # 单张图路径/批量文件夹路径
    SAVE_ROOT = "./cell_processed_result"  # 结果保存根目录

    counter = DogCellCounter(save_root=SAVE_ROOT)
    try:
        if PROCESS_MODE == "single":
            counter.process_single_image(IMG_PATH)
        elif PROCESS_MODE == "batch":
            counter.process_batch_images(IMG_PATH)
        else:
            raise ValueError("PROCESS_MODE仅支持single或batch")
        print(f"\n📊 所有处理完成，结果根目录：{os.path.abspath(SAVE_ROOT)}")
    except Exception as e:
        print(f"\n❌ 程序执行失败：{str(e)}")
